package codebook.runtime.redis_extension

import akka.actor.{Actor, ActorLogging, ActorRef}
import scredis.PubSubMessage

class PubSubWorker extends Actor with ActorLogging {
  def receive:Receive = process(Set.empty)

  def process(subscriber:Set[ActorRef]):Receive = {
    case m: PubSubMessage.Subscribe => println(s"Subscribed to channel ${m.channel}")
    case m: PubSubMessage.Message => println(s"Received message for channel ${m.channel} with data ${m.readAs[String]()}")
    case m: PubSubMessage.Unsubscribe => println(s"Unsubscribed from channel ${m.channelOpt}")
    case m: PubSubMessage.PSubscribe => println(s"Subscribed to channels matching pattern ${m.pattern}")
    case m: PubSubMessage.PMessage => println(s"Received message for pattern ${m.pattern} on channel ${m.channel} with data ${m.readAs[String]()}")
    case m: PubSubMessage.PUnsubscribe => println(s"Unsubscribed from pattern matching ${m.patternOpt}")
    case e: PubSubMessage.Error => println(s"Scredis received error $e")
  }
}
