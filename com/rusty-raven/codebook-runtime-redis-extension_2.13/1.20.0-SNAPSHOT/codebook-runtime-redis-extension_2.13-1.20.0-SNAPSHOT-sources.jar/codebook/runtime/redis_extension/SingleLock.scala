package codebook.runtime.redis_extension

import codebook.runtime.redis_extension.RedisClientType.RedisClient

import scala.concurrent.{ExecutionContext, Future}

class SingleLock(clientPool: RedisClientPool[_ <: RedisClient], key:String, lockWord:String) extends RedisLock {
  private var _lock:Boolean = false

  override def lock(timeoutSec:Int = 5)(implicit ec:ExecutionContext): Future[Boolean] = {
    clientPool.client.setNX(key, lockWord:String).map {
      r =>
        _lock = r
        clientPool.client.expire(key,timeoutSec)

        r
    }
  }

  override def unlock()(implicit ec:ExecutionContext): Future[Boolean] = {
    if (_lock) {
      clientPool.client.del(key).map {
        _ =>
          _lock = false
          true
      }
    } else {
      Future.successful(true)
    }
  }

  override def isLocked:Boolean = _lock
}
