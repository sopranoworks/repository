package codebook.runtime.redis_extension

import codebook.runtime.redis_extension.RedisClientType.RedisClient
import scredis.serialization.{Reader, Writer}

import scala.concurrent.{ExecutionContext, Future}

class RedisList[V](val bucket:String)(implicit val redisClientPool:RedisClientPool[_ <: RedisClient], reader:Reader[V], writer:Writer[V], ec:ExecutionContext) extends RedisLockable {

  def get(i: Int):Future[Option[V]] =
    redisClientPool.client.lIndex(bucket, i)

  def getAll:Future[List[V]] = slice(0, -1)

  def set(i: Int, v:V):Future[Boolean] =
    redisClientPool.client.lSet(bucket, i, v).map(_ => true)

  def remove(v:V, limit:Int = 0):Future[Int] =
    redisClientPool.client.lRem(bucket, v, limit).map(_.toInt)

  def trim(s:Int,e:Int):Future[Boolean] =
    redisClientPool.client.lTrim(bucket, s, e).map(_ => true)

//  def insert(v:V , index:Long):Future[Boolean] =
//    redisClient.lInsert(bucket, index, v).map(_ > 0)

  def push(vs:V*):Future[Boolean] =
    redisClientPool.client.lPush(bucket,vs:_*).map(_ > 0)

  def pop:Future[Option[V]] =
    redisClientPool.client.lPop(bucket)

  def length:Future[Int] =
    redisClientPool.client.lLen(bucket).map(_.toInt)

  def slice(start:Int, end:Int):Future[List[V]] =
    redisClientPool.client.lRange(bucket, start, end)
}
