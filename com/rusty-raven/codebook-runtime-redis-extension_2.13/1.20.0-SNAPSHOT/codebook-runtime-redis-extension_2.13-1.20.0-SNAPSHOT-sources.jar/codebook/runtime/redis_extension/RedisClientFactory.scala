package codebook.runtime.redis_extension

import akka.actor.ActorSystem
import codebook.runtime.redis_extension.RedisClientType.RedisClient
import com.typesafe.config.Config
import org.slf4j.LoggerFactory
import scredis.Server

object RedisClientFactory {
  import codebook.runtime.util.OptionHelper._
  import codebook.runtime.util.SafeConfig._

  private val _logger = LoggerFactory.getLogger("RedisClientFactory")

  def apply(config: Config)(implicit system:ActorSystem):Option[RedisClientPool[_ <: RedisClient]] = {
    config.getStringListOpt("redis_hosts") match {
      // Redis cluster does not support database number
      case Some(hosts) =>
        try {
          val cln = RedisClientPool(hosts.map(h => h.split(":")).map(h => Server(h(0), h(1).toInt)).toArray)
          Some(cln)
        } catch {
          case _ : Throwable =>
            _logger.error("redis_hosts invalid format")
            None
        }
      case None =>
        for {
          redis_host <- config.getStringOpt("redis_host") ~> _logger.error("redis_host not found")
          redis_port <- config.getIntOpt("redis_port") ~> _logger.error("redis_port not found")
        } yield {
          RedisClientPool(redis_host, redis_port, config.getInt("redis_db_id", 0))
        }
    }
  }
}
