package codebook.runtime.redis_extension

import codebook.runtime.redis_extension.RedisClientType.RedisClient

trait RedisLockable {
  import RedisLockFactory._

  def bucket:String
  def redisClientPool:RedisClientPool[_ <: RedisClient]

  def getLock(key: String = bucket + "$lock", lockWord: String = "lock"): RedisLock =
    redisClientPool.getLock(key, lockWord)
}
