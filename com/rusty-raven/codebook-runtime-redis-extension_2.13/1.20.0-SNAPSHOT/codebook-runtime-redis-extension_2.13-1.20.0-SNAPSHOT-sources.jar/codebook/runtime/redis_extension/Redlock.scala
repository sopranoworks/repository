package codebook.runtime.redis_extension

import codebook.runtime.redis_extension.RedisClientType.RedisClient

import scala.concurrent.{ExecutionContext, Future}

class Redlock(redisClients: Iterable[RedisClientPool[_ <: RedisClient]], key: String, lockWord:String) extends RedisLock {
  private var _locks:Option[Iterable[SingleLock]] = None
  override def lock(timeoutSec:Int)(implicit ec:ExecutionContext): Future[Boolean] = {
    val locks = redisClients.map(new SingleLock(_, key,lockWord))
    Future.sequence(locks.map(_.lock(timeoutSec))).map {
      r =>
        val n = r.count(v => v)
        if (n < (redisClients.size / 2 + 1)) {

          locks.foreach(_.unlock())

          false
        } else {
          _locks = Some(locks)
          true
        }
    }
  }

  override def unlock()(implicit ec:ExecutionContext): Future[Boolean] = {
    _locks.foreach(_.foreach(_.unlock()))
    (for {
      locks <- _locks
    } yield {
      _locks = None
      Future.sequence(locks.map(_.unlock())).map {
        _ => true
      }
    }).getOrElse {
      Future.successful(true)
    }
  }

  override def isLocked: Boolean = _locks.isDefined
}
