package codebook.runtime.redis_extension

import codebook.runtime.collection.CacheMap
import codebook.runtime.redis_extension.RedisClientType.RedisClient
import scredis.serialization.{Reader, Writer}

import scala.concurrent.{ExecutionContext, Future}

class RedisCacheMap[V](protected var _map:Map[String,V], redisMap: RedisMap[V], withLock:Boolean)(implicit ec: ExecutionContext) extends CacheMap[V] {
  private val _lock = if (withLock) redisMap.getLock() else new DummyLock
  
//  def get(key:String):Option[V] = _map.get(key)

  override def addOne(elem: (String, V)): Future[Boolean] = {
    _lock.withLock({
      redisMap.addOne(elem).map {
        r =>
          if (r) {
            _map += elem
          }
          r
      }},false)
  }

  override def addAll(map:Map[String,V]):Future[Boolean] = {
    _lock.withLock({
      redisMap.addAll(map).map {
        r =>
          if (r) {
            _map ++= map
          }
          r
      }
    },false)
  }
  
  override def subtractOne(key: String): Future[Boolean] = {
    _lock.withLock({
      redisMap.subtractOne(key).map {
        r =>
          if (r) {
            _map -= key
          }
          r
      }}, false)
  }

  override def refresh():Future[Boolean] = {
    redisMap.getAll.map {
      optMap =>
        optMap.exists {
          map =>
            _map = map
            true
        }
    }
  }
}

object RedisCacheMap {
  def apply[V](bucket:String, initialMap:Option[Map[String,V]] = None, withLock:Boolean = true)(implicit redisClientPool: RedisClientPool[_ <: RedisClient],reader:Reader[V], writer:Writer[V], ec:ExecutionContext):Future[RedisCacheMap[V]] = {
    val redisMap = new RedisMap[V](bucket)
    initialMap match {
      case Some(map) =>
        redisMap.addAll(map).flatMap {
          r =>
            if (r) {
              Future.successful(new RedisCacheMap[V](map, redisMap, withLock))
            } else {
              Future.failed(new RuntimeException("Could not set initial map"))
            }
        }
      case None =>
        redisMap.getAll.map {
          case Some(map) =>
            new RedisCacheMap[V](map, redisMap, withLock)
          case None =>
            new RedisCacheMap[V](Map.empty[String, V], redisMap, withLock)
        }
    }
  }

//  def apply[V](bucket:String, initialMap:Map[String,V], withLock:Boolean = true)(implicit redisClientPool: RedisClientPool[_ <: RedisClient],reader:Reader[V], writer:Writer[V], ec:ExecutionContext):Future[Option[RedisCacheMap[V]]] = {
//    val redisMap = new RedisMap[V](bucket)
//    redisMap.addAll(initialMap).map {
//      r =>
//        if (r) {
//          Some(new RedisCacheMap[V](initialMap, redisMap, withLock))
//        } else {
//          None
//        }
//    }
//  }

  def empty[V](bucket:String, withLock:Boolean = true)(implicit redisClientPool: RedisClientPool[_ <: RedisClient],reader:Reader[V], writer:Writer[V], ec:ExecutionContext):RedisCacheMap[V] = {
    val redisMap = new RedisMap[V](bucket)
    new RedisCacheMap[V](Map.empty[String,V], redisMap, withLock)
  }
}
