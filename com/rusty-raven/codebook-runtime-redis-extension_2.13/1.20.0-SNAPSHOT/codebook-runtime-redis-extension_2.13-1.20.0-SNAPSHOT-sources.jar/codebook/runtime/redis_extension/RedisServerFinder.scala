package codebook.runtime.redis_extension

import codebook.runtime.redis_extension.RedisClientType.RedisClient
import codebook.runtime.server.{ServerAddressBase, ServerFinder => ServerFinderBase}

import scala.concurrent.Future

trait RedisServerFinder[T <: ServerAddressBase[T]] extends ServerFinderBase[T] {
  protected def redisClient:RedisClientPool[_ <: RedisClient]

  override protected def finderName: String = "RedisFinder"

  override protected def isReadyToStartFinding: Boolean = try {
    redisClient.withBlockingClient {
      cln =>
        // check accessing the redis server
        cln.keys(key + "*")
        true
    }
  } catch {
    case _ : Throwable => false
  }

  override protected def reserveBeaconKey(sign: String): Future[Boolean] = try {
    redisClient.withClient {
      cln =>
        cln.setNX(sign,"").map {
          res =>
            if (res) {
              cln.expire(sign, 60)
              true
            } else {
              false
            }
        }
    }
  } catch {
    case e : Throwable =>
      Future.failed(e)
  }

  override protected def cancelReservationOfBeaconKey(sign:String):Unit = clearBeacon(sign)

  override protected def queryServer(): Future[List[(String,String)]] = try {
    redisClient.withClient {
      cln =>
        cln.keys(key + "*").flatMap {
          keys =>
            Future.sequence(keys.map {
              k =>
                cln.get(k).flatMap { v =>  Future.successful(v.map(a =>k->a))}

            }).flatMap {
              s => Future.successful(s.flatten.toList)
            }
        }
    }
  } catch {
    case e : Throwable =>
      Future.failed(e)
  }

  override protected def sendBeacon(sign:String): Unit =
    myAddress.foreach(addr =>
      redisClient.withClient {
        cln =>
          for {
            _ <- cln.set(sign, addr.serialize)
            _ <- cln.expire(sign, 60)
          } {}
      }
    )

  override protected def clearBeacon(sign:String):Unit = {
    redisClient.withClient (_.del(sign))
  }
}
