package codebook.runtime.redis_extension

import scala.concurrent.{ExecutionContext, Future}

trait RedisLock {
  def lock(timeoutSec:Int)(implicit ec:ExecutionContext):Future[Boolean]
  def withLock[T](f: => Future[T], ifFail: => T, timeoutSec:Int = 5)(implicit ec:ExecutionContext):Future[T] = {
    lock(timeoutSec).flatMap {
      r =>
        try {
          if (r) {
            f
          } else {
            Future.successful(ifFail)
          }
        } finally {
          unlock()
        }
    }
  }
  def unlock()(implicit ec:ExecutionContext):Future[Boolean]
  def isLocked:Boolean
}
