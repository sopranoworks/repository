package codebook.runtime.redis_extension

import codebook.runtime.server.ServerAddressBase

import scala.concurrent.{Future, Promise}
import scala.util.{Failure, Success}

trait CachedRedisServerFinder[T <: ServerAddressBase[T]] extends RedisServerFinder[T] {
  private var _cachedServers = List.empty[(String,String)]
  private var _last = 0L
  private var _working = false
  private val _first = Promise[List[(String,String)]]()

  val redisQueryInterval = 30000 // ms

  override def queryServer(): Future[List[(String, String)]] = synchronized {
    if (_last == 0) {
      // at first time

      if (!_working) {
        _working = true
        super.queryServer().onComplete {
          case Success(srvs) =>
            _cachedServers = srvs
            _last = System.currentTimeMillis()
            _working = false
            _first.success(_cachedServers)
          case _ =>
            _last = System.currentTimeMillis()
            _working = false
            _first.success(Nil)
        }
      }
      _first.future
    } else {
      if (!_working && System.currentTimeMillis() - _last >= redisQueryInterval) {
        _working = true
        super.queryServer().onComplete {
          case Success(t) =>
            _cachedServers = t
            _working = false
            _last = System.currentTimeMillis()
          case Failure(e) =>
            _working = false
            _last = System.currentTimeMillis()
        }
      }
      Future.successful(_cachedServers)
    }
  }
}
