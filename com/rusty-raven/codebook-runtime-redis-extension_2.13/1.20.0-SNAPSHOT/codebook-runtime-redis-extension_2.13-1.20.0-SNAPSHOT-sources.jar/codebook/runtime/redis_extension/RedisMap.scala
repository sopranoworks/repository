package codebook.runtime.redis_extension

import codebook.runtime.redis_extension.RedisClientType.RedisClient
import scredis.serialization.{Reader, Writer}

import scala.concurrent.{ExecutionContext, Future}

class RedisMap[V](val bucket:String)(implicit val redisClientPool:RedisClientPool[_ <: RedisClient],reader:Reader[V], writer:Writer[V], ec:ExecutionContext) extends RedisLockable {

  def get(key:String):Future[Option[V]] = {
    redisClientPool.client.hGet[V](bucket, key)
  }

  def getAll:Future[Option[Map[String,V]]] =
    redisClientPool.client.hGetAll(bucket)

  def addOne(elem:(String,V)):Future[Boolean] = {
    redisClientPool.client.hSet(bucket, elem._1, elem._2)
  }

  def addAll(map:Map[String,V]):Future[Boolean] = {
    redisClientPool.client.hmSet(bucket,map).map(_ => true)
  }

  def subtractOne(key:String):Future[Boolean] = {
    redisClientPool.client.hDel(bucket, key).map (_ > 0)
  }

  def += (elem:(String,V)):Future[Boolean] =
    addOne(elem)

  def -= (key:String):Future[Boolean] =
    subtractOne(key)
}
