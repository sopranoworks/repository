package codebook.runtime.redis_extension

import akka.actor.ActorSystem
import codebook.runtime.redis_extension.RedisClientType.RedisClient
import scredis._
import scredis.commands._

import scala.concurrent.Await
import scala.concurrent.duration.Duration

object RedisClientType {
  type RedisClient = HashCommands
    with HyperLogLogCommands
    with KeyCommands
    with ListCommands
    with PubSubCommands
    with ScriptingCommands
    with SetCommands
    with SortedSetCommands
    with StringCommands
}

class RedisClientPool[CLN <: /*HashCommands with HyperLogLogCommands with KeyCommands with ListCommands with ScriptingCommands with SetCommands with SortedSetCommands with StringCommands*/RedisClient](val client :CLN)(implicit system:ActorSystem) {
//  private val client:Client = Client(host,port,database = database)
//  private val client:T = RedisCluster()

  case class BlockingClientWrapper(client: CLN) {
    def setnx(key:String, v:String)(implicit d:Duration = Duration.Inf):Boolean = {
      Await.result(client.setNX(key,v),d)
    }

    def expire(key:String, t:Int)(implicit d:Duration = Duration.Inf):Boolean = {
      Await.result(client.expire(key,t), d)
    }

    def keys(key:String)(implicit d:Duration = Duration.Inf):Set[String]/*Option[List[Option[String]]]*/ = {
      Await.result(client.keys(key),d)
    }

    def set(key:String, v:String)(implicit d:Duration = Duration.Inf):Boolean = {
      Await.result(client.set(key,v),d)
    }

    def get(key:String)(implicit d:Duration = Duration.Inf):Option[String] = {
      Await.result(client.get(key), d)
    }
    def del(keys:String*):Unit = {
      client.del(keys:_*)
    }
  }

  def withBlockingClient[T](f:BlockingClientWrapper => T): T = {
    f(BlockingClientWrapper(client))
  }


  def withClient[T](f:CLN => T): T = {
    f(client)
  }
}

object RedisClientPool {
  def apply(host:String,port:Int,database:Int)(implicit system:ActorSystem):RedisClientPool[Redis] =
    new RedisClientPool(Redis(host,port,database = database))
  def apply(servers:Array[Server])(implicit system:ActorSystem):RedisClientPool[RedisCluster] =
    new RedisClientPool(RedisCluster(servers))
}
