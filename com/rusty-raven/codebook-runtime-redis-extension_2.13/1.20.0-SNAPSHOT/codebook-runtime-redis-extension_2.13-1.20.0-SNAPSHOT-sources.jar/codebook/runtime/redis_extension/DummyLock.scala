package codebook.runtime.redis_extension
import scala.concurrent.{ExecutionContext, Future}

class DummyLock extends RedisLock {
  private var _lock = false

  override def lock(timeoutSec: Int)(implicit ec: ExecutionContext): Future[Boolean] = {
    _lock = true
    Future.successful(true)
  }

  override def unlock()(implicit ec: ExecutionContext): Future[Boolean] = {
    Future.successful(true)
  }

  override def isLocked: Boolean = _lock
}
