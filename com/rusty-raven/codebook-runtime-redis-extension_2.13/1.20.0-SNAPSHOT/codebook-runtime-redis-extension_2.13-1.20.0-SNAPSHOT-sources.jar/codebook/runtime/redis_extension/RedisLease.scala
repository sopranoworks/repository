package codebook.runtime.redis_extension

import akka.coordination.lease.LeaseSettings
import akka.coordination.lease.scaladsl.Lease

import scala.concurrent.Future

class RedisLease(settings: LeaseSettings) extends Lease(settings) {
  override def acquire(): Future[Boolean] = ???

  override def acquire(leaseLostCallback: Option[Throwable] => Unit): Future[Boolean] = ???

  override def release(): Future[Boolean] = ???

  override def checkLease(): Boolean = ???
}
