package codebook.runtime.redis_extension

case class RedisHost(host:String,port:Int,database:Int)
