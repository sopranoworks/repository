package codebook.runtime.redis_extension

import akka.actor.ActorRef
import scredis.PubSubMessage

object PubSubHandler {
  def handler(actorRef: ActorRef):Function[PubSubMessage, Unit] = {
    case m: PubSubMessage.Subscribe => actorRef ! m
    case m: PubSubMessage.Message => actorRef ! m
    case m: PubSubMessage.Unsubscribe => actorRef ! m
    case m: PubSubMessage.PSubscribe => actorRef ! m
    case m: PubSubMessage.PMessage => actorRef ! m
    case m: PubSubMessage.PUnsubscribe => actorRef ! m
    case e: PubSubMessage.Error => actorRef ! e
  }
}
