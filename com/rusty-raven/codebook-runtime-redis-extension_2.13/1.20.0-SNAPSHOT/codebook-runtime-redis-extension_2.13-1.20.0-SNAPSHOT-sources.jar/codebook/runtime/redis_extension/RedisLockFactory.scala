package codebook.runtime.redis_extension

import codebook.runtime.redis_extension.RedisClientType.RedisClient
import scredis.{Client, RedisCluster}

object RedisLockFactory {
  trait LockFactory {
    def getLock(key:String, lockWord:String):RedisLock
  }
  implicit class SingleLockFactory(clientPool: RedisClientPool[_ <: RedisClient]) extends LockFactory {
    override def getLock(key: String, lockWord:String = "lock"): RedisLock = new SingleLock(clientPool, key, lockWord)
  }
//  implicit class RedlockFactory(redisCluster: RedisCluster) extends LockFactory {
//    override def getLock(key: String, lockWord:String = "lock"): RedisLock = new SingleLock(redisCluster, key, lockWord)
//  }
}
