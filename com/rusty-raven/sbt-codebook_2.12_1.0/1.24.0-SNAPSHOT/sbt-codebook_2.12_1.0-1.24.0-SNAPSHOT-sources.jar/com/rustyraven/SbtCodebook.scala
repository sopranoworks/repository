package com.rustyraven

import sbt.{Def, *}
import Keys.*
import com.rustyraven.codebook.{GeneratorOptions, ProtocolGenerator}
import sbt.plugins.JvmPlugin
import sbt.complete.DefaultParsers.*
import sbt.internal.io.Source

object CodebookPlugin extends AutoPlugin {
  val Codebook = config("codebook")

  object autoImport {
    val codebookGenerate = TaskKey[Seq[File]]("generate")
    val withDocument = SettingKey[Boolean]("generate document")
    val withTestClient = SettingKey[Boolean]("generate with TestClient code")
    val testDirectory = SettingKey[File]("test directory")
    val withTest = SettingKey[Boolean]("generate test code")
    val documentSourceDir = SettingKey[String]("document source directory")
    val documentFormat = SettingKey[String]("document format")
    val clientLanguage = SettingKey[String]("client language")
    val skeleton = InputKey[Unit]("skeleton")
    val document = InputKey[Unit]("document")
    val clientCode = InputKey[Unit]("clientCode")
    val migration = TaskKey[Unit]("migration")
    val info = TaskKey[Unit]("info")
    val help = inputKey[Unit]("help")
  }

  import autoImport._

  private val codebookBuildDependency = SettingKey[ModuleID]("build dependency")

  /*
    http://stackoverflow.com/questions/25158287/how-do-i-modify-sourcegenerators-in-compile-from-an-autoplugin
    The problem was that the JVM plugin resets the sourceGenerators setting. The solution is just to add:
   */
  override def requires = JvmPlugin

  override lazy val projectSettings = inConfig(Codebook)(Seq(
    sourceDirectory := (Compile / sourceDirectory).value / "codebook",
    scalaSource := (Compile / sourceManaged).value / "codebook",
    codebookGenerate := generatorTask.value,
    skeleton := skeletonTask.evaluated,
    document := documentTask.evaluated,
    clientCode := clientCodeTask.evaluated,
    migration := migrationTask.value,
    info := infoTask.value,
    help := helpTask.evaluated,
  )) ++ Seq(
    withDocument := false,
    withTestClient := false,
    testDirectory := (Compile / sourceManaged).value / "test",
    withTest := false,
    documentSourceDir := "docsrc",
    documentFormat := "sphinx",
    clientLanguage := "csharp",

    ivyConfigurations += Codebook,
    Compile / managedSourceDirectories += (Codebook / scalaSource).value,
    Compile / sourceGenerators += (Codebook / codebookGenerate).taskValue,
    watchSources += new Source(sourceDirectory.value, "*.cb", HiddenFileFilter),
    cleanFiles += (Codebook / scalaSource).value
  )

  def generatorTask:Def.Initialize[Task[Seq[File]]] = Def.task {
    val refs = referenceFiles.value
    val cachedCompile = FileFunction.cached(streams.value.cacheDirectory / "codebook", FilesInfo.lastModified, FilesInfo.exists) {
      src:Set[File] =>
        val res = ProtocolGenerator.generate(src,
          refs,
          (Codebook / scalaSource).value,
          "scala",
          testCodeDir = if (withTest.value) Some(testDirectory.value) else None,
          documentBaseDir = None,
          withClientCode = withTestClient.value,
          withServerCode = false,
          withDocument = withDocument.value,withServerSkeleton = false)
        if (src.nonEmpty && res.isEmpty) sys.error("codebook generation failed")
        res
    }
    cachedCompile(((Codebook / sourceDirectory).value ** "*.cb").get.toSet).toSeq
  }

  def skeletonTask:Def.Initialize[InputTask[Unit]] = Def.inputTask {
    val args = spaceDelimited("<arg>").parsed
    val category = args.length match {
      case 0 =>
        None
      case _ =>
        Some(args.head)
    }
    val _sources = (sourceDirectory map (path => (path ** "*.cb").get)).value.toSet
    val refs = referenceFiles.value
    ProtocolGenerator.generate(
      _sources,
      refs,
      new File(baseDirectory.value,"skeleton"),
      "scala",
      testCodeDir = None,
      documentBaseDir = None,
      opts = GeneratorOptions(false, false, category.forall(_ => false), true, category))
  }

  def documentTask:Def.Initialize[InputTask[Unit]] = Def.inputTask {
    val _sources = (sourceDirectory map (path => (path ** "*.cb").get)).value.toSet
    val refs = referenceFiles.value
    val args = spaceDelimited("<format>").parsed
    val lang = args.length match {
      case 0 =>
        documentFormat.value
      case _ =>
        args.head
    }
    ProtocolGenerator.generate(
      _sources,
      refs,
      new File(baseDirectory.value,documentSourceDir.value),
      lang,
      None,
      None,
      GeneratorOptions())
  }

  def clientCodeTask:Def.Initialize[InputTask[Unit]] = Def.inputTask {
    val args = spaceDelimited("<language>").parsed
    val lang = args.length match {
      case 0 =>
        clientLanguage.value
      case _ =>
        args.head
    }
    val _sources = (sourceDirectory map (path => (path ** "*.cb").get)).value.toSet
    val refs = referenceFiles.value
    ProtocolGenerator.generate(
      _sources,
      refs,
      new File(baseDirectory.value,s"clientCode/$lang"),
      sourceGeneratorType = lang,
      testCodeDir = if (withTest.value) Some(new File(baseDirectory.value,s"clientTest/$lang")) else None,
      documentBaseDir = Some(new File(baseDirectory.value, documentSourceDir.value)),
      opts = GeneratorOptions(withClientCode = true, withDocument = true))
  }

  def migrationTask:Def.Initialize[Task[Unit]] = Def.task {
    val _sources = (sourceDirectory map (path => (path ** "*.cb").get)).value.toSet
    val refs = referenceFiles.value
    ProtocolGenerator.generate(
      _sources,
      refs,
      new File(baseDirectory.value,"src/main/migrations"),
      "liquibase",
      None,
      None,
      GeneratorOptions())
  }

  private def flattenTasks[A](tasks: Seq[Def.Initialize[Task[A]]]): Def.Initialize[Task[List[A]]] =
    tasks.toList match {
      case Nil => Def.task { Nil }
      case x :: xs => Def.taskDyn { flattenTasks(xs) map (x.value :: _) }
    }
  
  private def depProjects: Def.Initialize[Task[List[Set[File]]]] = Def.taskDyn {
    val pdeps = projectDependencies.value
    val projects = loadedBuild.value.allProjectRefs.map(_._1)
    val fss = projects.map {
      projectRef =>
        Def.taskDyn {
          val pid = (projectRef / projectID).value
          val fs = if (pdeps.exists(mid => mid.name == pid.name)) {
            val srs = (projectRef / sourceDirectory).map(path => (path ** "*.cb").get).value.toSet
            srs
          } else {
            Set.empty[File]
          }
          Def.task {
            fs
          }
        }
    }
    flattenTasks(fss)
  }

  private def referenceFiles: Def.Initialize[Task[Set[File]]] = Def.task {
    depProjects.value.reduce(_ ++ _)
  }

  def infoTask:Def.Initialize[Task[Unit]] = Def.task {
    val r = referenceFiles.value
    println(r)
  }

  def helpTask:Def.Initialize[InputTask[Unit]] = Def.inputTask {
    println("help")
    println("  generate   : generate code")
    println("  skeleton   : generate skeleton code")
    println("  document   : generate document")
    println("  clientCode : generate client code")
    println("  migration  : generate migration code")
    println("  info       : show reference files")
    println("  help       : show this message")
  }
}
