package codebook.runtime.mongodb_extension

import org.mongodb.scala.{Document, MongoCollection}

trait MongoCollectionHolder {
  def collection:MongoCollection[Document]
}
