package codebook.runtime.mongodb_extension

import akka.util.ByteString
import codebook.runtime.protocol.ByteStringSerializable
import codebook.runtime.util.ByteStringReader
import org.mongodb.scala.bson.ObjectId

object ObjectIdHelper {
  implicit class ObjectIdByteStringSerializable(oid:ObjectId) extends ByteStringSerializable {
    override def toByteString: ByteString = {
      ByteString(oid.toByteArray)
    }
  }
  object ObjectId {
    def apply(reader:ByteStringReader):ObjectId =
      new ObjectId(reader.readBytes(12).toArray)
  }
}
