package codebook.runtime.mongodb_extension

import org.mongodb.scala.bson.BsonObjectId
import org.mongodb.scala.model.Filters.{and, equal, lt, or}
import org.mongodb.scala.result.UpdateResult
import org.mongodb.scala.{Document, MongoCollection}

import scala.concurrent.{ExecutionContext, Future}

trait MongoHelper {
  val MAX_RETRY_COUNT = 3
  val TRANSACTION_RETRY_INTERVAL = 100
  val MAX_TRANSACTION_DURATION_MILLS:Long = 5000

  object UpdateFailure extends Throwable

  implicit def holderToCollection(holder: MongoCollectionHolder):MongoCollection[Document] = holder.collection

  def retry[T](f: => Future[T], retries: Int = MAX_RETRY_COUNT)(implicit ec: ExecutionContext): Future[T] = {
    f recoverWith {
      case _ if retries > 0 =>
        Thread.sleep(TRANSACTION_RETRY_INTERVAL)
        retry(f, retries - 1)
    }
  }

  private def writeLock(coll:MongoCollection[Document], lockerId:BsonObjectId, collectionId:Long, tm:Long):Future[Document] =
    coll.findOneAndUpdate(
      and(equal(fieldName = "_id", value = collectionId),or(equal(fieldName = "lockerId", value = null),or(lt(fieldName = "lockerLimit", value = tm), equal(fieldName = "lockerLimit", value = null)))),
      Document("$set" -> Document("lockerId" -> lockerId, "lockerLimit" -> (tm + MAX_TRANSACTION_DURATION_MILLS)))
    ).toFuture()

  private def writeBack(coll:MongoCollection[Document], lockerId:BsonObjectId, collectionId:Long, updatedDoc:Document = Document())(implicit ec:ExecutionContext): Future[UpdateResult] =
    coll.updateOne(and(equal(fieldName = "_id", value = collectionId), equal(fieldName = "lockerId", value = lockerId)), Document("$set" -> (updatedDoc ++ Document("lockerId"->None))) ).toFuture().flatMap {
      res =>
        if (res.getModifiedCount == 1) Future.successful(res) else Future.failed(UpdateFailure)
    }

  def execTransactiveAction[T](coll:MongoCollection[Document],collectionId:Long, action:Document => (T,Option[Document]))(implicit /*connector: MongoConnector, */ec:ExecutionContext):Future[T] = try {
    val lock = BsonObjectId()
    val tm = System.currentTimeMillis()

    (for {
      doc <- retry(writeLock(coll, lock, collectionId, tm))
    } yield {
      action(doc) match {
        case (res,Some(updatedDoc)) =>
          writeBack(coll, lock, collectionId, updatedDoc).flatMap {
            updateRes =>
              if (updateRes.getModifiedCount == 1) {
                Future.successful(res)
              } else
                Future.failed(UpdateFailure)
          }
        case (res,None) =>
          writeBack(coll, lock, collectionId).flatMap(_ => Future.successful(res))
      }
    }).flatten
  } catch {
    case e : Throwable =>
      Future.failed(e)
  }

  def execMultiTransactiveAction[T](targets:List[(MongoCollection[Document], Long)], action:List[Document] => (T,Option[List[Document]]))(implicit /*connector: MongoConnector, */ec:ExecutionContext):Future[T] = try {
    val lock = BsonObjectId()
    val tm = System.currentTimeMillis()

    retry(Future.sequence( targets.map {
      case (coll, collectionId) =>
        retry(writeLock(coll, lock, collectionId, tm))
    }).recoverWith {
      case e =>
        targets.foreach {
          case (coll, collectionId) =>
            writeBack(coll, lock, collectionId)
        }
        Future.failed(e)
    }).flatMap {
      list =>
        action(list) match {
          case (res, Some(list)) =>
            Future.sequence(targets.zip(list).map {
              case ((coll,collectionId),doc) =>
                writeBack(coll, lock, collectionId, doc)
            }).map {
              _ => res
            }
          case (res,None) =>
            Future.sequence(targets.map {
              case (coll,collectionId) => writeBack(coll, lock, collectionId)
            }).flatMap {
              _ => Future.successful(res)
            }
        }
    }
  } catch {
    case e : Throwable =>
      Future.failed(e)
  }
}
