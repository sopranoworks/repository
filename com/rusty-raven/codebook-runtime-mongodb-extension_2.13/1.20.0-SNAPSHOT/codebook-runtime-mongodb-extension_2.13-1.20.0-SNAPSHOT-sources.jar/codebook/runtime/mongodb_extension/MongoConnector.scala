package codebook.runtime.mongodb_extension

import org.mongodb.scala._

trait MongoConnector {
  private var _client: Option[MongoClient] = None

  def databaseName:String

  def client : Option[MongoClient] = _client

  def database: Option[MongoDatabase] = client.map(_.getDatabase(databaseName))

  def connect(host:String):Unit = {
    if (_client.isEmpty) {
      _client = Some(MongoClient("mongodb://" + host))
    }
  }

  def disconnect():Unit = {
    _client.foreach {
      cln =>
        cln.close()
        _client = None
    }
  }
}
