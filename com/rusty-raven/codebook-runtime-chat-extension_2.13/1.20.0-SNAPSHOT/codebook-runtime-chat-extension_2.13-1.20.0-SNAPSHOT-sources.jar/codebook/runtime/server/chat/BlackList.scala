package codebook.runtime.server.chat

import scala.concurrent.{ExecutionContext, Future}

trait BlackList {
  def check(uid:Long):Boolean
  def add(uid:Long):Boolean
  def remove(uid:Long):Boolean
}

trait BlackListFactory {
  def apply(uid:Long)(implicit ec: ExecutionContext):Future[Option[BlackList]]
}

object DummyBlackListFactory extends BlackListFactory {
  override def apply(uid: Long)(implicit ec: ExecutionContext): Future[Option[BlackList]] = Future.successful(None)
}
