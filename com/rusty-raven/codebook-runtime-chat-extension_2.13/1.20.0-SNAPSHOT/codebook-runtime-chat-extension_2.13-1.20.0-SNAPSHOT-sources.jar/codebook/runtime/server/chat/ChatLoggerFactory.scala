package codebook.runtime.server.chat

import akka.actor.{ActorRef, ActorSystem}
import akka.routing.{ActorRefRoutee, RoundRobinRoutingLogic, Router}
import codebook.runtime.util.HasAkkaConfig

trait ChatLoggerFactory extends HasAkkaConfig {
  def numRoutee:Int

  def createChatLoggerRouter(system:ActorSystem):Router = {
    val routees = Vector.fill(numRoutee)(ActorRefRoutee(createChatLogger(system)))
    Router(RoundRobinRoutingLogic(), routees)
  }
  def chatLoggerName:String = "chat_logger"
  def createChatLogger(system:ActorSystem):ActorRef
}
