package codebook.runtime.server.chat

import akka.actor.ActorRef
import akka.util.ByteString
import codebook.runtime.util.UIDPublisher
import org.slf4j.{Logger, LoggerFactory}

class RoomLedger[CR <: ChatRoom](uidPublisher: UIDPublisher, roomFactory:RoomFactory[CR]) {
//  import RoomKeeper._
  
  private var _chatRooms = Map.empty[Long,CR]
  private var _ownerToRooms = Map.empty[Long,Set[CR]]
  protected val _logger: Logger = LoggerFactory.getLogger("ChatRoomGuestBook")

  protected def addToOwner(owner: Long, cr: CR): Unit =
    _ownerToRooms.get(owner) match {
      case Some(rooms) =>
        _ownerToRooms += owner -> (rooms + cr)
      case None =>
        _ownerToRooms += owner -> Set(cr)
    }

  def processCreate(owner: Long, roomType: Int, addOwner: Boolean, exchg: ActorRef)/*(implicit context:RoomKeeperContext)*/: Option[Long] = {
    val roomId = uidPublisher.safePublish
    roomFactory.createRoom(roomId, roomType, owner, roomFactory.initialRoomSizeFor(roomType)).map {
      cr =>
        cr.postCreate(exchg)
        _chatRooms += roomId -> cr

        addToOwner(owner, cr)

        if (addOwner) {
          cr.addMember(owner, exchg)
        }
        roomId
    }
  }

  protected def removeFromOwner(owner: Long, roomId: Long): Unit = {
    _ownerToRooms.get(owner).foreach(
      rooms =>
        _ownerToRooms += owner -> rooms.filterNot(_.roomId == roomId)
    )
  }

  def processDestroy(roomId: Long, cr: CR, by: Long, exchg: ActorRef)/*(implicit context:RoomKeeperContext)*/: Boolean = {
    cr.preDestroy(exchg)
    val owner = cr.owner
    if (roomFactory.destroyRoom(cr, by)) {
      _chatRooms -= roomId
      removeFromOwner(owner, roomId)
      true
    } else false
  }

  def createChatRoom(owner: Long, roomType: Int, addOwner: Boolean, exchg: ActorRef)/*(implicit context:RoomKeeperContext)*/: Option[Long] = synchronized {
    processCreate(owner, roomType, addOwner, exchg)
  }

  def queryChatRoom(owner: Long, roomType: Int, createIfNotExists: Boolean, addOwner: Boolean, exchg: ActorRef)/*(implicit context:RoomKeeperContext)*/: Option[Long] = synchronized {
    _ownerToRooms.get(owner).flatMap(_.find(_.roomType == roomType).map(_.roomId)).orElse {
      _logger.info(s"Chat Room for owner=$owner, roomType=$roomType does not exist")
      if (createIfNotExists) {
        _logger.info(s"creating ...")
        processCreate(owner, roomType, addOwner, exchg)
      } else None
    }
  }

  def destroyChatRoom(roomId: Long, by: Long, exchg: ActorRef)/*(implicit context:RoomKeeperContext)*/: Boolean = synchronized {
    _chatRooms.get(roomId).exists {
      cr =>
        cr.synchronized {
          processDestroy(roomId, cr, by, exchg)
        }
    }
  }

  def joinChatRoom(roomId: Long, user: Long, exchg: ActorRef)/*(implicit context:RoomKeeperContext)*/: Boolean =
    _chatRooms.get(roomId).exists {
      cr =>
        cr.synchronized {
          cr.addMember(user, exchg)
        }
    }

  def exitChatRoom(roomId: Long, op: Long, user: Long, exchg: ActorRef)/*(implicit context:RoomKeeperContext)*/: Boolean =
    _chatRooms.get(roomId).exists {
      cr =>
        cr.synchronized {
          val oldOwner = cr.owner
          cr.removeMember(op, user, exchg) match {
            case Some(keep) =>
              if (!keep) {
                processDestroy(roomId, cr, -1, exchg)
              } else {
                val newOwner = cr.owner
                if (newOwner != oldOwner) {
                  synchronized {
                    removeFromOwner(oldOwner, roomId)
                    addToOwner(newOwner, cr)
                  }
                }
              }
              true
            case _ =>
              false
          }
        }
    }

  def chatRoomOf(roomId: Long): Option[CR] =
    _chatRooms.get(roomId)

  def updateRoom(roomRaw: ByteString)/*(implicit context:RoomKeeperContext)*/: Unit = {
    roomFactory.decode(roomRaw).foreach {
      room =>
        _chatRooms.get(room.roomId).foreach {
          old =>
            _chatRooms += room.roomId -> room
            _ownerToRooms.get(old.owner).foreach {
              set =>
                val up = set - old
                if (up.isEmpty) {
                  _ownerToRooms -= old.owner
                } else {
                  _ownerToRooms += old.owner -> up
                }
            }
            _ownerToRooms.get(room.owner) match {
              case Some(set) =>
                _ownerToRooms += room.owner -> (set + room)
              case None =>
                _ownerToRooms += room.owner -> Set(room)
            }
        }
    }
  }
}
