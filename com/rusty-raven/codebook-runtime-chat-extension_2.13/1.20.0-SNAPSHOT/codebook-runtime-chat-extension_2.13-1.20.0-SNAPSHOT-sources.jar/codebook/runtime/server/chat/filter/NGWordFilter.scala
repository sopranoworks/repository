package codebook.runtime.server.chat.filter

class NGWordFilter extends ChatFilter {
  private trait NgWordNodeLogic {
    private var _children:Map[Char,NgWordNode] = Map.empty
    private var _hasTerm:Boolean = false

    def addWord(word:Array[Char],index:Int):Unit = {
      if (word.length > index) {
        val c = word(index)
        _children.getOrElse(c, {
          val child = NgWordNode(c)
          _children += c -> child
          child
        }).addWord(word,index + 1)
      } else {
        _hasTerm = true
      }
    }

    def where():String = "[root]"

    def findWordIn(word:Array[Char],index:Int,depth:Int = 0):Int = {
      if (_children.isEmpty) {
        depth
      } else {
        if (word.length >= index + 1) {
          val r = _children.get(word(index)).map {
            child=>child.findWordIn(word,index + 1,depth + 1)
          }.getOrElse(0)
          if (r == 0 && _hasTerm) depth else r
        } else {
          if (_hasTerm) depth else 0 // not match
        }
      }
    }

    def isEmpty:Boolean = _children.isEmpty
  }

  private case class NgWordNode(c:Char) extends NgWordNodeLogic {
    override def where(): String = "" + c
  }

  private val _ngWords = new NgWordNodeLogic {}

  private var _replacementChar:Char = '?'

  def replacementChar_=(r:Char):Unit = _replacementChar = r
  def replacementChar:Char = _replacementChar

  def loadDictionary(ngWords:Iterable[String]):Unit = {
    ngWords.foreach {
      ng=>
        _ngWords.addWord(ng.toCharArray,0)
    }
  }
  
  override def filterMessage(src: String): String = {
    if (_ngWords.isEmpty) {
      src
    } else {
      val l = src.length
      var i = 0
      val arr = src.toCharArray
      var dst = ""

      while (i < l) {
        val l = _ngWords.findWordIn(arr, i)
        if (l > 0) {
          (0 until l).foreach(_ => dst += _replacementChar)
          i += l
        } else {
          dst += arr(i)
          i += 1
        }
      }
      dst
    }
  }
}
