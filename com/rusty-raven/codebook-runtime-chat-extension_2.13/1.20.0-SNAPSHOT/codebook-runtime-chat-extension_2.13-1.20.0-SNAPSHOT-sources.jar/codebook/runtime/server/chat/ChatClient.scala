/**
  * codebook.runtime.server.chat.ChatClient
  *
  * Copyright (c) 2016-2019 Osamu Takahashi
  * Copyright (c) 2016-2019 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server.chat

import akka.actor.{Actor, ActorLogging, ActorRef, ActorSystem, Props}
import akka.cluster.Cluster
import akka.pattern.ask
import codebook.runtime.protocol.chat._
import codebook.runtime.server.{ClusterManager, ClusterService, ClusterServiceConnector, UserServiceActorPool}
import codebook.runtime.util.HasAkkaConfig
import org.slf4j.LoggerFactory

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success}

class ChatClient(pool:UserServiceActorPool,blackListFactory: BlackListFactory = DummyBlackListFactory,internalRouting:Boolean = true) extends ClusterService with HasAkkaConfig {
  private val chatPort = new ClusterServiceConnector {
    override def path: String = "/user/" + ChatExchange.handlerName

    override def useRoles: Set[String] = Set(ChatExchange.roleIdentifier)

    override def name: String = "ChatPort"
  }

  private val _logger = LoggerFactory.getLogger("ChatClient")
  private var _worker:Option[ActorRef] = None
  private var _lastMessageId:Long = 1

  def cx:Option[ActorRef] = chatPort()

  private def messageId:Long = synchronized {
    val r = _lastMessageId
    _lastMessageId += 1
    r
  }

  def sendDirectMessage(from:Long,to:Set[Long],msg:String,messageType:Byte = 0):Boolean =
    cx match {
      case Some(port) =>
        port ! DirectMessage(messageId, from, to, StringTrailer(msg), messageType)
        true
      case None =>
        _logger.warn(s"ChatPortFinder must start first!")
        false
    }

  def sendAreaMessage(from:Long,areaId:Int,msg:String,radiusLevel:Byte):Boolean =
    cx match {
      case Some(port) =>
        port ! AreaMessage(messageId, from, areaId, StringTrailer(msg), radiusLevel)
        true
      case None =>
        _logger.warn(s"ChatPortFinder must start first!")
        false
    }

  def sendRoomMessage(roomId:Long, from:Long, msg:String, messageType:Byte = 0):Boolean =
    cx match {
      case Some(port) =>
        port ! RoomMessage(messageId, roomId,from,StringTrailer(msg),messageType = messageType)
        true
      case None =>
        _logger.warn(s"ChatPortFinder must start first!")
        false
    }

  def sendDirectMessageTrailer(from:Long,to:Set[Long],trailer:ChatMessageTrailer,messageType:Byte = 0):Boolean =
    cx match {
      case Some(port) =>
        port ! DirectMessage(messageId, from, to, trailer, messageType)
        true
      case None =>
        _logger.warn(s"ChatPortFinder must start first!")
        false
    }

  def sendAreaMessageTrailer(from:Long,areaId:Int,trailer:ChatMessageTrailer,radiusLevel:Byte):Boolean =
    cx match {
      case Some(port) =>
        port ! AreaMessage(messageId, from, areaId, trailer, radiusLevel)
        true
      case None =>
        _logger.warn(s"ChatPortFinder must start first!")
        false
    }

  def sendRoomMessageTrailer(roomId:Long, from:Long, trailer:ChatMessageTrailer, messageType:Byte = 0):Boolean =
    cx match {
      case Some(port) =>
        port ! RoomMessage(messageId, roomId,from,trailer,messageType = messageType)
        true
      case None =>
        _logger.warn(s"ChatPortFinder must start first!")
        false
    }

  def sendSingleChatMessage(msg:SingleTargetChatMessage)(implicit ec:ExecutionContext):Future[ChatTransportStatus.Value] =
    cx match {
      case Some(port) =>
        blackListFactory(msg.from).flatMap {
          optBl =>
            optBl.flatMap(bl => if (bl.check(msg.to)) None else Some(false)) match {
              case Some(_) =>
                Future.successful(ChatTransportStatus.BlackListedInSender)
              case None =>
                import codebook.runtime.util.TimeLimits.timeout15s._

                (if (internalRouting && pool.contains(msg.to)) {
                  _worker
                } else None).getOrElse(port)
                  .ask(msg).mapTo[MessageAck].map(ack => ChatTransportStatus(ack.result))
            }
        }
      case None =>
        _logger.warn(s"ChatPortFinder must start first!")
        Future.successful(ChatTransportStatus.TransportError)
    }

  /**
    * Send Single Direct Message to a user
    *
    * @param from from user id
    * @param to destination user id
    * @param trailer message trailer
    * @param messageType user defined message type id
    * @param ec execute context
    * @return future response of transporting
    */
  def sendSingleDirectMessage(from:Long, to:Long, trailer:ChatMessageTrailer, messageType:Byte = 0)(implicit ec:ExecutionContext):Future[ChatTransportStatus.Value] =
    sendSingleChatMessage(SingleDirectMessage(messageId, from, to, trailer, messageType))


  /**
    * Send Single Direct Message to a user who within the same area
    * 
    * @param from from user id
    * @param to destination user id
    * @param areaId target area id
    * @param trailer message trailer
    * @param radiusLevel radius level(if <0, dont care)
    * @param ec execute context
    * @return future response of transporting
    */
  def sendSingleAreaMessage(from:Long, to:Long, areaId:Int, trailer:ChatMessageTrailer, radiusLevel:Byte)(implicit ec:ExecutionContext):Future[ChatTransportStatus.Value] =
    sendSingleChatMessage(SingleAreaMessage(messageId, from, to, areaId, trailer, radiusLevel))


  private class Worker extends Actor with ActorLogging {
    import codebook.runtime.protocol.chat.ChatTransportStatus._

    def receive: Receive = {
      case msg:SingleTargetChatMessage =>
        pool(msg.to) match {
          case Some(actor) =>
            import context.dispatcher
            val from = sender()

            blackListFactory(msg.to).onComplete {
              case Success(Some(bl)) =>
                if (bl.check(msg.from)) {
                  log.info("=== Deliver SingleTargetChatMessage")
                  actor.forward(msg)
                  from ! msg.toAck(DestinationReceived)
                } else {
                  log.info(s"A message from ${msg.from} received, but blacklisted by ${msg.to}")
                  from ! msg.toAck(BlackListedInReceiver)
                }
              case Failure(_) | Success(None) =>
                log.info(s"=== Deliver SingleTargetChatMessage wo BL:$msg")
                actor.forward(msg)
                from ! msg.toAck(DestinationReceived)
            }

          case None =>
            // ERROR
        }
      case msg:MultiTargetChatMessage =>
        log.info(s"Receive ChatMessage to:${msg.to}")
        msg.to.foreach(pool(_).foreach(_ ! msg))
      case ntf:ChatRoomNotificationResponse =>
        log.info(s"Receive ChatRoomNotification $ntf to:${ntf.to}")
        ntf.to.foreach(pool(_).foreach(_ ! ntf))
    }
  }

  def startWorker()(implicit system:ActorSystem): Unit = {
    _worker = Some(system.actorOf(Props(new Worker).withDispatcher("chat-client-actor-dispatcher"), ChatClient.clientActorName))
  }

  override def startWithCluster(cluster: Cluster, manager: ClusterManager): Unit = {
    implicit val system = cluster.system
    chatPort.start()
    startWorker()
  }
}

object ChatClient extends HasAkkaConfig {
  def clientActorName:String = "ChatClient"

  override def roles: List[String] = ChatPortFinder.roleName :: Nil

  override def akkaConfig: String = ChatMessageSettings.akkaConfig +
    ChatRoomMessageSettings.akkaConfig +
"""
chat-client-actor-dispatcher {
  type = Dispatcher
  executor = "fork-join-executor"
  fork-join-executor {
    parallelism-min = 4
    parallelism-factor = 4.0
    parallelism-max = 16
  }
  throughput = 5
}
""".stripMargin
}
