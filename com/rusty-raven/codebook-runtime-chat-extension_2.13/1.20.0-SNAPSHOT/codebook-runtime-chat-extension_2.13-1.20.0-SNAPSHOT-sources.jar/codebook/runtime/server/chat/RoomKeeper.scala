package codebook.runtime.server.chat

import akka.actor.{Actor, ActorLogging, ActorRef}
import akka.util.ByteString
import codebook.runtime.protocol.ResultStatus
import codebook.runtime.protocol.chat.{ChatRoomNotificationResponse, CreateChatRoomErrorResponse, CreateChatRoomRequest, CreateChatRoomResponse, DestroyChatRoomRequest, DestroyChatRoomResponse, ExitChatRoomRequest, ExitChatRoomResponse, GetChatRoomMemberListErrorResponse, GetChatRoomMemberListRequest, GetChatRoomMemberListResponse, GetChatRoomOwnerErrorResponse, GetChatRoomOwnerRequest, GetChatRoomOwnerResponse, GetChatRoomStatusErrorResponse, GetChatRoomStatusRequest, GetChatRoomStatusResponse, JoinChatRoomRequest, JoinChatRoomResponse, KickOutFromRoomRequest, QueryChatRoomErrorResponse, QueryChatRoomRequest, QueryChatRoomResponse, UpdateRoomRequest}
import codebook.runtime.util.UIDPublisher
import org.slf4j.LoggerFactory

class RoomKeeper[CR <: ChatRoom](/*uidPublisher: UIDPublisher,roomFactory:RoomFactory[CR]*/ roomLedger: RoomLedger[CR]) extends Actor with ActorLogging {
//  private var _chatRooms = Map.empty[Long,CR]
//  private var _ownerToRooms = Map.empty[Long,Set[CR]]
//  protected val _logger = LoggerFactory.getLogger("RoomKeeper")

  import RoomKeeper._

//  implicit object RoomKeeperContext extends RoomKeeperContext
  implicit def roomKeeperContext: RoomKeeper.RoomKeeperContext = RoomKeeperContext

/*  protected def addToOwner(owner:Long,cr:CR):Unit =
    _ownerToRooms.get(owner) match {
      case Some(rooms) =>
        _ownerToRooms += owner->(rooms + cr)
      case None =>
        _ownerToRooms += owner->Set(cr)
    }

  def processCreate(owner:Long,roomType:Int,addOwner:Boolean,exchg:ActorRef):Option[Long] = {
    val roomId = uidPublisher.safePublish
    roomFactory.createRoom(roomId,roomType,owner,roomFactory.initialRoomSizeFor(roomType)).map {
      cr=>
        cr.postCreate(exchg)
        _chatRooms += roomId->cr

        addToOwner(owner,cr)

        if (addOwner) {
          cr.addMember(owner, exchg)
        }
        roomId
    }
  }

  protected def removeFromOwner(owner:Long,roomId:Long):Unit = {
    _ownerToRooms.get(owner).foreach(
      rooms=>
        _ownerToRooms += owner->rooms.filterNot(_.roomId == roomId)
    )
  }

  def processDestroy(roomId:Long,cr:CR,by:Long,exchg:ActorRef):Boolean = {
    cr.preDestroy(exchg)
    val owner = cr.owner
    if (roomFactory.destroyRoom(cr , by)) {
      _chatRooms -= roomId
      removeFromOwner(owner,roomId)
      true
    } else false
  }

  def createChatRoom(owner:Long,roomType:Int,addOwner:Boolean,exchg:ActorRef):Option[Long] = synchronized {
    processCreate(owner,roomType,addOwner,exchg)
  }

  def queryChatRoom(owner:Long,roomType:Int,createIfNotExists:Boolean,addOwner:Boolean,exchg:ActorRef):Option[Long] = synchronized {
    _ownerToRooms.get(owner).flatMap(_.find(_.roomType == roomType).map(_.roomId)).orElse {
      log.info(s"Chat Room for owner=$owner, roomType=$roomType does not exist")
      if (createIfNotExists) {
        log.info(s"creating ...")
        processCreate(owner,roomType,addOwner,exchg)
      } else None
    }
  }

  def destroyChatRoom(roomId:Long,by:Long,exchg:ActorRef):Boolean = synchronized {
    _chatRooms.get(roomId).exists {
      cr => cr.synchronized {
        processDestroy(roomId,cr,by,exchg)
      }
    }
  }

  def joinChatRoom(roomId:Long,user:Long,exchg:ActorRef):Boolean =
      _chatRooms.get(roomId).exists {
        cr =>
          cr.synchronized {
            cr.addMember(user,exchg)
          }
      }

  def exitChatRoom(roomId:Long,op:Long,user:Long,exchg:ActorRef):Boolean =
      _chatRooms.get(roomId).exists {
        cr =>
          cr.synchronized {
            val oldOwner = cr.owner
            cr.removeMember(op,user,exchg) match {
              case Some(keep) =>
                if (!keep) {
                  processDestroy(roomId, cr, -1, exchg)
                } else {
                  val newOwner = cr.owner
                  if (newOwner != oldOwner) {
                    synchronized {
                      removeFromOwner(oldOwner,roomId)
                      addToOwner(newOwner,cr)
                    }
                  }
                }
                true
              case _ =>
                false
            }
          }
      }

  def chatRoomOf(roomId:Long):Option[CR] =
      _chatRooms.get(roomId)

  def updateRoom(roomRaw:ByteString):Unit = {
    roomFactory.decode(roomRaw).foreach {
      room =>
        _chatRooms.get(room.roomId).foreach {
          old =>
            _chatRooms += room.roomId -> room
            _ownerToRooms.get(old.owner).foreach {
              set =>
                val up = set - old
                if (up.isEmpty) {
                  _ownerToRooms -= old.owner
                } else {
                  _ownerToRooms += old.owner -> up
                }
            }
            _ownerToRooms.get(room.owner) match {
              case Some(set) =>
                _ownerToRooms += room.owner -> (set + room)
              case None =>
                _ownerToRooms += room.owner -> Set(room)
            }
        }
    }
  } */

  def receive: Receive = process()

  def process():Receive = {
    case req: CreateChatRoomRequest =>
      log.info("CreateChatRoomRequest")
//      rerouteToLeader(clusterLeader, req, {
        roomLedger.createChatRoom(req.owner, req.roomType, req.addOwner, self).map {
          roomId =>
            new CreateChatRoomResponse(req.timestamp, ResultStatus.Success.id.toShort, roomId)
        }.getOrElse(new CreateChatRoomErrorResponse(req.timestamp, ResultStatus.Failure.id.toShort))
//      })

    case req: DestroyChatRoomRequest =>
      log.info("DestroyChatRoomRequest")
//      rerouteToLeader(clusterLeader, req, {
        new DestroyChatRoomResponse(req.timestamp,
          if (roomLedger.destroyChatRoom(req.roomId, req.user, self)) {
            ResultStatus.Success.id.toShort
          } else {
            ResultStatus.Failure.id.toShort
          })
//      })

    case req: QueryChatRoomRequest =>
      log.info("QueryChatRoomRequest")
//      rerouteToLeader(clusterLeader, req, {
        roomLedger.queryChatRoom(req.owner, req.roomType, req.createIfNotExists, req.addOwner, self).map {
          roomId =>
            new QueryChatRoomResponse(req.timestamp, ResultStatus.Success.id.toShort, roomId)
        }.getOrElse(new QueryChatRoomErrorResponse(req.timestamp, ResultStatus.Failure.id.toShort))
//      })

    case req: JoinChatRoomRequest =>
//      rerouteToLeader(clusterLeader, req, {
        new JoinChatRoomResponse(req.timestamp,
          if (roomLedger.joinChatRoom(req.roomId, req.user, self)) {
            log.info("JoinChatRoom Success")
            ResultStatus.Success.id.toShort
          } else {
            log.info("JoinChatRoom Failure")
            ResultStatus.Failure.id.toShort
          })
//      })

    case req: ExitChatRoomRequest =>
//      rerouteToLeader(clusterLeader, req, {
        new ExitChatRoomResponse(req.timestamp,
          if (roomLedger.exitChatRoom(req.roomId, req.user, req.user, self)) {
            ResultStatus.Success.id.toShort
          } else {
            ResultStatus.Failure.id.toShort
          })
//      })

    case req: KickOutFromRoomRequest =>
//      rerouteToLeader(clusterLeader, req, {
        new ExitChatRoomResponse(req.timestamp,
          if (roomLedger.exitChatRoom(req.roomId, req.operator, req.user, self)) {
            ResultStatus.Success.id.toShort
          } else {
            ResultStatus.Failure.id.toShort
          })
//      })

    case req: GetChatRoomStatusRequest =>
      sender() ! roomLedger.chatRoomOf(req.roomId).map {
        cr =>
          new GetChatRoomStatusResponse(req.timestamp, ResultStatus.Success.id.toShort, cr.owner, cr.members.toList)
      }.getOrElse(new GetChatRoomStatusErrorResponse(req.timestamp, ResultStatus.Failure.id.toShort))

    case req: GetChatRoomOwnerRequest =>
      sender() ! roomLedger.chatRoomOf(req.roomId).map {
        cr =>
          new GetChatRoomOwnerResponse(req.timestamp, ResultStatus.Success.id.toShort, cr.owner)
      }.getOrElse(new GetChatRoomOwnerErrorResponse(req.timestamp, ResultStatus.Failure.id.toShort))

    case req: GetChatRoomMemberListRequest =>
      sender() ! roomLedger.chatRoomOf(req.roomId).map {
        cr =>
          new GetChatRoomMemberListResponse(req.timestamp, ResultStatus.Success.id.toShort, cr.members.toList)
      }.getOrElse(new GetChatRoomMemberListErrorResponse(req.timestamp, ResultStatus.Failure.id.toShort))

//    case ntf: ChatRoomNotificationResponse =>
//      sendChatRoomNotification(agentServers, ntf).foreach(retryLater(_))

    case req: UpdateRoomRequest =>
      roomLedger.updateRoom(req.roomRaw)
  }
}

object RoomKeeper {
  val roomKeeperActorName:String = "RoomKeeper"
  class RoomKeeperContext
  object RoomKeeperContext extends RoomKeeperContext
}
