package codebook.runtime.server.chat
import akka.actor.{Actor, ActorRef, ActorSystem, Props}

object DummyChatLoggerFactory extends ChatLoggerFactory {
  private class DummyWorker extends Actor {
    def receive:Receive = {
      case _ => /* nothing to do */
    }
  }
  override def numRoutee: Int = 1

  override def createChatLogger(system: ActorSystem): ActorRef =
    system.actorOf(Props(new DummyWorker),chatLoggerName)
}
