package codebook.runtime.server.chat

import akka.actor.{ActorSystem, Address, Props}
import akka.routing.{ActorRefRoutee, BroadcastRoutingLogic, RoundRobinRoutingLogic, Router}
import codebook.runtime.protocol.UserPosition
import codebook.runtime.protocol.chat.{ChatMessageSettings, ChatRoomMessageSettings}
import codebook.runtime.server.ClusterManager
import codebook.runtime.util.AkkaConfigBuilder

trait CXCluster[D,U <: UserPosition[D],CR <: ChatRoom] extends ClusterManager {
  private var _cxSystem:Option[ActorSystem] = None
  private var _exchangers:Option[Router] = None
  private var _exchangeRouter:Option[Router] = None
  private var _chatLogger:Option[Router] = None

  val cxClusterSystemName = "CXCluster"

  def exchangers:Option[Router] = _exchangers
  def exchangerRouter:Option[Router] = _exchangeRouter

  def chatLogger:Option[Router] = _chatLogger

//  def roomKeeper:RoomKeeper[CR]
  def guestBook:RoomLedger[CR]

  def chatLoggerFactory:ChatLoggerFactory = DummyChatLoggerFactory

  val MAX_EXCHANGER = 16

  override def canBecomeALeader = true

  override def akkaConfig: String = super.akkaConfig +
    ChatMessageSettings.akkaConfig +
    ChatRoomMessageSettings.akkaConfig +
    chatLoggerFactory.akkaConfig

  def initializeWithSystemAndFinder(system:ActorSystem,finder:ChatPortFinder):Unit = {
    val chatLogger = chatLoggerFactory.createChatLoggerRouter(system)
    val routees = Vector.fill(MAX_EXCHANGER) {
      ActorRefRoutee(system.actorOf(Props(new ChatExchanger(finder, guestBook, chatLogger))))
    }
    val broadcast = Router(BroadcastRoutingLogic(), routees)
    val router = Router(RoundRobinRoutingLogic(), routees)
    _exchangers = Some(broadcast)
    _exchangeRouter = Some(router)
    _chatLogger = Some(chatLogger)
  }

  override def onLeaderChanged(newLeader: Address): Unit = {
    cluster.foreach {
      c =>
        if (c.selfAddress == newLeader) {
          
        }
    }
  }

  override def start()(implicit system: ActorSystem): Boolean = {
    if (_cxSystem.isEmpty) {
      _cxSystem = Some(system)
      val finder = new ChatPortFinder
      addService(finder)

      if (super.start()) {
        initializeWithSystemAndFinder(system,finder)
        true
      } else { false }
    } else { false }
  }

  def startWithFinder(finder:ChatPortFinder): Unit = {
    if (_cxSystem.isEmpty) {
      implicit val cxSystem = ActorSystem(cxClusterSystemName,AkkaConfigBuilder(this).toConfig)
      if (super.start()) {
        initializeWithSystemAndFinder(cxSystem,finder)
      }
    }
  }
}
