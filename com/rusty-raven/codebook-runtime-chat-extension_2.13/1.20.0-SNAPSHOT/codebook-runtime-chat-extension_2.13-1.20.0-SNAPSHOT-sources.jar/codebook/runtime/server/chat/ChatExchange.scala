/**
  * codebook.runtime.server.chat.ChatExchange
  *
  * Copyright (c) 2016-2019 Osamu Takahashi
  * Copyright (c) 2016-2019 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server.chat

import akka.actor.{ActorRef, Props}
import akka.cluster.Cluster
import codebook.runtime.protocol.chat.{ChatMessageSettings, ChatRoomMessageSettings}
import codebook.runtime.protocol._
import codebook.runtime.server.area.PositionDbDistributor
import codebook.runtime.server.{ClusterManager, ClusterService, GuestBookDistributor, ReservationDeskSerializerSettings}
import codebook.runtime.util.HasAkkaConfig
import org.slf4j.LoggerFactory

import scala.reflect.ClassTag

class ChatExchange[D : ClassTag,U <: UserPosition[D] : ClassTag,P <: PlayerPosition[D,U,P] : ClassTag,R <: RelativeUserPosition[D],CR <: ChatRoom](helper:PositionHelper[D,U,P,R],cxClusterManager:CXCluster[D,U,CR]) extends ClusterService with HasAkkaConfig{
  private val _logger = LoggerFactory.getLogger("ChatExchange")
  private val _chatPortFinder:ChatPortFinder = new ChatPortFinder
  private var _cargoHandlers:Option[ActorRef] = None

  val MAX_EXCHANGER = 16

  def cargoHandler:Option[ActorRef] = _cargoHandlers

  override def akkaConfig: String =
    ChatMessageSettings.akkaConfig +
    ChatRoomMessageSettings.akkaConfig +
    AreaMessageSettings.akkaConfig +
    ReservationDeskSerializerSettings.akkaConfig +
s"""
akka.cluster.jmx.multi-mbeans-in-same-jvm = on
"""

  override def roles: List[String] = ChatExchange.roleIdentifier :: PositionDbDistributor.receiverRole :: GuestBookDistributor.receiverRole :: Nil

  override def startWithCluster(cluster: Cluster, manager: ClusterManager): Unit = {
    _logger.info("ChatExchange is going to start with cluster")
    val system = cluster.system

    _chatPortFinder.startWithCluster(cluster,manager)

    cxClusterManager.startWithFinder(_chatPortFinder)

    for {
      broadcast <- cxClusterManager.exchangers
      router <- cxClusterManager.exchangerRouter
    } {
      _cargoHandlers = Some(system.actorOf(Props(new CargoHandler(broadcast,router,helper)),ChatExchange.handlerName))
    }
  }
}

object ChatExchange {
  def roleIdentifier = "cx"
  def handlerName = "CargoHandler"
}
