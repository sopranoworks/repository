/**
  * codebook.runtime.server.chat.ChatPortFinder
  *
  * Copyright (c) 2016-2019 Osamu Takahashi
  * Copyright (c) 2016-2019 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server.chat

import codebook.runtime.server.RoleFinder

class ChatPortFinder extends RoleFinder {
  override def roleName: String = ChatPortFinder.roleName
  override val destinationActorName: String = ChatClient.clientActorName
}

object ChatPortFinder {
  val roleName = "chatport"
}
