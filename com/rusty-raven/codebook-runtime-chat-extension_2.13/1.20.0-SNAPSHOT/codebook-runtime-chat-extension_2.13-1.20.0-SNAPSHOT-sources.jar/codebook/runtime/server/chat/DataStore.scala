package codebook.runtime.server.chat

import org.redisson.Redisson
import org.redisson.config.Config

class DataStore(configFileName:String) {
  val config = Config.fromYAML(configFileName)
  val client = Redisson.create(config)

  def uniqueId:Long = {
    val r = client.getAtomicLong("uniqueId")
    r.incrementAndGet()
  }

  


}
