/**
  * codebook.runtime.server.chat.CargoHandler
  *
  * Copyright (c) 2016-2019 Osamu Takahashi
  * Copyright (c) 2016-2019 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server.chat

import akka.actor.{Actor, ActorLogging}
import akka.routing.Router
import akka.util.ByteString
import codebook.runtime.math.Octree
import codebook.runtime.protocol.chat.{AreaOctree, ChatMessage, ChatRoomRequest, GuestBook}
import codebook.runtime.protocol._
import codebook.runtime.server.reservationdesk.DeriveGuestBookRequest
import codebook.runtime.util.ByteStringReader

import scala.reflect.ClassTag

class CargoHandler[D : ClassTag,U <: UserPosition[D] : ClassTag,P <: PlayerPosition[D,U,P],R <: RelativeUserPosition[D]](exchangersBroadcast:Router, exchangersRouter:Router, helper: PositionHelper[D,U,P,R]) extends Actor with ActorLogging {
  private def decodePositionDb(bytes:ByteString):Option[(Map[Long,U],Octree[U])] = {
    val reader = ByteStringReader(bytes)
    val l = VLong.decode(reader).toInt
    val users = 0.until(l).flatMap {
      _ =>
        helper.decodeUserPosition(reader)
    }
    for {
      octree<-Octree(users)
    } yield {
      (users.map(u => u.uid->u).toMap, octree)
    }
  }

  def receive: Receive = processMessage(posCounts = Map.empty,gbCounts = Map.empty)
  
  def processMessage(posCounts:Map[Int,Int],gbCounts:Map[Int,Int]):Receive = {
    case DeliverPositionDb(areaId,positionDbBytes) =>
      val c = posCounts.getOrElse(areaId, 0)
      if (c == 0) {
        log.info(s"Receive PositionDB from Area $areaId")
      }
      decodePositionDb(positionDbBytes).foreach {
        a =>
          exchangersBroadcast.route(new AreaOctree[D,U](areaId,a._1,a._2),sender())
      }
      context.become(processMessage(posCounts + (areaId->(if (c < 60 - 1) c + 1 else 0)),gbCounts),discardOld = true)
    case m : DeriveGuestBookRequest =>
      val c = gbCounts.getOrElse(m.nodeId, 0)
      if (c == 0) {
        log.info(s"Receive GuestBook from ${m.nodeId}")
      }
      exchangersBroadcast.route(GuestBook(m.nodeId,m.guests.toSet),sender())
      val newGbCounts = gbCounts + (m.nodeId->(if (c < 10 - 1) c + 1 else 0))
      context.become(processMessage(posCounts,newGbCounts),discardOld = true)

    case msg: ChatMessage =>
      log.info(s"Receive ChatMessage:${msg.getClass.getName}")
      exchangersRouter.route(msg,sender())

    case req: ChatRoomRequest =>
      log.info(s"Receive ChatRoomRequest:$req")
      exchangersRouter.route(req,sender())
  }
}
