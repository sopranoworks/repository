package codebook.runtime.server.chat

import akka.actor.ActorRef
import akka.util.ByteString
import codebook.runtime.protocol.{ResultStatus, VLong}
import codebook.runtime.protocol.chat.{ChatRoomNotificationResponse, ChatRoomNotificationStatus, RoomMessage, RoomMessageHistory}
import codebook.runtime.util.ByteStringHelper
import org.slf4j.LoggerFactory

class ChatRoom(val roomId:Long,var owner:Long,var maxMember:Int,val roomType:Int,private var _roomHash:Int = 0,protected var _members:Set[Long] = Set.empty) {
  protected val _logger = LoggerFactory.getLogger(s"CR[$roomId]")

  var history:List[RoomMessageHistory] = List.empty

  val MAX_MESSAGE_HISTORY = 10

  implicit def statusToId(stat:ChatRoomNotificationStatus.Value):Int = stat.id

  import codebook.runtime.protocol.ResultStatus.toShort

  def roomHash:Int = _roomHash

  def nextOwner:Long = _members.head

  def changeOwner(newOwner:Long,exchg:ActorRef):Boolean = {
    exchg ! new ChatRoomNotificationResponse(0,ResultStatus.Success,_members.toList,roomId,roomType,ChatRoomNotificationStatus.OwnerChanged,newOwner,owner)
    owner = newOwner
    _roomHash += 1
    true
  }

  def addMember(newMember:Long,exchg:ActorRef):Boolean = {
    if (_members.size < maxMember) {
      _members += newMember
      _roomHash += 1
      if (_members.size > 1) {
        exchg ! new ChatRoomNotificationResponse(0,ResultStatus.Success,_members.toList,roomId,roomType,ChatRoomNotificationStatus.PlayerJoined,newMember,0)
      }
      true
    } else {
      false
    }
  }

  /**
    * Removing a member from chat room
    * @param removedMember the member to remove from chat room
    * @param exchg exchg actor to send notification
    * @return if keep room, should return Some(true)
    */
  def removeMember(operator:Long,removedMember:Long,exchg:ActorRef):Option[Boolean] = {
    if ((operator == removedMember || operator == owner) && _members.contains(removedMember)) {
      // Send ChatRoomNotification to all members who belonging to the room before removing.
      // Specification Changed 2021/05/24
      exchg ! new ChatRoomNotificationResponse(0,ResultStatus.Success,_members.toList,roomId,roomType,
        if (operator == removedMember) ChatRoomNotificationStatus.PlayerLeave else ChatRoomNotificationStatus.PlayerKickedOut,
        operator,removedMember)
      _members -= removedMember
      _roomHash += 1

      if (_members.isEmpty) {
        Some(whenNoMember(exchg))
      } else
      if (removedMember == owner) {
        _logger.info("Owner has gone away")
        Some(whenOwnerAway(exchg) && whenMemberAway(exchg))
      } else {
        Some(whenMemberAway(exchg))
      }
    } else {
      None
    }
  }
  
  def members:Set[Long] = _members

  def postMessage(msg:RoomMessage):Unit = {
    history = (RoomMessageHistory(System.currentTimeMillis(),msg) :: history).take(MAX_MESSAGE_HISTORY)
  }

  def postCreate(exchg:ActorRef):Unit = {}

  def preDestroy(exchg:ActorRef):Unit = {
    exchg ! new ChatRoomNotificationResponse(0,ResultStatus.Success,_members.toList,roomId,roomType,ChatRoomNotificationStatus.ChatRoomDestroyed,0,0)
  }

  def whenMemberAway(exchg:ActorRef):Boolean = true

  def whenOwnerAway(exchg:ActorRef):Boolean = {
    _logger.info(s"Owner will be changed to $nextOwner")
    changeOwner(nextOwner,exchg)
  }

  def whenNoMember(exchg:ActorRef):Boolean = {
    _logger.info("No member left, going to destroy")
    false
  }

  def serialize:String =
    s"$owner/$maxMember/$roomType/$roomHash/${_members.mkString(",")}"

  def toByteString:ByteString =
    ByteStringHelper.LE.longToByteString(roomId) ++
    ByteStringHelper.LE.longToByteString(owner) ++
    ByteStringHelper.LE.intToByteString(maxMember) ++
    ByteStringHelper.LE.intToByteString(roomType) ++
    ByteStringHelper.LE.intToByteString(roomHash) ++
    members.foldLeft(VLong(members.size).toByteString) {
      case (b,l) => b ++ ByteStringHelper.LE.longToByteString(l)
    }
}
