/**
  * codebook.runtime.server.chat.ChatExchanger
  *
  * Copyright (c) 2016-2019 Osamu Takahashi
  * Copyright (c) 2016-2019 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server.chat

import akka.actor.{Actor, ActorLogging, ActorRef, Address, RootActorPath}
import akka.cluster.Cluster
import akka.dispatch.ControlMessage
import akka.pattern.ask
import akka.routing.Router
import codebook.runtime.math.{Octree, Sphere}
import codebook.runtime.protocol.{ResultStatus, UserPosition}
import codebook.runtime.protocol.chat._
import codebook.runtime.server.ClusterLeader
import codebook.runtime.util.TimeLimits._10s
import org.joda.time.DateTime

import scala.concurrent.duration.FiniteDuration
import scala.concurrent.{ExecutionContext, Future}
import scala.reflect.ClassTag
import scala.util.{Failure, Success}

class ChatExchanger[D : ClassTag,P <: UserPosition[D] : ClassTag,CR <: ChatRoom](finder: ChatPortFinder, /*roomKeeper: RoomKeeper[CR]*/ roomLedger: codebook.runtime.server.chat.RoomLedger[CR], chatLogger:Router) extends Actor with ActorLogging {
  import codebook.runtime.util.OptionHelper._
  def receive: Receive = process()

  val MAX_AREA_MESSAGE = 100
  val MAX_CACHE_DURATION_SECOND = 60
  val MAX_RETRY_COUNT = 2
  val RETRY_DURATION: FiniteDuration = _10s

  implicit val ec: ExecutionContext = context.dispatcher

  case class SetLeader(clusterLeader: ClusterLeader) extends ControlMessage

  protected def radiusLevelToRadius(level:Byte):Float = {
    100.0f
  }
  private case class AreaGuestBook(users:Map[Long,P],octree: Octree[P],lastUpdate:DateTime)
  private case class AgentGuestBook(users:Set[Long],lastUpdate:DateTime)

  private case class RetrySending(ttl:Int, msg:Any)

  private def sendMessageToAgent(agentId:Int,message:Any):Unit = {
    for {
      dest <- finder.connectorFor(agentId) ~> log.warning(s"Unknown destination agent id:$agentId")
    } {
      dest ! message
    }
  }

  private object TransportError extends Throwable

  private def sendMessageToAgentWithWaitingResult(agentId:Int,message:Any)(implicit ec: ExecutionContext):Future[MessageAck] = {
    (for {
      dest <- finder.connectorFor(agentId) ~> log.warning(s"Unknown destination agent id:$agentId")
    } yield {
      import codebook.runtime.util.TimeLimits.timeout15s._
      dest.ask(message).mapTo[MessageAck]
    }).getOrElse(Future.failed(TransportError))
  }

  private def refreshGuestBook(areaServers: Map[Int, AreaGuestBook], agentServers: Map[Int, AgentGuestBook]):(Map[Int,AreaGuestBook],Map[Int,AgentGuestBook]) = {
    val tl = DateTime.now().minusSeconds(MAX_CACHE_DURATION_SECOND)
    val newAreaServers = areaServers.filter {
      case (_,guestbook) =>
        guestbook.lastUpdate.isAfter(tl)

    }
    val newAgentServers = agentServers.filter {
      case (_,guestbook) =>
        guestbook.lastUpdate.isAfter(tl)
    }
    (newAreaServers,newAgentServers)
  }

  private def queryDestinations(agentServers:Map[Int,AgentGuestBook],to: Iterable[Long]): (Map[Int, Set[Long]],Set[Long]) = {
    var dests: Map[Int, Set[Long]] = Map.empty
    var unknown: Set[Long] = Set.empty
    to.foreach {
      u =>
        agentServers.find(a => a._2.users.contains(u)) match {
          case Some((aid, _)) =>

            val v = if (dests.contains(aid)) {
              dests(aid) + u
            } else {
              Set(u)
            }
            dests += aid -> v
          case None =>
            unknown += u
        }
    }
    if (unknown.nonEmpty) {
      log.warning(s"unknown user destination ids:${unknown.mkString(",")}")
    }
    (dests,unknown)
  }

  private def sendRoomMessage(agentServers: Map[Int, AgentGuestBook], rm: RoomMessage): Option[RoomMessage] = {
    (for {
      room <- roomLedger.chatRoomOf(rm.roomId) ~> log.warning(s"Unknown chat room id:${rm.roomId}")
    } yield {
      room.postMessage(rm)
      val to = room.members.filter(_ != rm.from)
      val (dests, unknown) = queryDestinations(agentServers, to)
      dests.foreach {
        case (agentId, users) =>
          sendMessageToAgent(agentId, RoomMessage(rm.messageId, rm.roomId, rm.from, rm.trailer, users, rm.messageType))
      }
      if (unknown.nonEmpty) Some(rm.copy(to = unknown)) else None
    }).flatten
  }
  
  private def sendDirectMessage(agentServers: Map[Int, AgentGuestBook], dm:DirectMessage): Option[DirectMessage] = {
    val (dests, unknown) = queryDestinations(agentServers, dm.to)
    dests.foreach {
      case (agentId, users) =>
        sendMessageToAgent(agentId, DirectMessage(dm.messageId, dm.from, users, dm.trailer, dm.messageType))
    }
    if (unknown.nonEmpty) Some(dm.copy(to = unknown)) else None
  }
  
  private def sendSingleDirectMessage(agentServers: Map[Int, AgentGuestBook], dm:SingleTargetChatMessage, from:ActorRef): Unit = {
    val dest = agentServers.find(a => a._2.users.contains(dm.to))
    
    dest match {
      case Some((agentId, _)) =>
        sendMessageToAgentWithWaitingResult(agentId, dm).onComplete {
          case Success(ack) =>
            if (from != null) from ! ack
          case Failure(_) =>
            if (from != null) from ! dm.toAck(ChatTransportStatus.TransportError)
        }
      case None =>
        if (from != null) from ! dm.toAck(ChatTransportStatus.UserNotFound)
    }
  }

  private def sendSingleAreaMessage(areaServers:Map[Int,AreaGuestBook], agentServers: Map[Int, AgentGuestBook], m:SingleAreaMessage, from:ActorRef): Unit = {
    (for {
      guestbook <- areaServers.get(m.areaId) ~> log.warning(s"Guestbook for ${m.areaId} not found")
      p0 <- guestbook.users.get(m.from) ~> log.warning(s"The user ${m.from} could not find in guest book ${m.areaId}")
      p1 <- guestbook.users.get(m.to) ~> log.warning(s"The user ${m.from} could not find in guest book ${m.to}")
    } yield {
      if (m.radiusLevel < 0 || {
        val radius = radiusLevelToRadius(m.radiusLevel)
        (p0.position - p1.position).length2 < radius * radius
      }) {
        sendSingleDirectMessage(agentServers, m, from)
      } else {
        if (from != null) from ! m.toAck(ChatTransportStatus.UserNotFound)
      }
    }).getOrElse {
      if (from != null) from ! m.toAck(ChatTransportStatus.UserNotFound)
    }
  }

  private def sendMessageAck(agentServers: Map[Int, AgentGuestBook], ack: MessageAck, from:ActorRef): Unit = {
    val dest = agentServers.find(a => a._2.users.contains(ack.to))

    dest match {
      case Some((agentId, _)) =>
        sendMessageToAgentWithWaitingResult(agentId, ack)
      case None =>
    }
  }
  
  private def sendChatRoomNotification(agentServers: Map[Int, AgentGuestBook], ntf: ChatRoomNotificationResponse): Option[ChatRoomNotificationResponse] = {
    val (dests, unknown) = queryDestinations(agentServers, ntf.to)
    dests.foreach {
      case (agentId, users) =>
        sendMessageToAgent(agentId, new ChatRoomNotificationResponse(ntf.timestamp, 0, users.toList, ntf.roomId, ntf.roomType, ntf.status, ntf.value, ntf.value2))
    }
    if (unknown.nonEmpty) Some(new ChatRoomNotificationResponse(ntf.timestamp, ntf.resultStatus, unknown.toList, ntf.roomId, ntf.roomType, ntf.status, ntf.value, ntf.value2)) else None
  }

  private def leader:Either[Unit,Option[Address]] = {
    val cluster = Cluster(context.system)
    cluster.state.leader.map {
      leader =>
        if (leader == cluster.selfMember.address) {
          Right(None)
        } else {
          Right(Some(leader))
        }
    }.getOrElse(Left(()))
  }

  // TODO: Implement this
  private def rerouteToLeader[T,R](clusterLeader: Option[ClusterLeader], req:T,ifLeader: => R,ifFailure: => Unit = {}):Unit =
    leader match {
      case Right(leaderAddress) =>
        leaderAddress match {
          case Some(la) =>
            clusterLeader match {
              // Known leader
              case Some(cl) if cl.address == la =>
                cl.ref.forward(req)
                
              // Unknown leader
              case _ =>
                import codebook.runtime.util.TimeLimits.timeout5s._
                context.system.actorSelection(RootActorPath(la,"/user/" + ChatExchange.handlerName)).resolveOne().onComplete {
                  case Success(ref) =>
                    ref.forward(req)
                    self ! SetLeader(ClusterLeader(la, ref))
                  case Failure(e) =>
                    ifFailure
                }
            }

          case _ =>
//            log.info(s"process as leader")
            sender().tell(ifLeader,self)
        }
      case _ =>
        // failure
        ifFailure
    }

  private def retryLater(msg:Any,ttl:Int = MAX_RETRY_COUNT):Unit =
    context.system.scheduler.scheduleOnce(RETRY_DURATION, self, RetrySending(ttl,msg))

  private def process(areaServers:Map[Int,AreaGuestBook] = Map.empty,agentServers:Map[Int,AgentGuestBook] = Map.empty, clusterLeader: Option[ClusterLeader] = None ): Receive = {
    case GuestBook(agentId,guests) =>
      context.become(process(areaServers,agentServers + (agentId->AgentGuestBook(guests,DateTime.now()))),discardOld = true)

    case m: AreaOctree[_,_] =>
      context.become(process(areaServers + (m.areaId->AreaGuestBook(m.asInstanceOf[AreaOctree[D,P]].users,m.asInstanceOf[AreaOctree[D,P]].octree,DateTime.now())),agentServers),discardOld = true)

    case dm:DirectMessage =>
      sendDirectMessage(agentServers, dm).foreach(retryLater(_))

    case AreaMessage(messageId,from,areaId,msg,radiusLevel,_) =>
      for {
        guestbook <- areaServers.get(areaId) ~> log.warning(s"Guestbook for $areaId not found")
        center <- guestbook.users.get(from) ~> log.warning(s"The user $from could not find in guest book $areaId")
      } {
        val octree = guestbook.octree
        var to = octree.query(Sphere(center = center.position,radius = radiusLevelToRadius(radiusLevel))).map(_.uid).filter(_ != from)
        if (to.length > MAX_AREA_MESSAGE) {
          to = to.take(MAX_AREA_MESSAGE)
        }
        
        // Ignore unknown destinations
        val (dests, _) = queryDestinations(agentServers,to)
        dests.foreach {
          case (agentId, users) =>
            sendMessageToAgent(agentId, AreaMessage(messageId, from, areaId, msg, radiusLevel, users))
        }
      }

    case rm:RoomMessage =>
      sendRoomMessage(agentServers, rm).foreach(retryLater(_))

    case dm: SingleDirectMessage =>
      log.info("### SingleDirectMessage Received")
      sendSingleDirectMessage(agentServers, dm, sender())

    case m : SingleAreaMessage =>
      sendSingleAreaMessage(areaServers, agentServers, m, sender())
      
    case ack: MessageAck =>
      sendMessageAck(agentServers, ack, sender())

    case RefreshGuestBook =>
      val (areagb,agentgb) = refreshGuestBook(areaServers,agentServers)
      context.become(process(areagb,agentgb),discardOld = true)

    // TODO: separate Room message? -->>>

    case req:CreateChatRoomRequest =>
      log.info("CreateChatRoomRequest")
      rerouteToLeader (clusterLeader, req,{
        roomLedger.createChatRoom(req.owner,req.roomType,req.addOwner,self).map {
          roomId =>
            new CreateChatRoomResponse(req.timestamp,ResultStatus.Success.id.toShort,roomId)
        }.getOrElse(new CreateChatRoomErrorResponse(req.timestamp,ResultStatus.Failure.id.toShort))
      })

    case req:DestroyChatRoomRequest =>
      log.info("DestroyChatRoomRequest")
      rerouteToLeader (clusterLeader, req,{
        new DestroyChatRoomResponse(req.timestamp,
          if (roomLedger.destroyChatRoom(req.roomId,req.user,self)) {
            ResultStatus.Success.id.toShort
          } else {
            ResultStatus.Failure.id.toShort
          })
      })

    case req:QueryChatRoomRequest =>
      log.info("QueryChatRoomRequest")
      rerouteToLeader(clusterLeader, req,{
        roomLedger.queryChatRoom(req.owner,req.roomType,req.createIfNotExists,req.addOwner,self).map {
          roomId =>
            new QueryChatRoomResponse(req.timestamp,ResultStatus.Success.id.toShort,roomId)
        }.getOrElse(new QueryChatRoomErrorResponse(req.timestamp,ResultStatus.Failure.id.toShort))
      })

    case req:JoinChatRoomRequest =>
      rerouteToLeader (clusterLeader, req,{
        new JoinChatRoomResponse(req.timestamp,
          if (roomLedger.joinChatRoom(req.roomId,req.user,self)) {
            log.info("JoinChatRoom Success")
            ResultStatus.Success.id.toShort
          } else {
            log.info("JoinChatRoom Failure")
            ResultStatus.Failure.id.toShort
          })
      })

    case req:ExitChatRoomRequest =>
      rerouteToLeader(clusterLeader, req,{
        new ExitChatRoomResponse(req.timestamp,
          if (roomLedger.exitChatRoom(req.roomId,req.user,req.user,self)) {
            ResultStatus.Success.id.toShort
          } else {
            ResultStatus.Failure.id.toShort
          })
      })
      
    case req:KickOutFromRoomRequest =>
      rerouteToLeader(clusterLeader, req,{
        new ExitChatRoomResponse(req.timestamp,
          if (roomLedger.exitChatRoom(req.roomId,req.operator,req.user,self)) {
            ResultStatus.Success.id.toShort
          } else {
            ResultStatus.Failure.id.toShort
          })
      })

    case req:GetChatRoomStatusRequest =>
      sender() ! roomLedger.chatRoomOf(req.roomId).map {
        cr =>
          new GetChatRoomStatusResponse(req.timestamp,ResultStatus.Success.id.toShort,cr.owner,cr.members.toList)
      }.getOrElse(new GetChatRoomStatusErrorResponse(req.timestamp,ResultStatus.Failure.id.toShort))

    case req:GetChatRoomOwnerRequest =>
      sender() ! roomLedger.chatRoomOf(req.roomId).map {
        cr =>
          new GetChatRoomOwnerResponse(req.timestamp,ResultStatus.Success.id.toShort,cr.owner)
      }.getOrElse(new GetChatRoomOwnerErrorResponse(req.timestamp,ResultStatus.Failure.id.toShort))

    case req:GetChatRoomMemberListRequest =>
      sender() ! roomLedger.chatRoomOf(req.roomId).map {
        cr =>
          new GetChatRoomMemberListResponse(req.timestamp,ResultStatus.Success.id.toShort,cr.members.toList)
      }.getOrElse(new GetChatRoomMemberListErrorResponse(req.timestamp,ResultStatus.Failure.id.toShort))

    /// <<----


    case ntf:ChatRoomNotificationResponse =>
      sendChatRoomNotification(agentServers, ntf).foreach(retryLater(_))

//    case req:UpdateRoomRequest =>
//      roomKeeper.updateRoom(req.roomRaw)

    case RetrySending(ttl, msg) =>
      (msg match {
        case dm:DirectMessage =>
          sendDirectMessage(agentServers, dm)
        case rm:RoomMessage =>
          sendRoomMessage(agentServers, rm)
        case ntf:ChatRoomNotificationResponse =>
          sendChatRoomNotification(agentServers, ntf)
      }).foreach {
        left =>
          if (ttl > 0) retryLater(left,ttl - 1)
      }

    case SetLeader(clusterLeader) =>
      context.become(process(areaServers, agentServers, Some(clusterLeader)))
  }
}
