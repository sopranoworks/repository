package codebook.runtime.server.chat

import akka.util.ByteString
import codebook.runtime.protocol.VLong
import codebook.runtime.util.ByteStringReader

trait RoomFactory[CR <: ChatRoom] {
  def createRoom(roomId:Long,roomType:Int,owner:Long,maxMembers:Int, roomHash:Int = 0,members:Set[Long] = Set.empty):Option[CR]
  def destroyRoom(room:CR,by:Long):Boolean

  def parse(str:String):Option[(Int,Int,Int,Int,Set[Long])] =
    str.split("/").toList match {
      case owner :: maxMember :: roomType :: roomHash :: members :: Nil =>
        Some((owner.toInt, maxMember.toInt, roomType.toInt, roomHash.toInt,members.split(",").map { i => i.toLong}.toSet))

      case _ =>
        None
    }

  def deserialize(roomId:Long, from:String):Option[CR] =
    parse(from).flatMap {
      case (owner,maxMember,roomType,roomHash,members) =>
        createRoom(roomId, roomType, owner, maxMember, roomHash, members)
    }

  def decode(bytes:ByteString):Option[CR] = try {
    val reader = ByteStringReader(bytes)
    val roomId = reader.readLongLE
    val owner = reader.readLongLE
    val maxMember = reader.readIntLE
    val roomType = reader.readIntLE
    val roomHash = reader.readIntLE
    val n = VLong(reader)
    val members = 0.until(n.v.toInt).map(_ => reader.readLongLE).toSet

    createRoom(roomId, roomType, owner, maxMember, roomHash, members)
  } catch {
    case _:Throwable =>
      None
  }

  def initialRoomSizeFor(roomType:Int):Int
}
