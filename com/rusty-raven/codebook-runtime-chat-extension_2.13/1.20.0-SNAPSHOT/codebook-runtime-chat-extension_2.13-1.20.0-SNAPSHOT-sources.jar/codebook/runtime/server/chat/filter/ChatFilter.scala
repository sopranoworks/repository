package codebook.runtime.server.chat.filter

trait ChatFilter {
  def filterMessage(src:String):String
}
