package codebook.runtime.protocol.chat

object LoggerCommands {
  case class QueryDirectLog(to:Long, from:Long)
  case class QueryAreaLog(areaId:Long, receiver:Long)
  case class QueryRoomLog(roomId:Long)
  
}
