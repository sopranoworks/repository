package codebook.runtime.protocol.chat

import akka.serialization.Serializer
import akka.util.ByteString
import codebook.runtime.math.Octree
import codebook.runtime.packet.GzipPacketCipher
import codebook.runtime.protocol.{Request, UserPosition, VLong}
import codebook.runtime.util.{ByteStringDecodingListHelper, ByteStringHelper, ByteStringReader, ByteStringStringHelper, HasAkkaConfig}
import org.slf4j.LoggerFactory

import scala.reflect.ClassTag

private object ChatMessageId extends Enumeration {
  val directMessage = Value
  val areaMessage = Value
  val roomMessage = Value

  val singleDirectMessage = Value
  val singleAreaMessage = Value

  val messageAck = Value
}

object ChatTransportStatus extends Enumeration {
  val DestinationReceived = Value
  val UserNotFound = Value
  val BlackListedInSender = Value
  val BlackListedInReceiver = Value

  val TransportError = Value

  implicit def toInt(v:ChatTransportStatus.Value):Int = v.id
}

trait ChatMessage {
  private val _timestamp:Long = System.currentTimeMillis()
  
  def timestamp:Long = _timestamp
  def messageId:Long
  def from:Long
  def toByteString:ByteString
}

/**
  * Single target chat message
  *
  * This type message will receive a result of message transporting.
  */
trait SingleTargetChatMessage extends ChatMessage with TrailerEncoder {
  def to:Long
  def toAck(s:ChatTransportStatus.Value = ChatTransportStatus.DestinationReceived):MessageAck =
    MessageAck(from = to, to = from, messageId, s.id)
}

trait MultiTargetChatMessage extends ChatMessage with TrailerEncoder {
  def to:Set[Long]
}

/**
  * Chat message trailer
  *
  * trailer id MUST be within 4 bits value
  */
trait ChatMessageTrailer {
  /**
    * 0: StringTrailerId (reserved)
    * 1: BlobTrailerId (reserved)
    * 2-15(0x0f) User defined
    */
  def trailerId:Int
  def toByteString:ByteString
  def logging:Boolean = true
}

/**
  * Normally use , string type trailer
  * 
  * @param msg message string
  */
case class StringTrailer(msg:String) extends ChatMessageTrailer {
  override def trailerId:Int = 0
  override def toByteString: ByteString = {
    val bytes = msg.getBytes("UTF-8")
    ByteString(bytes)
  }
}

case class BlobTrailer(bytes:ByteString) extends ChatMessageTrailer {
  override def trailerId:Int = 1
  override def toByteString: ByteString = bytes
  override def logging:Boolean = false
}

case class IntermediateMessageTrailer(trailerId:Int, bytes:ByteString) extends ChatMessageTrailer {
  override def toByteString: ByteString = bytes
  override def logging:Boolean = false
}

trait TrailerEncoder {
  def encodeTrailer(trailer:ChatMessageTrailer):ByteString = {
    val bytes = trailer.toByteString
    VLong(bytes.length).toByteString ++ bytes
  }

}

trait AuxualTrailerDecoder {
  def trailerId:Int
  def decode(reader: ByteStringReader):Option[ChatMessageTrailer]
}

trait TrailerDecoder {
  private var decoders:Map[Int, AuxualTrailerDecoder] = Map.empty

  private def decodeMessage(reader: ByteStringReader,l:Int):String = {
    val bytes = reader.readBytes(l)
    bytes.decodeString("UTF-8")
  }

  private def decodeBlob(reader: ByteStringReader,l:Int):ByteString = {
    reader.readBytes(l)
  }

  def decodeTrailer(trailerId:Int,reader: ByteStringReader):Option[ChatMessageTrailer] = {
    val l = VLong(reader).v.toInt
    trailerId match {
      case 0 => Some(StringTrailer(decodeMessage(reader,l)))
      case 1 => Some(BlobTrailer(decodeBlob(reader,l)))
      case _ =>
        decoders.get(trailerId).flatMap(_.decode(reader)).orElse(Some(IntermediateMessageTrailer(trailerId,decodeBlob(reader,l))))
    }
  }

  def registerDecoder(decoder: AuxualTrailerDecoder):Unit =
    decoders += decoder.trailerId->decoder
}

object TrailerDecoder extends TrailerDecoder


case class DirectMessage(messageId:Long,from:Long,to:Set[Long],trailer: ChatMessageTrailer,messageType:Byte = 0) extends MultiTargetChatMessage {
  override def toByteString: ByteString =
    ByteString((ChatMessageId.directMessage.id | trailer.trailerId << 4).toByte) ++
    ByteStringHelper.LE.longToByteString(messageId) ++
    ByteStringHelper.LE.longToByteString(from) ++
    to.foldLeft(VLong(to.size).toByteString)((b,u) => b ++ ByteStringHelper.LE.longToByteString(u)) ++
    encodeTrailer(trailer) ++
    ByteString(messageType)
}

case class AreaMessage(messageId:Long,from:Long,areaId:Int,trailer: ChatMessageTrailer,radiusLevel:Byte,to:Set[Long] = Set.empty) extends MultiTargetChatMessage {
  override def toByteString: ByteString =
    ByteString((ChatMessageId.areaMessage.id | trailer.trailerId << 4).toByte) ++
    ByteStringHelper.LE.longToByteString(messageId) ++
    ByteStringHelper.LE.longToByteString(from) ++
    ByteStringHelper.LE.intToByteString(areaId) ++
    encodeTrailer(trailer) ++
    ByteString(radiusLevel) ++
    to.foldLeft(VLong(to.size).toByteString)((b,u) => b ++ ByteStringHelper.LE.longToByteString(u))
}

case class RoomMessage(messageId:Long,roomId:Long, from:Long, trailer: ChatMessageTrailer,to:Set[Long] = Set.empty,messageType:Byte = 0) extends MultiTargetChatMessage {
  override def toByteString: ByteString =
    ByteString((ChatMessageId.roomMessage.id | trailer.trailerId << 4).toByte) ++
    ByteStringHelper.LE.longToByteString(messageId) ++
    ByteStringHelper.LE.longToByteString(roomId) ++
    ByteStringHelper.LE.longToByteString(from) ++
    encodeTrailer(trailer) ++
    to.foldLeft(VLong(to.size).toByteString)((b,u) => b ++ ByteStringHelper.LE.longToByteString(u)) ++
    ByteString(messageType)
}

object RoomMessage {
  def apply(reader: ByteStringReader):RoomMessage = {
    val trailerId = reader.readByte >> 4
    new RoomMessage(
      reader.readLongLE,
      reader.readLongLE,
      reader.readLongLE,
      TrailerDecoder.decodeTrailer(trailerId,reader).get,
      ByteStringDecodingListHelper.decodeList(reader,(reader:ByteStringReader) => { reader.readLongLE}).toSet,
      reader.readByte)
  }
}

case class SingleDirectMessage(messageId:Long,from:Long, to:Long, trailer:ChatMessageTrailer, messageType:Byte = 0) extends SingleTargetChatMessage {
  override def toByteString: ByteString =
    ByteString((ChatMessageId.singleDirectMessage.id | trailer.trailerId << 4).toByte) ++
    ByteStringHelper.LE.longToByteString(messageId) ++
    ByteStringHelper.LE.longToByteString(from) ++
    ByteStringHelper.LE.longToByteString(to) ++
    encodeTrailer(trailer) ++
    ByteString(messageType)

  override def toString:String = s"SingleDirectMessage(messageId = $messageId, from = $from, to = $to, trailer = $trailer, messageType = $messageType)"
}

case class SingleAreaMessage(messageId:Long,from:Long,to:Long,areaId:Int,trailer:ChatMessageTrailer,radiusLevel:Byte) extends SingleTargetChatMessage {
  override def toByteString: ByteString =
    ByteString((ChatMessageId.singleAreaMessage.id | trailer.trailerId << 4).toByte) ++
    ByteStringHelper.LE.longToByteString(messageId) ++
    ByteStringHelper.LE.longToByteString(from) ++
    ByteStringHelper.LE.longToByteString(to) ++
    ByteStringHelper.LE.intToByteString(areaId) ++
    encodeTrailer(trailer) ++
    ByteString(radiusLevel)
}

case class RoomMessageHistory(timestamp:Long, roomMessage: RoomMessage) {
  def this(reader: ByteStringReader) = this(reader.readLongLE, RoomMessage(reader))

  def toByteString:ByteString = {
    ByteStringHelper.LE.longToByteString(timestamp) ++ roomMessage.toByteString
  }
}

case class MessageAck(from:Long, to:Long, messageId:Long, result:Int) extends SingleTargetChatMessage {
  override def toByteString: ByteString =
    ByteString(ChatMessageId.messageAck.id.toByte) ++
    ByteStringHelper.LE.longToByteString(from) ++
    ByteStringHelper.LE.longToByteString(to) ++
    ByteStringHelper.LE.longToByteString(messageId) ++
    ByteStringHelper.LE.intToByteString(result)
}


case class AreaOctree[D : ClassTag,P <: UserPosition[D] : ClassTag](areaId:Int, users:Map[Long,P],octree:Octree[P])

case class GuestBook(agentId:Int, guests:Set[Long])

case object RefreshGuestBook

class ChatMessageSerializer extends Serializer {
  private val _logger = LoggerFactory.getLogger("ChatMessageDecoder")
  private val _compressor = new GzipPacketCipher

  import TrailerDecoder._

  def decodeTo(reader: ByteStringReader):Set[Long] =
    0.until(VLong(reader).v.toInt).map(_ => reader.readLongLE).toSet

  def decode(bytes:ByteString):Option[AnyRef] = {
    val reader = ByteStringReader(bytes)
    try {
      val v = reader.readByte.toInt
      val messageTypeId = v & 0x0f
      val trailerTypeId = (v >> 4) & 0x0f
      messageTypeId match {
        case c if c == ChatMessageId.directMessage.id =>
          Some(DirectMessage(reader.readLongLE,reader.readLongLE,decodeTo(reader), decodeTrailer(trailerTypeId,reader).get, reader.readByte))
        case c if c == ChatMessageId.areaMessage.id =>
          Some(AreaMessage(reader.readLongLE,reader.readLongLE,reader.readIntLE,decodeTrailer(trailerTypeId,reader).get, reader.readByte,decodeTo(reader)))
        case c if c == ChatMessageId.roomMessage.id =>
          Some(RoomMessage(reader.readLongLE,reader.readLongLE,reader.readLongLE,decodeTrailer(trailerTypeId,reader).get, decodeTo(reader), reader.readByte))
        case c if c == ChatMessageId.singleDirectMessage.id =>
          Some(SingleDirectMessage(reader.readLongLE,reader.readLongLE, reader.readLongLE, decodeTrailer(trailerTypeId,reader).get, reader.readByte))
        case c if c == ChatMessageId.singleAreaMessage.id =>
          Some(SingleAreaMessage(reader.readLongLE,reader.readLongLE, reader.readLongLE, reader.readIntLE, decodeTrailer(trailerTypeId,reader).get, reader.readByte))
        case c if c == ChatMessageId.messageAck.id =>
          Some(MessageAck(reader.readLongLE, reader.readLongLE, reader.readLongLE, reader.readIntLE))
        case _ =>
          _logger.info(s"Unknown message type id:$messageTypeId")
          None
      }

    } catch {
      case _ : Throwable =>
        _logger.error("Invalid Message")
        None
    }
  }

  override def identifier: Int = 9011

  override def toBinary(o: AnyRef): Array[Byte] = o match {
    case m : ChatMessage =>
      val bytes = m.toByteString
      (_compressor.encrypt(bytes) match {
        case Some(comp) =>
          ByteString(1) ++ comp
        case None =>
          ByteString(0) ++ bytes
      }).toArray
    case _ =>
      throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type")
  }

  override def includeManifest: Boolean = false

  override def fromBinary(bytes: Array[Byte], manifest: Option[Class[_]]): AnyRef = {
    val bb = ByteString(bytes)
    (if (bb(0) == 0) {
      decode(bb.drop(1))
    } else {
      _compressor.decrypt(bb.drop(1)).flatMap(decode)
    }).getOrElse(throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type"))
  }

}

object ChatMessageSettings extends HasAkkaConfig {
  override def akkaConfig: String =
s"""
akka {
  actor {
    serializers {
      chatmsgser = "codebook.runtime.protocol.chat.ChatMessageSerializer"
    }
    serialization-bindings {
      "codebook.runtime.protocol.chat.ChatMessage" = chatmsgser
    }
  }
}
"""
}
