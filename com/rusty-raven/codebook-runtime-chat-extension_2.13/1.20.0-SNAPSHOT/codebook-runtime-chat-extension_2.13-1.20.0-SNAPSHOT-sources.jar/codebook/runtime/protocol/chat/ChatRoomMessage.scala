package codebook.runtime.protocol.chat

import codebook.runtime.protocol.{AkkaRequestSerializer, AkkaResponseSerializer}
import codebook.runtime.util.HasAkkaConfig

class ChatRoomRequestSerializer extends AkkaRequestSerializer {
  override val identifier = 9012
  val decoder = new ProtocolDecoder
}

class ChatRoomResponseSerializer extends AkkaResponseSerializer {
  override val identifier = 9013
  val decoder = new ProtocolDecoder
}

object ChatRoomMessageSettings extends HasAkkaConfig {
  override def akkaConfig: String =
s"""
akka {
  actor {
    serializers {
      chatroomreqser = "codebook.runtime.protocol.chat.ChatRoomRequestSerializer"
      chatroomresser = "codebook.runtime.protocol.chat.ChatRoomResponseSerializer"
    }
    serialization-bindings {
      "codebook.runtime.protocol.chat.ChatRoomRequest" = chatroomreqser
      "codebook.runtime.protocol.chat.ChatRoomResponse" = chatroomresser
    }
  }
}
"""
}
