/**
  * codebook.runtime.util JValueHelper
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Ossamu Takahashi
  */
package codebook.runtime.util

import codebook.runtime.protocol.StringN
import net.liftweb.json.JsonAST._

object JValueHelper {
  implicit class Converter(jv:JValue) {
    def getBoolean:Boolean =
      jv match {
        case JInt(v) =>
          v.toByte != 0
        case JDouble(v) =>
          v.toByte != 0
        case JString(s) =>
          Integer.parseInt(s).toByte != 0
        case JBool(v) =>
          v
        case _ =>
          throw new RuntimeException("Invalid JSON deserialization")
      }

    def getByte:Byte =
      jv match {
        case JInt(v) =>
          v.toByte
        case JDouble(v) =>
          v.toByte
        case JString(s) =>
          Integer.parseInt(s).toByte
        case _ =>
          throw new RuntimeException("Invalid JSON deserialization")
      }

    def getShort:Short =
      jv match {
        case JInt(v) =>
          v.toShort
        case JDouble(v) =>
          v.toShort
        case JString(s) =>
          Integer.parseInt(s).toShort
        case _ =>
          throw new RuntimeException("Invalid JSON deserialization")
      }

    def getInt:Int =
      jv match {
        case JInt(v) =>
          v.toInt
        case JDouble(v) =>
          v.toInt
        case JString(s) =>
          Integer.parseInt(s)
        case _ =>
          throw new RuntimeException("Invalid JSON deserialization")
      }

    def getLong:Long =
      jv match {
        case JInt(v) =>
          v.toInt
        case JDouble(v) =>
          v.toInt
        case JString(s) =>
          Integer.parseInt(s)
        case _ =>
          throw new RuntimeException("Invalid JSON deserialization")
      }

    def getFloat:Float =
      jv match {
        case JInt(v) =>
          v.toFloat
        case JDouble(v) =>
          v.toFloat
        case _ =>
          throw new RuntimeException("Invalid JSON deserialization")
      }

    def getDouble:Double =
      jv match {
        case JInt(v) =>
          v.toDouble
        case JDouble(v) =>
          v
        case _ =>
          throw new RuntimeException("Invalid JSON deserialization")
      }

    def getString:String =
      jv match {
        case JString(s) =>
          s
        case _ =>
          throw new RuntimeException("Invalid JSON deserialization")
      }
  }
  implicit class StringNtoJV(str:StringN) {
    def toJValue:JValue = JString(str.str)
  }
}
