package codebook.runtime.ranking

case class RankingResult(rankingBase:Int,numOfRanker:Int,score:Long,ids:List[Long])
