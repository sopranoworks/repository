package codebook.runtime.ranking

import java.util.concurrent.locks._
import scala.collection.mutable.HashMap

// TODO:range lock

trait RankingTable[Entry <: RankingEntry] {
  private val _idToEntry = HashMap[Long,Entry]()
  private var _root:Option[RankingPage] = None
  private val _lock = new ReentrantReadWriteLock(true)

//	def tableId:String

	def restore():Unit

	restore()

  private def _findPage(score:Long):RankingPage = {
		_root match {
			case Some(r) => r.findPage(score)
			case None =>
				val root = new RankingPage(score)
				_root = Some(root)
				root
		}
  }

	def updateEntry(id:Long,score:Long):Entry
	def addAndUpdate(id:Long,score:Long):Entry
	def cleanEntries():Unit

	def insert(page:RankingPage,ent:Entry):Unit

  private def _insert(page:RankingPage,ent:Entry):RankingPage = {
    page.append(ent)
    _idToEntry += ent.uid -> ent
    page
  }
	
  private def _insert(ent:Entry):RankingPage = {
    val score = ent.score
    val page = _findPage(score)
    _insert(page,ent)
  }

	private def _updateRankFromTo(from:RankingPage,to:Option[RankingPage]): Unit = {
		if (from != null) {
			var entry = from.next
			var rank = from.rankBase + from.count
	
			while(entry != to) {
				entry.foreach {
					e =>
						rank = e.updateRank(rank)
						entry = e.next
				}
			}
		}
	}

	private def _updateRank(i:RankingPage,r:Option[RankingPage]): Unit = {
		if (!r.contains(i)) {
			r match {
				case Some(e) =>
					if (i.score >= e.score) {
						_updateRankFromTo(i,e.next)
					} else {
						_updateRankFromTo(e,i.next)
					}
				case None =>
					_updateRankFromTo(i,r)
			}
		}
	}

	private def _updateRank(from:RankingPage): Unit = { _updateRankFromTo(from,None) }

  def insert(id:Long, score:Long): Unit = {
    val entry = updateEntry(id,score)
  	_lock.writeLock.lock()
  	try {
//  		_updateRank(_insert(id,score))
      _updateRank(_insert(entry))
    } finally {
  		_lock.writeLock.unlock()
  	}
  }

	private def _remove(rid:Long):Option[RankingPage] = {
		_idToEntry.get(rid).flatMap {
			e =>
				val page = e.page
		    page.foreach(_.remove(e))
				_idToEntry -= rid
    		page
		}
	}

  def remove(id:Long): Unit = {
  	_lock.writeLock.lock()
  	try {
  		_remove(id).foreach {
				removedPage =>
					_updateRank(removedPage)
		  		removedPage.refresh()
			}
  	} finally {
  		_lock.writeLock.unlock()
  	}
  }

  def update(rid:Long, score:Long): Unit = {
    val newEntry = updateEntry(rid,score)

  	_lock.writeLock.lock()
  	try {
  		val removedPage = _remove(rid)
//	  	if (removedPage != null) println("remove:" + removedPage.score)
//    	val insertedPage = _insert(id,score)
        val insertedPage = _insert(newEntry)

//	  	println("insert:" + insertedPage.score)

    	_updateRank(insertedPage,removedPage)
			removedPage.foreach(_.refresh())
  	} finally {
  		_lock.writeLock.unlock()
  	}
  }

  def add(id:Long,score:Long): Unit = {
    if (score != 0) {
      try {
        val newEntry = addAndUpdate(id,score)
        _lock.writeLock.lock()
        try {
          val removedPage = _remove(id)
          val insertedPage = _insert(newEntry)

          _updateRank(insertedPage,removedPage)
					removedPage.foreach(_.refresh())
        } finally {
          _lock.writeLock.unlock()
        }
      } catch {
        case _ : Throwable =>
      }
    }
  }

	def entryForId(id:Long):Option[RankingEntry] =
    _idToEntry.get(id)

  def rankOfId(id:Long):Option[Int] = {
  	_lock.readLock.lock()
		try {
			_idToEntry.get(id).flatMap(_.page.map(_.rankBase))
		} catch {
			case _:Exception => None
		} finally {
			_lock.readLock.unlock()
		}
	}

  def scoreOfId(id:Long):Option[Long] = {
  	_lock.readLock.lock()
		try {
			_idToEntry.get(id).map(_.score)
		} catch {
			case _:Exception => None
		} finally {
			_lock.readLock.unlock()
		}
	}

	/**
		* Get until nth ranker from top
		* @param n
		* @return
		*/
	def top(n:Int):List[RankingResult] = {
		var res = List.empty[RankingResult]
		var page = _root.map(_.top)
		var nn = n

		while(page.nonEmpty && nn > 0) {
			page.foreach {
				p =>
					p.result(n).foreach {
						r =>
							res = res :+ r
							nn -= r.numOfRanker
					}
					page = p.next
			}
		}
		res
	}

	private def _checkTree:Boolean = {
		var page = _root.map(_.top)
		var rank = 0
		var score = page.map(_.score + 1).getOrElse(0L)

		while(page.nonEmpty) {
			page = page.flatMap {
				p =>
					if (p.rankBase != rank || score <= p.score) {
						println(p)
						return false
					}
					rank += p.count
					score = p.score
					p.next
			}
		}
		true
	}

	def check:Boolean = {
  	_lock.readLock.lock()
  	try {
  		_root match {
				case None => true
				case _ => _checkTree
			}
		} catch {
			case _ : Throwable => false
		} finally {
			_lock.readLock.unlock()
		}
	}

	def describe(): Unit = {
		_lock.readLock.lock()

		_root.foreach {
			root =>
				var page:Option[RankingPage] = Some(root.top)
				while(page.nonEmpty) {
					page.foreach(_.describe())
					page = page.flatMap(_.next)
				}
		}
		_lock.readLock.unlock()
	}

  def clean(): Unit = {
    _lock.writeLock.lock()
    try {
			_root.foreach {
				root =>
					root.clear()
					cleanEntries()
			}
			_root = None
    } catch {
      case _ : Throwable =>
    } finally {
      _lock.readLock.unlock()
    }
  }
}
