package codebook.runtime.ranking

trait RankingEntry {
  def page:Option[RankingPage]
  def setPage(page:Option[RankingPage]):Unit
  def page_=(page:Option[RankingPage]):Unit = setPage(page)
  def uid:Long
  def score:Long
}
