package codebook.runtime.ranking

class RankingPage(val score:Long,rank:Int = 0,upper:Option[RankingPage] = None) {
  private var _rankBase:Int = rank
	// scores are stored left to right order
	// left > right
  private var _left:Option[RankingPage] = None
  private var _right:Option[RankingPage] = None
  private var _up:Option[RankingPage] = upper

  private var _entries:List[RankingEntry] = List()

//  def score: Long = score
  def rankBase: Int = _rankBase
  def count: Int = _entries.length

  def shiftRank(d:Int): Unit = {
    _rankBase += d
  }

  def append(e:RankingEntry): Unit = {
		if (e.score == score) {
			_entries :+= e
			e.page = Some(this)
		} else {
			findPage(e.score).append(e)
		}
  }

	def refresh(): Unit = {
		if (count == 0) {
			if (_up.isDefined && (_left.isEmpty || _right.isEmpty)) {
				_up.map(_._replace(this,if (_left.isEmpty) _right else _left))
			}
		}
	}

  def remove(e:RankingEntry): Unit = {
  	assert(e != null)
    _entries = _entries.filter(_ != e)
  }

	/**
		* Find or create specified score ranking page
		* @param s score
		* @return ranking page
		*/
	def findPage(s:Long):RankingPage = {
		if (s > score) {
			_left match {
				case Some(l) =>
					l.findPage(s)
				case None =>
					val newPage = new RankingPage(s,_rankBase,Some(this))
		//			println("create page:" + s)
					_left = Some(newPage)
					newPage
			}
		} else
		if (s < score) {
			_right match {
				case Some(r) => r.findPage(s)
				case None =>
					val newPage = new RankingPage(s,_rankBase + count,Some(this))
		//			println("create page:" + s)
					_right = Some(newPage)
					newPage
			}
		} else {
			this
		}
	}

	def updateRank(rank:Int):Int = {
		_rankBase = rank
		_rankBase + count
	}

	private def _replace(from:RankingPage,to:Option[RankingPage]):Unit = {
		if (_left.contains(from)) {
			_left = to
		} else {
			if (_right.contains(from)) {
				_right = to
			} else {
				assert(false)
			}
		}
		to.foreach(_._up = Some(this))
	}

	/**
		* Get Top Ranking Page
		* @return ranking page
		*/
	def top:RankingPage =
		// find left-est node
		_left.map(_.top).getOrElse(this)

	/**
		* Get Bottom Ranking Page
		* @return ranking page
		*/
	def bottom:RankingPage =
		// find right-est node
		_right.map(_.bottom).getOrElse(this)

	/**
		* Get next ranking page
		* @return next page
		*/
	def next:Option[RankingPage] = {
		_right match {
			case Some(r) => Some(r.top)
			case None =>
				var up = _up
				while (up.exists(_.score > score)) {
					up.foreach(u => up = u._up)
				}
				up
		}
	}

	def describe(): Unit = {
		println(toString)
	}

	private def _ids(n:Int):List[Long] = {
    _entries.map(_.uid).take(n)
	}

	def result(n:Int):Option[RankingResult] = {
		if (count > 0) Some(RankingResult(_rankBase,count,score,_ids(n))) else None
	}

  def clear(): Unit = {
		_left.foreach(_.clear())
		_right.foreach(_.clear())
    _left = None
    _right = None
    _entries = List.empty
  }
  override def toString: String = "score:" + score + " rank_base:" + _rankBase + " count:" + count
}
