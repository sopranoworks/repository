package codebook.runtime.protocol
import akka.util.ByteString
import codebook.runtime.util.ByteStringReader

case class VString(str:String) extends ByteStringSerializable {
  import codebook.runtime.util.ByteStringStringHelper._

//  def this(reader: ByteStringReader) = this(decodeString(reader))
  override def toByteString: ByteString = {
    val bytes = str.getBytes("UTF-8")
    VLong(bytes.length.toLong).toByteString ++ ByteString(bytes)
  }
}
