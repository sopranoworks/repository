/**
  * codebook.runtime.protocol.StringN
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.util.ByteStringReader

/**
  * The base class of fixed length string classes
  */
trait StringN extends ByteStringSerializable {
  def str:String
  def limit:Int

  /**
    * The converting to ByteString method
    * @return a ByteString converted string
    */
  def toByteString:ByteString = {
    if (str == null) {
      VLong(0).toByteString
    } else {
      if (str.length > limit) {
        val bytes = str.substring(0, limit).getBytes("UTF-8")
        VLong(bytes.length.toLong).toByteString ++ ByteString(bytes)
      } else {
        val bytes = str.getBytes("UTF-8")
        VLong(bytes.length.toLong).toByteString ++ ByteString(bytes)
      }
    }
  }
}

/**
  * The helper object for StringN class
  */
object StringN {
  /**
    * The decoding String from ByteString stream
    * @param reader a ByteStringReader
    * @param limit a limitation of string length
    * @return a length limited string
    */
  def decode(reader:ByteStringReader,limit:Int):String = {
    val l = VLong(reader).v
    if (l == 0) {
      ""
    } else {
      val bytes = reader.readBytes(l.toInt)
      val str = new String(bytes.toArray,"UTF-8")
      if (str.length > limit) str.substring(0,limit) else str
    }
  }
}
