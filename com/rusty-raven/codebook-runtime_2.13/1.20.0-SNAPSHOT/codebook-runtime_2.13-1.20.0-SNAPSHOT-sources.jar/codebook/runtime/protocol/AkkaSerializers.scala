/**
  * codebook.runtime.protocol.AkkaSerializers
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.protocol

import akka.serialization.Serializer
import akka.util.ByteString
import codebook.runtime.packet.GzipPacketCipher
import codebook.runtime.util.ByteStringReader

import scala.reflect.ClassTag

trait AkkaRequestSerializer extends Serializer {
  def decoder:Decoder

  def includeManifest: Boolean = false

  def identifier: Int = 1001

  def toBinary(obj: AnyRef): Array[Byte] = {
    obj match {
      case req : Request =>
        req.toByteString.toArray
      case _ =>
        throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type")
    }
  }

  def fromBinary(bytes: Array[Byte], clazz: Option[Class[_]]): AnyRef =
    decoder.decodeRequest(ByteStringReader(ByteString(bytes))).getOrElse(throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type"))
}

trait AkkaResponseSerializer extends Serializer {
  def decoder:Decoder

  def includeManifest: Boolean = false

  def identifier = 1002

  def toBinary(obj: AnyRef): Array[Byte] = {
    obj match {
      case req : Response =>
        req.toByteString.toArray
      case _ =>
        throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type")
    }
  }

  def fromBinary(bytes: Array[Byte], clazz: Option[Class[_]]): AnyRef =
    decoder.decodeResponse(ByteStringReader(ByteString(bytes))).getOrElse(throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type"))
}

abstract class AkkaProtocolSerializer[R <: Request : ClassTag] extends Serializer {
  def decoder:Decoder

  def includeManifest: Boolean = false

  def identifier: Int = 1001

  def toBinary(obj: AnyRef): Array[Byte] = {
    obj match {
      case req : R =>
        req.toByteString.toArray
      case _ =>
        throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type")
    }
  }
  // !! only request will be decoded !!
  def fromBinary(bytes: Array[Byte], clazz: Option[Class[_]]): AnyRef =
    decoder.decodeRequest(ByteStringReader(ByteString(bytes))).getOrElse(throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type"))
}

abstract class CompressedAkkaProtocolSerializer[R <: Request : ClassTag] extends AkkaProtocolSerializer[R] {
  private val _compressor = new GzipPacketCipher

  override def toBinary(obj: AnyRef): Array[Byte] = {
    obj match {
      case req : R =>
        val bytes = req.toByteString
        _compressor.encrypt(bytes).map(enc => ByteString(1) ++ enc).getOrElse(ByteString(0) ++ bytes).toArray
      case _ =>
        throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type")
    }
  }

  override def fromBinary(bytes: Array[Byte], clazz: Option[Class[_]]): AnyRef = {
    val src = ByteString.fromArray(bytes,1,bytes.length - 1)
    (if (bytes(0) == 1) _compressor.decrypt(src) else Some(src)).flatMap(b =>
      decoder.decodeRequest(ByteStringReader(b))).getOrElse(throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type"))
  }
}
