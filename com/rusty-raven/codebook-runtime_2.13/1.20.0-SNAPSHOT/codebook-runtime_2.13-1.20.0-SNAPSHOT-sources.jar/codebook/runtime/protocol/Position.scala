/**
  * codebook.runtime.protocol.Position
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Ossamu Takahashi
  */
package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.math.Float3
import codebook.runtime.util.ByteStringHelper._
import codebook.runtime.util.ByteStringHelper.LE._

trait Position[T] {
  def x:T
  def y:T
  def z:T
  def toFloat3:Float3
  def toByteString:ByteString
  def size:Int
}

case class IntPosition3(x:Int,y:Int,z:Int) extends Position[Int] {
  def toByteString:ByteString =
    intToByteString(x) ++ intToByteString(y) ++ intToByteString(z)

  def toFloat3:Float3 =
    Float3(x.toFloat,y.toFloat,z.toFloat)

  def ==(other:IntPosition3):Boolean =
    x == other.x && y == other.y && z == other.z

  def !=(other:IntPosition3):Boolean = !(this == other)
  def size = 4 * 3

  override def equals(other:Any) =
    other.isInstanceOf[IntPosition3] && this == other.asInstanceOf[IntPosition3]

  override def toString = s"IntPosition3($x,$y,$z)"
}

object PositionConversion {
  implicit def positionToFloat3[PT](pos:Position[PT]):Float3 =
    pos.toFloat3
}

/*object Position {
  def apply(iter:ByteIterator) = {
    val x = iter.getInt
    val y = iter.getInt
    val z = iter.getInt
    new Position(x,y,z)
  }
  def apply(bytes:ByteString):Position = this(bytes.iterator)
  def apply():Position = new Position(0,0,0)
  final def size = 4 * 3
}

trait PositionConversion {
  implicit def positionToByteString(pos:Position):ByteString =
    pos.toByteString
  implicit def positionToFloat3(pos:Position):Float3 =
    pos.toFloat3

  implicit def float3ToPosition(f3:Float3):Position =
    Position(f3.x.toInt,f3.y.toInt,f3.z.toInt)

  implicit object PositionToBSON extends BSONType[Position] {
    override def asBSONObject(p:Position):AnyRef = {
      val ret = new BasicBSONObject()
      ret.put("x",p.x)
      ret.put("y",p.y)
      ret.put("z",p.z)
      ret
    }
  }
} */
