package codebook.runtime.protocol

class CommonErrorResponse(val cmdId:Short,timestamp:Long,resultStatus: Short) extends Response(timestamp,resultStatus)
