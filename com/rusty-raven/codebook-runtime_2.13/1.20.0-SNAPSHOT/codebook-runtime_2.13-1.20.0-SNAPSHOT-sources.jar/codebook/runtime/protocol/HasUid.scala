package codebook.runtime.protocol

trait HasUid {
  def uid:Long
}
