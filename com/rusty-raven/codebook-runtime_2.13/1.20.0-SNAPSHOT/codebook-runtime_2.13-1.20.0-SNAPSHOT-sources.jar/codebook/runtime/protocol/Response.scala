/**
  * codebook.runtime.protocol.Response
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Ossamu Takahashi
  */
package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.util.ByteStringHelper

abstract class Response(timestamp:Long,val resultStatus:Short) extends Request(timestamp) {
  override def toByteString:ByteString = super.toByteString ++ ByteStringHelper.LE.shortToByteString(resultStatus)

  def ==(other:Response) =
    super.==(other) && resultStatus == other.resultStatus
  override def equals(other:Any) =
    other.isInstanceOf[Response] && this == other.asInstanceOf[Response]
}
