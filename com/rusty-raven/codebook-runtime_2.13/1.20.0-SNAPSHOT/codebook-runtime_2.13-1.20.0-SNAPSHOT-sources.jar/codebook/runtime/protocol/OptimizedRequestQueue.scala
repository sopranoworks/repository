package codebook.runtime.protocol

trait OptimizedRequestQueue extends RequestQueue {
  private var _request:Option[Request] = None

  def push(req:Request):Unit = _request match {
    case Some(prev) => _request = Some(compare(prev,req))
    case None => _request = Some(req)
  }
  def pop:Option[Request] = {
    val r = _request
    _request = None
    r
  }
  def top:Option[Request] = _request
  def compare(a:Request,b:Request):Request = b
}
