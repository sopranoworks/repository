/**
  * codebook.runtime.protocol.Request
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  */
package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.util.ByteStringHelper

abstract class Request(val timestamp:Long) extends ByteStringSerializable {
  def cmdId:Short

  def importance:Int = 1

  def toByteString:ByteString = ByteStringHelper.LE.shortToByteString(cmdId) ++ ByteStringHelper.LE.longToByteString(timestamp)

  def errorResponse(resultStatus: Short):Response =
    new CommonErrorResponse(cmdId, timestamp, resultStatus)

  def ==(other:Request) =
    timestamp == other.timestamp
  override def equals(other:Any) =
    other.isInstanceOf[Request] && this == other.asInstanceOf[Request]
}
