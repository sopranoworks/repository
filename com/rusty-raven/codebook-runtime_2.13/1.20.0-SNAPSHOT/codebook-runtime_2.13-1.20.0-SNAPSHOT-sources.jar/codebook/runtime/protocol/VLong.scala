/**
  * codebook.core.protocol.VLong
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.util.ByteStringReader

final case class VLong(v:Long) {
  def this(reader:ByteStringReader) = this(VLong.decode(reader))

  def toByteString:ByteString = {
    val flag = v < 0
    val vv = if (flag) (v ^ 0xffffffffffffffffL) else v

    val arr = collection.mutable.ArrayBuffer[Byte]()
    arr += ((vv & 0x3f) | (if (flag) 0x40 else 0x00)).toByte
    arr += ((vv >> 6) & 0x7f).toByte
    arr += ((vv >> 13) & 0x7f).toByte
    arr += ((vv >> 20) & 0x7f).toByte
    arr += ((vv >> 27) & 0x7f).toByte
    arr += ((vv >> 34) & 0x7f).toByte
    arr += ((vv >> 41) & 0x7f).toByte
    arr += ((vv >> 48) & 0x7f).toByte
    arr += ((vv >> 55) & 0x7f).toByte
    arr += ((vv >> 62) & 0x01).toByte

    var i = 9
    while(arr(i) == 0 && i > 0) i -= 1

    arr(i) = (arr(i) + 0x80).toByte

    ByteString(arr.slice(0,i + 1).toArray)
  }
}

object VLong {
  def decode(reader:ByteStringReader):Long = {
    val arr = collection.mutable.ArrayBuffer[Byte]()

    var b:Byte = 0
    var i = 0

    do {
      b = reader.readByte
      arr += b
      i += 1
    } while((b & 0x80) == 0 && i < 10)

    i -= 1

    val flag = (arr(0) & 0x40) == 0x40

    val r = if (i == 0) {
      (arr(0) & 0x3f).toLong
    } else {
      var v:Long = arr(i) & 0x7f
      i -= 1
      while(i > 0) {
        v = (v << 7) | arr(i)
        i -= 1
      }
      (v << 6) | (arr(0) & 0x3f)
    }
    if (flag) (r ^ 0xffffffffffffffffL) else r
  }

  def decode(bytes:ByteString):Long =
    decode(ByteStringReader(bytes))

  def apply(reader:ByteStringReader) = new VLong(decode(reader))

  def usedBytes(bytes:ByteString):Int = {
    val l = math.min(9,bytes.length)
    (0 until l).foreach {
      i =>
        if ((bytes(i).toInt & 0x80) != 0) return i + 1
    }
    0
  }
}
