package codebook.runtime.protocol

trait RequestQueue {
  def push(req:Request):Unit
  def pop:Option[Request]

  def top:Option[Request]

  def map[B](f: Request => B):Option[B] =
    pop.map(f)
}
