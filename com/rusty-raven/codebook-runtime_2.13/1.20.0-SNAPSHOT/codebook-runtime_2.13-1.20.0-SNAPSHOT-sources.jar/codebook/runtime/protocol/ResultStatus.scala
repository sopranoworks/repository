/**
  * codebook.runtime.protocol.ResultStatus
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Ossamu Takahashi
  */
package codebook.runtime.protocol

object ResultStatus extends Enumeration {
  type ResultStatus = Value
  val Success = Value
  val Failure = Value(-1)
  val InvalidRequest = Value(-5)
  val InvalidUserId = Value(-9)
  val RetryLater = Value(-10)
  val Timeout = Value(-11)

  val InvalidState = Value(-99)

  implicit def toShort(v :ResultStatus):Short = v.id.toShort
}
