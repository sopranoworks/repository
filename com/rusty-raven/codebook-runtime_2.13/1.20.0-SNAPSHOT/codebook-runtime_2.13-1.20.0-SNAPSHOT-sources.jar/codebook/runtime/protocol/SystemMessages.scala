/**
  * codebook.runtime.protocol.SystemMessages
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.protocol

import akka.dispatch.ControlMessage

object SystemMessages {
  object Connected extends ControlMessage
  object ConnectFailed extends ControlMessage
  object Retry extends ControlMessage
  object Closed extends ControlMessage
  object GoodBy extends ControlMessage

  object Hello extends ControlMessage
  object Tick extends ControlMessage

  trait MessageWithID extends ControlMessage {
    def id:Long
  }

  object InvalidPacketReceived extends ControlMessage
  object InvalidTLSSession extends ControlMessage

  case class TransmitTo(ids:List[Long],msg:AnyRef) extends ControlMessage
  case class Broadcast(msg:AnyRef) extends ControlMessage
}
