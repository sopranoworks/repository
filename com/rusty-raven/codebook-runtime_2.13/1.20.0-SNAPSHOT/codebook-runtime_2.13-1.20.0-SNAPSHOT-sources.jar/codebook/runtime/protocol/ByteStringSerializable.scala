package codebook.runtime.protocol

import akka.util.ByteString

trait ByteStringSerializable {
  def toByteString:ByteString
}
