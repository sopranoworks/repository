/**
  * codebook.runtime.protocol.Decoder
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.protocol

import codebook.runtime.util.ByteStringReader

/**
 * The Decoder trait
 * Decoding a Request/Response from byte string using ByteStringReader
 */
trait Decoder {
  def decodeRequest(reader:ByteStringReader):Option[Request]
  def decodeResponse(reader:ByteStringReader):Option[Response]
}
