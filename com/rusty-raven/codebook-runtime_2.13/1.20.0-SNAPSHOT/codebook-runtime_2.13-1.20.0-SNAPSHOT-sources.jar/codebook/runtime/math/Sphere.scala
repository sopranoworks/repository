package codebook.runtime.math

case class Sphere(center:Float3,radius:Float) {
  private val radius2 = radius * radius
  def contains_?(p:Float3):Boolean = (p - center).length2 <= radius2
}
