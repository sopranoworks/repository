package codebook.runtime.math

case class YCylinder(xzCenter:Float3,xzRadius:Float,yHeight:Float) {
  private lazy val r2:Float = xzRadius * xzRadius
  private lazy val h2:Float = yHeight * 0.5F

  def contains_?(p:Float3):Boolean =
    (Float3(center.x - p.x,0,center.z - p.z).length2 <= r2) &&
      (center.y - p.y).abs <= h2

  lazy val center:Float3 = xzCenter + Float3(0,h2,0)
}
