package codebook.runtime.math

import akka.util.ByteString
import codebook.runtime.protocol.ByteStringSerializable
import codebook.runtime.util.ByteStringReader

case class AxisAlignedBox(center:Float3,halfSize:Float3) extends ByteStringSerializable {
  def intersects_?(sp:Sphere): Boolean =
    (center - sp.center).abs <= (halfSize + sp.radius)

  def intersects_?(c:YCylinder): Boolean =
    (Float3(center.x - c.xzCenter.x,0,center.z - c.xzCenter.z).abs <= halfSize + c.xzRadius) &&
      ((center.y - c.center.y).abs <= halfSize.y + c.yHeight * 0.5F)

  def contains_?(p:Float3): Boolean =
    (p - center).abs <= halfSize

  def min: Float3 = center - halfSize
  def max: Float3 = center + halfSize

  def ==(other:AxisAlignedBox): Boolean =
    center == other.center && halfSize == other.halfSize

  override def equals(other:Any): Boolean =
    other.isInstanceOf[AxisAlignedBox] && this == other.asInstanceOf[AxisAlignedBox]

  override def toByteString: ByteString = center.toByteString ++ halfSize.toByteString
}

object AxisAlignedBox {
  def withMinMax(min:Float3,max:Float3):AxisAlignedBox = {
    val c = (min + max) / 2
    val s = (max - c).abs
    AxisAlignedBox(c,s)
  }
  def withMinMax(minmax:(Float3,Float3)):AxisAlignedBox =
    withMinMax(minmax._1,minmax._2)

  def decode(reader:ByteStringReader):AxisAlignedBox =
    AxisAlignedBox(Float3.decode(reader),Float3.decode(reader))
}
