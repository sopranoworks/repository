package codebook.runtime.math

import akka.util.ByteString
import codebook.runtime.protocol.VLong
import codebook.runtime.util.ByteStringReader

trait HasFloat3Position {
  def position:Float3
}

trait PositionSerializer[P <: HasFloat3Position] {
  def encode(p:P):ByteString
  def decode(reader:ByteStringReader):P
}

private [math] case class OctreeLeaf[P <: HasFloat3Position](aab:AxisAlignedBox,users:Seq[P],depth:Int,leaves:Option[Seq[OctreeLeaf[P]]]) {
  def includes_?(user:P):Boolean =
    aab.contains_?(user.position)

  def numLeaves:Int = leaves.map(_.length).getOrElse(0)

  def query(sp:Sphere):Seq[(P,Float)] = if (aab.intersects_?(sp)) {
    users.filter(u => sp.contains_?(u.position)).map(u => (u,(u.position - sp.center).length2)) ++
    (leaves match {
      case Some(l) =>
        l.flatMap(_.query(sp))
      case _ =>
        Seq.empty[(P,Float)]
    })
  } else {
    Seq.empty[(P,Float)]
  }

  def query(c:YCylinder):Seq[(P,Float)] = if (aab.intersects_?(c)) {
      users.filter(u => c.contains_?(u.position)).map(u => (u,(u.position - c.xzCenter).length2)) ++
      (leaves match {
        case Some(l) =>
          l.flatMap(_.query(c))
        case _ =>
          Seq.empty[(P,Float)]
      })
    } else {
      Seq.empty[(P,Float)]
    }

  def toByteString(serializer:PositionSerializer[P]): ByteString = {
    users.foldLeft(aab.toByteString ++ VLong(users.length).toByteString)((b,u) => b ++ serializer.encode(u)) ++
      VLong(depth).toByteString ++
      (leaves match {
        case Some(leaf) =>
          leaf.foldLeft(VLong(leaf.length).toByteString)((b,l) => b ++ l.toByteString(serializer))
        case None =>
          VLong(0).toByteString
      })
  }

  def ==(other:OctreeLeaf[P]):Boolean = {
    val n = numLeaves
    aab == other.aab &&
      users.length == other.users.length &&
      n == other.numLeaves &&
      users.zip(other.users).forall(e => e._1 == e._2) &&
      ((leaves,other.leaves) match {
        case (Some(l1),Some(l2)) =>
          l1.zip(l2).forall(e => e._1 == e._2)
        case (None,None) =>
          true
        case _ =>
          false
      })
  }
}

private [math] object OctreeLeaf {
  final val MINIMUM_USER_COUNT=3
  final val MAXIMUM_DEPTH=10

  def sideOf(center:Float,p:Float): Int = if (p >= center) 1 else 0

  def regionIndexOf(centers:Float3,pos:Float3): Int =
    (sideOf(centers.x,pos.x) << 2) |
      (sideOf(centers.y,pos.y) << 1) |
      sideOf(centers.z,pos.z)

  def minimum(flag:Int,min:Float,center:Float): Float = if (flag != 0) center else min
  def maximum(flag:Int,max:Float,center:Float): Float = if (flag != 0) max else center

  def regionFromIndex(aab:AxisAlignedBox,centers:Float3,idx:Int):AxisAlignedBox = {
    val min = aab.min
    val max = aab.max

    AxisAlignedBox.withMinMax(
      Float3(minimum(idx & 4,min.x,centers.x),
        minimum(idx & 2,min.y,centers.y),
        minimum(idx & 1,min.z,centers.z)),
      Float3(maximum(idx & 4,max.x,centers.x),
        maximum(idx & 2,max.y,centers.y),
        maximum(idx & 1,max.z,centers.z)))
  }

  def split[P <: HasFloat3Position](aab:AxisAlignedBox,users:Seq[P],depth:Int):Option[Seq[OctreeLeaf[P]]] = {
    if (users.length > MINIMUM_USER_COUNT && depth < MAXIMUM_DEPTH) {
      val centers = aab.center
      val idxs = users.map(u => (u,regionIndexOf(centers,u.position)))
      val usersInRegions = for (i<- 0 to 7)
        yield (i,idxs.filter(_._2 == i).map(_._1))

      Some(usersInRegions.filter(_._2.nonEmpty).map { e=>
        OctreeLeaf(regionFromIndex(aab,centers,e._1),e._2,depth + 1)
      })
    } else {
      None
    }
  }

  def apply[P <: HasFloat3Position](aab:AxisAlignedBox,users:Seq[P],depth:Int):OctreeLeaf[P] = {
    val leaves = split(aab,users,depth)
    new OctreeLeaf(aab,if (leaves.isEmpty) users else Seq(),depth,leaves)
  }

  def decode[P <: HasFloat3Position](reader: ByteStringReader,serializer: PositionSerializer[P]):OctreeLeaf[P] = {
    val aab = AxisAlignedBox.decode(reader)
    val un = VLong.decode(reader).toInt
    val users = 0.until(un).map(_ => serializer.decode(reader))
    val depth = VLong.decode(reader).toInt
    val ln = VLong.decode(reader).toInt
    val leaves = 0.until(ln).map(_ => OctreeLeaf.decode(reader,serializer))

    OctreeLeaf(aab,users,depth,if (ln == 0) None else Some(leaves))
  }
}

class Octree[P <: HasFloat3Position](private val _root:OctreeLeaf[P]) {
  def this(aab:AxisAlignedBox,users:Seq[P]) = this(OctreeLeaf(aab,users,0))

  def query(sp:Sphere):Seq[P] = _root.query(sp).sortWith(_._2 < _._2).map(_._1)
  def query(c:YCylinder):Seq[P] = _root.query(c).sortWith(_._2 < _._2).map(_._1)

  def toByteString(implicit serializer:PositionSerializer[P]): ByteString = {
    _root.toByteString(serializer)
  }

  def ==(other:Octree[P]):Boolean = {
    _root == other._root
  }

  override def equals(obj: Any): Boolean =
    obj.isInstanceOf[Octree[P]] && this == obj.asInstanceOf[Octree[P]]
}

object Octree {
  def determinateRegion[P <: HasFloat3Position](users:Seq[P]):Option[AxisAlignedBox] = {
    users.headOption.map {
      usz =>
      val p = usz.position
      AxisAlignedBox.withMinMax(users.foldRight((p,p)) { (user:P,minmax:(Float3,Float3)) =>
          ((pos:Float3) => (minmax._1.min(pos),minmax._2.max(pos)))(user.position)
        })
    }
  }

  def apply[P <: HasFloat3Position](users:Seq[P]):Option[Octree[P]] = {
    determinateRegion(users) match {
      case Some(region) =>
        Some(new Octree(region,users))
      case _ =>
        None
    }
  }

  def decode[P <: HasFloat3Position](reader:ByteStringReader)(implicit serializer: PositionSerializer[P]):Octree[P] = {
    new Octree(OctreeLeaf.decode(reader,serializer))
  }
}
