package codebook.runtime.math

import akka.util.ByteString
import codebook.runtime.util.{ByteStringHelper, ByteStringReader}

case class Float3(v:Array[Float]) {
  val Epsilon:Float = 0.00001f

  def x:Float = v(0)
  def y:Float = v(1)
  def z:Float = v(2)

  def min(other:Float3): Float3 = Float3.min(this,other)
  def max(other:Float3): Float3 = Float3.max(this,other)

  def +(other:Float3) = Float3(
    (for {
      i <- 0.until(3)
    } yield {
      v(i) + other.v(i)
    }).toArray)
  def -(other:Float3) = Float3(
    (for {
      i <- 0.until(3)
    } yield {
      v(i) - other.v(i)
    }).toArray)
  def +(n:Float) = Float3(v.map(_ + n))
  def /(div:Int) = Float3(v.map(_ / div))
  def length2: Float = // v.map(e => e * e).sum
    (for {
      i <- 0.until(3)
    } yield {
      val e = v(i)
      e * e
    }).sum
  def length: Double = math.sqrt(length2)
  def abs = Float3(v.map(math.abs))

  def ==(other:Float3): Boolean =
    (for {
      i <- 0.until(3)
    } yield {
      math.abs(v(i) - other.v(i)) < Epsilon
//      v(i) == other.v(i)
    }).forall(e => e)

  override def equals(other:Any): Boolean =
    other.isInstanceOf[Float3] && this == other.asInstanceOf[Float3]

  def <(other:Float3): Boolean =
    (for {
      i <- 0.until(3)
    } yield {
      v(i) < other.v(i)
    }).forall(e => e)
  def <=(other:Float3): Boolean =
    (for {
      i <- 0.until(3)
    } yield {
      v(i) <= other.v(i)
    }).forall(e => e)

  def toByteString:ByteString = ByteStringHelper.LE.floatToByteString(x) ++
    ByteStringHelper.LE.floatToByteString(y) ++
    ByteStringHelper.LE.floatToByteString(z)

  override def toString: String = s"($x,$y,$z)"
}

object Float3 {
  def apply(x:Float,y:Float,z:Float):Float3 = Float3(Array(x,y,z))

  def min(a:Float3,b:Float3) =
    Float3(a.v.zip(b.v).map(e => math.min(e._1,e._2)))
  def max(a:Float3,b:Float3) =
    Float3(a.v.zip(b.v).map(e => math.max(e._1,e._2)))

  def decode(reader:ByteStringReader):Float3 = {
    Float3(reader.readFloatLE,reader.readFloatLE,reader.readFloatLE)
  }
}
