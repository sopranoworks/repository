package codebook.runtime.math

object FP16_88 {
  def floatToFP16_88(f:Float):Short = {
    (f * 256).toShort
  }
  def fp1688ToFloat(s:Short):Float = {
    s.toFloat / 256.0f
  }
}

object FP16_124 {
  def floatToFP16_124(f:Float):Short = {
    (f * 16).toShort
  }
  def fp16124ToFloat(s:Short):Float = {
    s.toFloat / 16.0f
  }
}
