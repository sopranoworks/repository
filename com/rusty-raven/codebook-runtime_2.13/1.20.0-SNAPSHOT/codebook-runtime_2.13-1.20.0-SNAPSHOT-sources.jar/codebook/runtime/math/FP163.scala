package codebook.runtime.math

import akka.util.ByteString
import codebook.runtime.util.{ByteStringHelper, ByteStringReader}

trait FP163 {
  def x:Short
  def y:Short
  def z:Short

  def toFloat3:Float3

  def toByteString: ByteString =
    ByteStringHelper.LE.shortToByteString(x) ++
      ByteStringHelper.LE.shortToByteString(y) ++
      ByteStringHelper.LE.shortToByteString(z)

//  override def toString: String = s"($x,$y,$z)"
}

trait FP163Decode {
  def apply(f3:Float3):FP163
  def apply(reader:ByteStringReader):FP163
}

case class FP163_88(x:Short,y:Short,z:Short) extends FP163 {
  import FP16_88._
  def toFloat3:Float3 = Float3(fp1688ToFloat(x),fp1688ToFloat(y),fp1688ToFloat(z))
}

case class FP163_124(x:Short,y:Short,z:Short) extends FP163 {
  import FP16_124._
  def toFloat3:Float3 = Float3(fp16124ToFloat(x),fp16124ToFloat(y),fp16124ToFloat(z))
}

object FP163_88 extends FP163Decode {
  import FP16_88._
  def apply(f3:Float3):FP163 = FP163_88(floatToFP16_88(f3.x),floatToFP16_88(f3.y),floatToFP16_88(f3.z))
  def apply(reader:ByteStringReader):FP163 = FP163_88(reader.readShortLE,reader.readShortLE,reader.readShortLE)
}

object FP163_124 extends FP163Decode {
  import FP16_124._
  def apply(f3:Float3):FP163 = FP163_124(floatToFP16_124(f3.x),floatToFP16_124(f3.y),floatToFP16_124(f3.z))
  def apply(reader:ByteStringReader):FP163 = FP163_124(reader.readShortLE,reader.readShortLE,reader.readShortLE)
}
