/**
  * codebook.runtime.storage.MongoDBConnector
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  *
  */
package codebook.runtime.storage
/*
import akka.event.slf4j.SLF4JLogging
import com.mongodb._
import com.typesafe.config.Config
import net.liftweb.mongodb.MongoDB
import net.liftweb.util.ConnectionIdentifier

import collection.JavaConversions._

/**
  * A mongo db connection utility class
  */
trait MongoDBConnector extends ConnectionIdentifier with SLF4JLogging {
  private var _mongo:Option[MongoClient] = None

  /**
    * You should overwrite this for your own configuration.
    * @return MongoClientOptions
    */
  def mongoOptions:MongoClientOptions = MongoClientOptions.builder().build()

  /**
    * Connecting to mongo db
    * @param hosts host address list
    * @param dbName A database name
    * @param user A database user name (optional)
    * @param password A database user password (optional)
    */
  def connect(hosts:List[ServerAddress],dbName:String,user:Option[String],password:Option[String]):Unit =
    synchronized {
      _mongo match {
        case None =>
          val creds = for {
            u <- user
            p <- password
          } yield {
            MongoCredential.createMongoCRCredential(u,dbName,p.toCharArray)
          }

          log.info(s"Connecting to database:$dbName at $hosts")
          _mongo = Option(if (hosts.length == 1)
              creds.map(c => new MongoClient(hosts.head, List(c), mongoOptions)).getOrElse(new MongoClient(hosts.head, mongoOptions))
             else
              creds.map(c => new MongoClient(hosts,List(c),mongoOptions)).getOrElse(new MongoClient(hosts,mongoOptions)
            )
          )
          _mongo.getOrElse(log.error("Create MongoClient failure"))
          _mongo.foreach(m=>MongoDB.defineDb(this,m,dbName))
        case _ =>
      }
    }

  private def _hostsToServerAddress(hosts:List[String]):Option[List[ServerAddress]] = try {
    Some(hosts.map {
      host =>
        val v = host.split(':')
        if (v.length >= 2) {
          new ServerAddress(v(0).trim,v(1).toInt)
        } else {
          new ServerAddress(v(0).trim)
        }
    })
  } catch {
    case _ : Throwable =>
      log.error("invalid port expression")
      None
  }

  private def _safe_read[T](config:Config,key:String)(f:(Config,String) => T):Option[T] = try {
    Some(f(config,key))
  } catch {
    case _ : Throwable =>
      log.info("key not found on the configuration:" + key)
      None
  }

  /**
    * Connecting to mongo db using configuration file
    * @param config the configuration file
    * @return success or not
    */
  def connect(config:Config):Boolean =
    (for {
      hosts <-_safe_read(config,"hosts") { _.getStringList(_) }
      dbName<-_safe_read(config,"dbname") { _.getString(_) }
      addrs <-_hostsToServerAddress(hosts.toList)
    } yield {
      val user = _safe_read(config,"user") { _.getString(_)}
      val password = _safe_read(config,"password") { _.getString(_)}

      connect(addrs,dbName,user,password)
      true
    }).getOrElse(false)

  /**
    * Disconnecting from mongo db
    */
  def disconnect():Unit = {
    synchronized {
      _mongo.foreach {
        m =>
          m.close()
          MongoDB.closeAll()
      }
      _mongo = None
    }
  }
}

 */
