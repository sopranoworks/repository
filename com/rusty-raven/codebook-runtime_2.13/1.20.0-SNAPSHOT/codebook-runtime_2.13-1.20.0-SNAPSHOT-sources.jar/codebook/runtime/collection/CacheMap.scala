package codebook.runtime.collection

import scala.concurrent.Future

trait CacheMap[V] {
  protected def _map:Map[String,V]

  def get(key:String):Option[V] = _map.get(key)
  def getAll:Map[String,V] = _map

  def addOne(elem: (String, V)): Future[Boolean]
  def addAll(map:Map[String,V]):Future[Boolean]
  def subtractOne(key: String): Future[Boolean]
  def refresh():Future[Boolean]

  def +=(elem: (String, V)): Future[Boolean] =
    addOne(elem)

  def -=(key: String): Future[Boolean] =
    subtractOne(key)
}
