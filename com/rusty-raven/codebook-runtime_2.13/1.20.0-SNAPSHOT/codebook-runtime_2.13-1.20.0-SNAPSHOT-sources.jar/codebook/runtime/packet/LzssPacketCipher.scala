package codebook.runtime.packet
import akka.util.ByteString
import codebook.runtime.protocol.VLong
import codebook.runtime.util.{ByteStringHelper, ByteStringReader}

class LzssPacketCipher extends PacketCipher {

  private def _findMatch(bytes: ByteString, p: Int, dic: Int, limit: Int):(Boolean,Int,Int) = {
    if (dic == 0) {
      (false,0,1)
    } else {
      var maxLen = 0
      var maxLenPos = 0
      var hit = false
      val d = bytes(p)

      (dic until 0 by -1).foreach {
        i =>
          if (bytes(p - i) == d) {
            var t = 1
            while(t < 4096 + 2 && p + t < limit && bytes(p - i + t) == bytes(p + t)) {
              t += 1
            }
            if (t >= 2 && maxLen < t) {
              maxLen = t
              maxLenPos = i
              hit = true
            }
          }
      }
      (hit,maxLenPos,if (hit) maxLen else 1)
    }
  }

  /**
    * Encrypting input bytes
    *
    * @param bytes source bytes
    * @return encrypted bytes
    */
  override def encrypt(bytes: ByteString): Option[ByteString] = {
    var body = ByteString()
    val limit = bytes.length
    var l = limit
    var p = 0
    var dic = 0

    while(l > 0) {
      var flag = 0
      var chunk = ByteString()

      var j = 0

      while(j < 8 && l > 0) {
        val (hit:Boolean,pos:Int,len:Int) = _findMatch(bytes,p,dic,limit)
        if (hit) {
          flag |= 1 << j
          val code = (((pos - 1) & 0x0f) << 12) | ((len - 2) & 0xfff)
          chunk ++= ByteStringHelper.LE.shortToByteString(code.toShort)
        } else {
          chunk ++= ByteString(bytes(p))
        }
        p += len
        if (dic < 16) {
          dic += len
          if (dic > 16) dic = 16
        }
        l -= len
        j += 1
      }
      body ++= ByteString(flag.toByte) ++ chunk
      if (body.length >= limit) l = 0 // break compression
    }
    if (body.length < limit) {
      val res = VLong(limit).toByteString ++ body
      if (res.length < limit) Some(res) else None
    } else None
  }

  /**
    * Decrypting input bytes
    *
    * @param bytes source bytes
    * @return decrypted bytes
    */
  override def decrypt(bytes: ByteString): Option[ByteString] = {
    val reader = ByteStringReader(bytes)

    try {
      val limit = VLong(reader).v
      var len = 0

      var dst = ByteString()

      while(len < limit) {
        val flag = reader.readByte.toInt

        var i = 0
        while(i < 8 && len < limit) {
          if ((flag & (1 << i)) != 0) {
            val code = reader.readShortLE
            val pos =((code >> 12) & 0x0f) + 1
            val sz = (code & 0x0fff) + 2
            val p = dst.length

            (0 until sz).foreach (j => dst ++= ByteString(dst(p - pos + j)))
            len += sz
          } else {
            dst ++= ByteString(reader.readByte)
            len += 1
          }
          i += 1
        }
      }
      Some(dst)
    } catch {
      case _ : Throwable =>
        None
    }
  }
}
