/**
  * codebook.runtime.packet.PacketCipher
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.packet

import akka.util.ByteString

/**
 * The Packet Cipher Trait
 */
trait PacketCipher {
  /**
   * Encrypting input bytes
   * @param bytes source bytes
   * @return encrypted bytes
   */
  def encrypt(bytes:ByteString):Option[ByteString]

  /**
   * Decrypting input bytes
   * @param bytes source bytes
   * @return decrypted bytes
   */
  def decrypt(bytes:ByteString):Option[ByteString]
}

/**
  * THe AES cipher using JCE class
  * YOU MUST SET UNLIMITED KEY LENGTH SECURITY POLICY FILE!
  * (If not, you can not use 256 bits AES.)
  */
final class AESPacketCipher(key:ByteString) extends PacketCipher {
  private val _encryptor = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5PADDING")
  private val _decryptor = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5PADDING")
  private val _secret = new javax.crypto.spec.SecretKeySpec(key.toArray,"AES")
  private val _iv = new javax.crypto.spec.IvParameterSpec(Array.fill(_blockSize)(0:Byte))

  private lazy val _blockSize = _encryptor.getBlockSize

  _encryptor.init(javax.crypto.Cipher.ENCRYPT_MODE,_secret,_iv)
  _decryptor.init(javax.crypto.Cipher.DECRYPT_MODE,_secret,_iv)

  def encrypt(bytes:ByteString):Option[ByteString] =
    Some(ByteString(_encryptor.doFinal(bytes.toArray)))

  def decrypt(bytes:ByteString):Option[ByteString] =
    Some(ByteString(_decryptor.doFinal(bytes.toArray)))
}

/**
 * The Dummy Packet Cipher class
 * Nothing to do
 */
final class DummyPacketCipher extends PacketCipher {
  override def encrypt(bytes:ByteString):Option[ByteString] = None
  override def decrypt(bytes:ByteString):Option[ByteString] = Some(bytes)
}
