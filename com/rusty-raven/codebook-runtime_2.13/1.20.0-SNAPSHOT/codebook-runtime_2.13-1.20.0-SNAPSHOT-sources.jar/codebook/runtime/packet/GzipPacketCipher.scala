package codebook.runtime.packet
import java.io.{ByteArrayInputStream, ByteArrayOutputStream}
import java.nio.ByteBuffer
import java.nio.channels.Channels
import java.util.zip.{GZIPInputStream, GZIPOutputStream}

import akka.util.ByteString

class GzipPacketCipher extends PacketCipher {
  val INFLATE_BUFFER_SIZE = 1024

  /**
    * Encrypting input bytes\
    *
    * @param bytes source bytes
    * @return encrypted bytes
    */
  override def encrypt(bytes: ByteString): Option[ByteString] = {
    val dst = new ByteArrayOutputStream()
    val gout = new GZIPOutputStream(dst)
    gout.write(bytes.toArray)
    gout.finish()
    val enc = ByteString(dst.toByteArray)
    if (enc.length < bytes.length) Some(enc) else None
  }

  /**
    * Decrypting input bytes
    *
    * @param bytes source bytes
    * @return decrypted bytes
    */
  override def decrypt(bytes: ByteString): Option[ByteString] = {
    var dst = ByteString()
    val gin = new GZIPInputStream(new ByteArrayInputStream(bytes.toArray))
    val ch = Channels.newChannel(gin)
    var l:Int = 0

    do {
      val out = ByteBuffer.allocate(INFLATE_BUFFER_SIZE)
      l = ch.read(out)
      if (l > 0) {
        out.flip()
        dst ++= ByteString(out)
      }
    } while(l > 0)

    Some(dst)
  }
}
