/**
  * codebook.runtime.packet.PacketReader
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.packet

import akka.event.slf4j.SLF4JLogging
import akka.util.ByteString
import codebook.runtime.protocol.VLong
import codebook.runtime.util.ByteStringReader

/**
  * The Packet reader from ByteString class
  */
class PacketReader extends SLF4JLogging {
  private var _state = 0
  private var _length = 0
  private var _previousBytes = ByteString()
  private var _encrypted = false

  /**
    * The picking up packets from byte string method
    * @param bytes a source byte string
    * @return List of packets or None
    */
  def pickup(bytes:ByteString):Option[List[Packet]] = {
    var buf = _previousBytes ++ bytes
    var packets = List.empty[Packet]
    var loop = false

    do {
      loop = false
      _state match {
        case 0 =>
          try {
            val reader = ByteStringReader(buf)
            val vl = VLong.decode(reader).toInt
            buf = buf.drop(buf.length - reader.length)

            _length = if (vl < 0) {
              _encrypted = true
              -vl
            } else {
              _encrypted = false
              vl
            }

            if (_length > Packet.MAX_PACKET_SIZE) {
              log.warn(s"Invalid Packet Length:Too Long => ${_length}")
              throw new RuntimeException(s"Invalid Packet Length:Too Long => ${_length}")
            }
            _state = 1
            loop = true
          } catch {
            case _ : IndexOutOfBoundsException =>
          }

        case 1 =>
          if (buf.length >= _length + 2) {
            val body = buf.slice(0,_length)
            buf = buf.drop(_length)
            val crc = ByteStringReader(buf).readShortLE
            buf = buf.drop(2)

            _state = 0
            val crc2 = Packet.calcCRC(body)
            if (crc != crc2) {
              log.warn(s"CRC unmatched:$crc <=> $crc2")
              throw new RuntimeException(s"CRC unmatched:$crc <=> $crc2")
            }

            packets ++= List(new Packet(body,_encrypted))
            loop = true
          }
      }
    } while(loop)

    _previousBytes = buf

    if (packets.isEmpty) None else Some(packets)
  }
}
