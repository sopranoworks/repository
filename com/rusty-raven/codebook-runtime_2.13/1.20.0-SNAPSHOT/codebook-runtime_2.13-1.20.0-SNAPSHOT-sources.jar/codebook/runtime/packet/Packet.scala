/**
  * codebook.runtime.packet.Packet
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.packet

import akka.event.slf4j.SLF4JLogging
import akka.util.ByteString
import codebook.runtime.protocol.VLong
import codebook.runtime.util.ByteStringReader
import codebook.runtime.util.ByteStringHelper.LE._

/**
  * The packet class
  * @param bytes a packet body
  * @param encrypted a flag if this packet is encrypted or not
  */
case class Packet(bytes:ByteString,encrypted:Boolean = false) extends SLF4JLogging {
  private val _crc = Packet.calcCRC(bytes)

  def crc: Short = _crc

  /**
   * Encrypt this if needed
   * @param cipher PacketCipher currently uses
   * @return Encrypted packet or myself
   */
  def encode(cipher:PacketCipher): Packet =
    if (encrypted) {
      this
    } else {
      val b = toByteString
      cipher.encrypt(b).map(enc=>Packet(enc,true)).getOrElse(this)
    }

  /**
    Decode the packet with the cipher if encrypted
    If not, return self
    @param cipher the PacketCipher
    @return decrypted packet or self
  */
  def decode(cipher:PacketCipher):Option[Packet] = if (!encrypted) Some(this) else {
    try {
      cipher.decrypt(bytes).map { b =>

        val src = ByteStringReader(b)
        val pl = VLong(src).v.toInt

        val enc = if (pl < 0) true else false
        val l = math.abs(pl)

        if (l + 2 > src.length) {
          throw new RuntimeException("Packet corrupted")
        }

        val pkt = Packet(src.readBytes(l), enc)
        val crc = src.readShortLE

        if (crc != pkt.crc) {
          throw new RuntimeException("Invalid CRC")
        }

        pkt
      }
    } catch {
      case e : Throwable =>
        log.error(e.toString)
        None
    }
  }

  def ==(other:Packet) =
    bytes == other.bytes && encrypted == other.encrypted

  def toByteString:ByteString = {
    VLong(if (encrypted) -bytes.length else bytes.length).toByteString ++ bytes ++ _crc
  }
  def length = bytes.length
  override def toString = "Packet(" + bytes.toList.map("%02x".format(_)).mkString(",") + ")"
}

object Packet {
  final val MAX_PACKET_SIZE = 5000
  def calcCRC(bytes:ByteString) =
    ((bytes.map(_.toInt).reduce((v,o) => v + o).toShort)^0xffff).toShort

  def pickupFromBytes(bytes:ByteString):Option[Packet] = {
    val lb = VLong.usedBytes(bytes)
    if (lb > 0 && bytes.length >= lb + 2) {
      val reader = ByteStringReader(bytes)
      val l = VLong.apply(reader).v.toInt
      val enc = if (l < 0) true else false

      val ll = math.abs(l)
      if (bytes.length >= lb + 2 + l) {
        val body = reader.readBytes(ll)
        val crc = reader.readShortLE
        if (calcCRC(body) == crc) {
          return Some(Packet(body,enc))
        }
      }
    }
    None
  }
}

trait PacketConversion {
  implicit def byteStringToPacket(bytes:ByteString) = Packet(bytes)
  implicit def packetToByteString(pkt:Packet) = pkt.bytes
}
