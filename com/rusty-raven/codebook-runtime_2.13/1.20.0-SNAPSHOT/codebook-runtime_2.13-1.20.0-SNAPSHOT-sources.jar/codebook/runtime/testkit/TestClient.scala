package codebook.runtime.testkit

import akka.actor.{Actor, ActorRef, ActorSystem, Props}
import akka.io.Tcp.{Close, Write}
import akka.pattern.ask
import akka.util.ByteString
import codebook.runtime.io.TcpClientPort
import codebook.runtime.packet.{DummyPacketCipher, Packet, PacketCipher}
import codebook.runtime.protocol.{Decoder, Request, SystemMessages}
import codebook.runtime.util.ByteStringReader

import scala.collection.mutable.{Queue => MQueue}
import scala.concurrent.duration.{Duration, FiniteDuration}
import scala.concurrent.{Await, Future}
import scala.reflect.ClassTag

abstract class TestClient[RES:ClassTag] {
  import codebook.runtime.util.TimeLimits._

  private var _port:Option[ActorRef] = None
  private var _receiver:Option[ActorRef] = None
  private var _timestamp = 0L
  private var _connected = false

  def connected:Boolean = _connected

  def hostname:String
  def port:Int
  def decoder:Decoder

  val packetCipher:PacketCipher = new DummyPacketCipher
  val queuing:Boolean = true

  def periodical:Boolean = false
  def PERIODICAL_PROC_DURATION:FiniteDuration = Duration.Zero

  private case object Check
  private case object PickUp
  private case object Tick

  def timestamp:Long = {
    val t = _timestamp
    _timestamp += 1
    t
  }

  def decodeResponsePacket(bytes:ByteString):Option[Any] =
    decoder.decodeResponse(ByteStringReader(bytes))

  def periodicalProc():Unit = {

  }

  private case class ReceiverState(
    requester:Option[ActorRef] = None,
    messageQueue:MQueue[Any] = MQueue.empty,
    socket:Option[ActorRef] = None)

  private class Receiver extends Actor {

    override def preStart(): Unit = {
      if (periodical) {
        context.system.scheduler.scheduleWithFixedDelay(Duration.Zero,PERIODICAL_PROC_DURATION,self,Tick)(context.dispatcher)
      }
    }

    def receive: Receive = process(ReceiverState())

    def process(receiverState: ReceiverState): Receive = {
      case socket:ActorRef =>
//        _socket = Some(socket)
        context.become(process(receiverState.copy(socket = Some(socket))))

      case Check =>
        if (receiverState.messageQueue.nonEmpty) {
          receiverState.requester.foreach(_ ! receiverState.messageQueue.dequeue())
//          _requester = None
          context.become(process(receiverState.copy(requester = None)))
        } else {
          context.system.scheduler.scheduleOnce(Duration(1,"s"),self,Check)(context.system.dispatcher)
        }

      case PickUp =>
        self.forward(Check)
        context.become(process(receiverState.copy(requester = Some(sender()))))

      case Tick =>
        periodicalProc()

      case Close =>
        receiverState.socket.foreach(_ ! Close)
        context.stop(self)

      case pkt: Packet =>
        pkt.decode(packetCipher).foreach {
          dpkt =>
            decodeResponsePacket(dpkt.bytes).foreach(self.forward(_))
        }

      case wrt @ Write(bytes, _) =>
        _port match {
          case Some(_) =>
            receiverState.socket.foreach (_! wrt)
          case None =>
            receiverState.socket.foreach (_ ! bytes)
        }

      case bytes:ByteString =>
        _port match {
          case Some(_) =>
            receiverState.socket.foreach(_ ! Write(bytes))
          case None =>
            receiverState.socket.foreach (_ ! bytes)
        }

      case c @ SystemMessages.Connected =>
        _connected = true
        if (queuing) {
          receiverState.messageQueue.enqueue(c)
        }

      case x =>
        if (queuing) {
          receiverState.messageQueue.enqueue(x)
        }
    }
  }
  
  def connect()(implicit system:ActorSystem):Unit = {
    val receiver = system.actorOf(Props(new Receiver))
    val h = hostname
    val p = port
    val prt = system.actorOf(Props(new TcpClientPort {
      override def hostname: String = h
      override def createServiceActor(socket: ActorRef): ActorRef = {
        receiver ! socket
        receiver
      }
      override def port: Int = p
    }))
    _port = Some(prt)
    _receiver = Some(receiver)
  }

  def connect(socket:ActorRef)(implicit system:ActorSystem):Unit = {
    val receiver = system.actorOf(Props(new Receiver))
    receiver ! socket
    _receiver = Some(receiver)
  }

  def disconnect():Unit = {
    if (_port.nonEmpty) {
      _receiver.foreach(_ ! Close)
    }
    _port = None
    _receiver = None
  }

  def send(bytes:ByteString):Unit = {
    _port match {
      case Some(_) =>
        _receiver.foreach(_ ! Write(bytes))
      case None =>
        _receiver.foreach(_ ! bytes)
    }
  }

  def send(req:Request):Unit = {
    send(new Packet(req.toByteString).encode(packetCipher).toByteString)
  }

  def expectMsg[T](max: FiniteDuration, obj: T): T = {
    if (receiveOne(max) != obj) throw new RuntimeException("Not expected object received")
    obj
  }

  def receiveOne(max: FiniteDuration): AnyRef =
    _receiver.map {
      rcv =>
        val f = rcv.ask(PickUp)(max)
        try {
          Await.result(f.mapTo[AnyRef], max)
        } catch {
          case _ : java.util.concurrent.TimeoutException =>
            null
        }
    }.orNull

  def receive: RES = {
    val r = receiveOne(Duration(5, "s"))
    r.asInstanceOf[RES]
  }

  def waitUntilKindOf(chk:RES => Boolean)(implicit system:ActorSystem): RES = {
    val f = Future {
      var r: Option[RES] = None
      do {
        r = Option(receive)
      } while (r.forall(chk))
      r.get
    }(system.dispatcher)
    Await.result(f.mapTo[RES], _60s)
  }
}
