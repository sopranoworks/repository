package codebook.runtime.profile

import akka.actor.{Actor, ActorRef, ActorSystem, Props}
import codebook.runtime.util.HasAkkaConfig

object Profiling {
  def prof[T](name:String,f: => T)(implicit profiler:Profiler):T = {
    val t = profiler.begin(name)
    try {
      val r = f
      profiler.end(t)
      r
    } catch {
      case e : Exception =>
        profiler.cancel(t)
        throw e
    }
  }
}

class Profiler extends HasAkkaConfig {
  case class Profile(name:String, min:Long, max:Long, total:Long, count:Long, error:Long)
  case class Token(name:String, tid:Long)
  private case class Begin(token: Token, time:Long)
  private case class Result(token:Token, time:Long)
  private case class Cancel(token: Token)

  private case class ShareData(
    var _measurements:Map[Long,Long] = Map.empty[Long,Long],
    var _profiles:Map[String,Profile] = Map.empty[String,Profile]
  )

  private var _token:Long = 0
  private var _system:Option[ActorSystem] = None
  private var _worker:Option[ActorRef] = None
  private val _data = ShareData()

  private class Worker(data: ShareData) extends Actor {
    private object CleanUp

    private def _beginMeasurement(begin: Begin): Unit =
      data._measurements += begin.token.tid->begin.time

    private def _finishMeasurement(result: Result): Unit = {
      data._measurements.get(result.token.tid) match {
        case Some(t) =>
          val d = result.time - t
          val name = result.token.name
          data._profiles.get(name) match {
            case Some(profile) =>
              data._profiles += name->profile.copy(
                min = if (profile.min > d) d else profile.min,
                max = if (profile.max < d) d else profile.max,
                total = profile.total + d,
                count = profile.count + 1)
            case None =>
              data._profiles += name->Profile(name, d, d, d, 1, 0)
          }
        case None =>
          // no entry
      }
    }

    private def _cancelMeasurement(token: Token): Unit = {
      data._measurements.get(token.tid) match {
        case Some(t) =>
          val name = token.name
          data._profiles.get(name) match {
            case Some(profile) =>
              data._profiles += name -> profile.copy(error = profile.error + 1)
            case None =>
              data._profiles += name -> Profile(name,Long.MaxValue,Long.MinValue,0,0,1)
          }
        case None =>
          // no entry
      }
    }

    override def receive: Receive = {
      case b:Begin =>
        _beginMeasurement(b)
      case r:Result =>
        _finishMeasurement(r)
      case Cancel(token) =>
        _cancelMeasurement(token)
      case CleanUp =>
    }
  }

  def profileSetName = "default"
  
  def startProfiling(actorSystem:Option[ActorSystem] = None): Unit = {
    val system = actorSystem.getOrElse(ActorSystem(profileSetName + "ProfilingSystem"))
    _system = Some(system)
    _worker = Option(system.actorOf(Props(new Worker(_data)),"Worker"))
  }

  def endProfiling(): Unit = {
    _system.foreach {
      sys =>
        sys.terminate()
        _system = None
        _worker = None
    }
  }

  def begin(name:String):Token =
    _worker match {
      case Some(worker) =>
        val t = Token(name,synchronized {
                  val tt = _token
                  _token += 1
                  tt
                })
        worker ! Begin(t,System.currentTimeMillis())
        t
      case None =>
        Token(name,0)
    }

  def end(token:Token): Unit =
    _worker.foreach(_ ! Result(token,System.currentTimeMillis()))


  def cancel(token: Token): Unit =
    _worker.foreach(_ ! Cancel(token))

  def results:Iterable[Profile] = _data._profiles.values

//  startProfiling()
}

object DefaultProfiler {
  implicit /* lazy */val defaultProfiler:Profiler = new Profiler
}
