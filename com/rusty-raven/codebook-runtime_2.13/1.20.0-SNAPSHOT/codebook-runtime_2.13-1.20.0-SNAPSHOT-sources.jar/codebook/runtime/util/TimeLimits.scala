/**
  * codebook.runtime.util.TimeLimits
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.util

import scala.concurrent.duration.Duration
import akka.util.Timeout

/**
  * The collection of time limit utility
  */
object TimeLimits {
  lazy val _1s = Duration(1,"s")
  lazy val _3s = Duration(3,"s")
  lazy val _5s = Duration(5,"s")
  lazy val _10s = Duration(10,"s")
  lazy val _15s = Duration(15,"s")
  lazy val _20s = Duration(20,"s")
  lazy val _30s = Duration(30,"s")
  lazy val _60s = Duration(60,"s")
  lazy val _120s = Duration(120,"s")
  lazy val _300s = Duration(300,"s")

  object timeout3s {
    implicit val timeout = Timeout(_3s)
  }
  object timeout5s {
    implicit val timeout = Timeout(_5s)
  }
  object timeout10s {
    implicit val timeout = Timeout(_10s)
  }
  object timeout15s {
    implicit val timeout = Timeout(_15s)
  }
  object timeout20s {
    implicit val timeout = Timeout(_20s)
  }
  object timeout30s {
    implicit val timeout = Timeout(_30s)
  }
  object timout60s {
    implicit val timeout = Timeout(_60s)
  }
  object timeout120s {
    implicit val timeout = Timeout(_120s)
  }
  object timeout300s {
    implicit val timeout = Timeout(_300s)
  }
}
