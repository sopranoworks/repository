package codebook.runtime.util

import scala.collection.mutable

class dSFMT {

  val DSFMT_MEXP = 19937
  val DSFMT_N = (DSFMT_MEXP - 128) / 104 + 1
  val DSFMT_N32 = DSFMT_N * 4
  val DSFMT_N64 = DSFMT_N * 2
  val DSFMT_SR = 12

  private val DSFMT_LOW_MASK = 0x000FFFFFFFFFFFFFL
  private val DSFMT_HIGH_CONST = 0x3FF0000000000000L
  private val DSFMT_POS1 = 37
  private val DSFMT_SL1	= 19
  private val DSFMT_MSK1 = 0x000ffffffdf7fffdL
  private val DSFMT_MSK2 = 0x000dfffffff6bfffL
  private val DSFMT_FIX1 = 0xd0ef7b7c75b06793L
  private val DSFMT_FIX2 = 0x9c50ff4caae0a641L
  private val DSFMT_PCV1 = 0x8234c51207c80000L
  private val DSFMT_PCV2 = 0x0000000000000001L

/*  dSFMT-params11213.h
#define DSFMT_SL1	19
#define DSFMT_MSK1	UINT64_C(0x000ffffffdf7fffd)
#define DSFMT_MSK2	UINT64_C(0x000dfffffff6bfff)
#define DSFMT_MSK32_1	0x000fffffU
#define DSFMT_MSK32_2	0xfdf7fffdU
#define DSFMT_MSK32_3	0x000dffffU
#define DSFMT_MSK32_4	0xfff6bfffU
#define DSFMT_FIX1	UINT64_C(0xd0ef7b7c75b06793)
#define DSFMT_FIX2	UINT64_C(0x9c50ff4caae0a641)
#define DSFMT_PCV1	UINT64_C(0x8234c51207c80000)
#define DSFMT_PCV2	UINT64_C(0x0000000000000001)
#define DSFMT_IDSTR	"dSFMT2-11213:37-19:ffffffdf7fffd-dfffffff6bfff"
 */


  @inline
  private def u_l(i:Int) = i.toLong & 0xffffffffL

  @inline
  private def ulsr(l:Long,i:Int) = ((l >> 1) & 0x7fffffffffffffffL) >> (i - 1)

  class W128 {
    val d = mutable.ArrayBuffer[Double](0,0)
    // var uint64 u[2]
    // var uint32 u32[4]
    def init(i1:Int,i2:Int,i3:Int,i4:Int):Unit = {
      d(0) = l_d((u_l(i2) << 32) + u_l(i1))
      d(1) = l_d((u_l(i4) << 32) + u_l(i3))
    }
  }
  object W128 {
    def apply(w:W128):W128 = {
      val ww = new W128
      ww.d(0) = w.d(0)
      ww.d(1) = w.d(1)
      ww
    }
    def apply(i1:Int,i2:Int,i3:Int,i4:Int):W128 = {
      val ww = new W128
      ww.init(i1,i2,i3,i4)
      ww
    }
  }

  private val status = new mutable.ArrayBuffer[W128](DSFMT_N + 1)
  private var idx = 0

  @inline
  private def d_l(d:Double) = java.lang.Double.doubleToLongBits(d)

  @inline
  private def l_d(l:Long) = java.lang.Double.longBitsToDouble(l)

  @inline
  private def d_l_d(d:Double)(f:Long => Long):Double = l_d(f(d_l(d)))

  @inline
  private def do_recursion(r:W128,a:W128,b:W128,lung:W128):Unit = {
    val t0 = d_l(a.d(0))
    val t1 = d_l(a.d(1))
    val L0 = d_l(lung.d(0))
    val L1 = d_l(lung.d(1))
    val lung_u0 = (t0 << DSFMT_SL1) ^ ((L1 >> 32) & 0xffffffffL) ^ (L1 << 32) ^ d_l(b.d(0))
    val lung_u1 = (t1 << DSFMT_SL1) ^ ((L0 >> 32) & 0xffffffffL) ^ (L0 << 32) ^ d_l(b.d(1))
    lung.d(0) = l_d(lung_u0)
    lung.d(1) = l_d(lung_u1)

    r.d(0) = l_d( ulsr(lung_u0,DSFMT_SR) ^ (lung_u0 & DSFMT_MSK1) ^ t0)
    r.d(1) = l_d( ulsr(lung_u1,DSFMT_SR) ^ (lung_u1 & DSFMT_MSK2) ^ t1)
  }

  private def _gen_rand_all(): Unit = {
    val lung = W128(status(DSFMT_N))

    do_recursion(status(0),status(0),status(DSFMT_POS1),lung)
    (1 until DSFMT_N - DSFMT_POS1).foreach(i => do_recursion(status(i),status(i),status(i + DSFMT_POS1),lung))
    (DSFMT_N - DSFMT_POS1 until DSFMT_N).foreach(i => do_recursion(status(i),status(i),status(i + DSFMT_POS1 - DSFMT_N),lung))
    status(DSFMT_N) = lung
  }

  def genrand_close1_open2:Double = {
    if (idx >= DSFMT_N64) {
      _gen_rand_all()
      idx = 0
    }
    val r = status(idx / 2).d(idx % 2)
    idx += 1
    r
  }

  def genrand_close_open:Double =
    genrand_close1_open2 - 1.0

  def random = genrand_close_open

  private def initial_mask(): Unit = {
    (0 until DSFMT_N).foreach {
      i=>
        status(i).d(0) = d_l_d(status(i).d(0))(l=>(l & DSFMT_LOW_MASK) | DSFMT_HIGH_CONST)
        status(i).d(1) = d_l_d(status(i).d(1))(l=>(l & DSFMT_LOW_MASK) | DSFMT_HIGH_CONST)
    }
  }

  private def period_certification(): Unit = {
    val pcv = mutable.ArrayBuffer(DSFMT_PCV1,DSFMT_PCV2)
    val tmp = mutable.ArrayBuffer(d_l(status(DSFMT_N).d(0)) ^ DSFMT_FIX1,d_l(status(DSFMT_N).d(1)) ^ DSFMT_FIX2)

    var inner = tmp(0) & pcv(0)
    inner ^= tmp(1) & pcv(1)

    var i = 32
    while (i > 0) {
      val v = (inner >> 1) & 0x7fffffffffffffffL
      inner ^= (v >> (i - 1))
      i >>= 1
    }
    inner &= 1

    if (inner == 1)
      return

    status(DSFMT_N).d(1) = d_l_d(status(DSFMT_N).d(1))(_ ^ 1)
  }

  private def _chk_init_gen_rand(seed:Int,mexp:Int):Unit = {

    var prev = seed
    val init = Array(seed) ++ (1 until (DSFMT_N + 1) * 4).map {
      i=>
        val p = prev & 0xffffffffL
        val v = (1812433253L * (p ^ (p >> 30)) + i).toInt
        prev = v
        v
    }
    (0 until DSFMT_N + 1).foreach(i=>status += W128(init(i * 4),init(i * 4 + 1),init(i * 4 + 2),init(i * 4 + 3)) )
    initial_mask()
    period_certification()
    idx = DSFMT_N64
  }

  @inline
  def init_gen_rand(seed:Int):Unit = {
    _chk_init_gen_rand(seed,DSFMT_MEXP)
  }
}

object dSFMT {
  def apply(seed:Int = 12345):dSFMT = {
    val d = new dSFMT
    d.init_gen_rand(seed)
    d
  }
}