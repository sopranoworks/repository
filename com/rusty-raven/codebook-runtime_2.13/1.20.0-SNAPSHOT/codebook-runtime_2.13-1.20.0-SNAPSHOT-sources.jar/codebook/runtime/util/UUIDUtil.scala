/**
  * codebook.runtime.util.UUIDUtil
  *
  * Copyright (c) 2016-2017 Osamu Takahashi
  * Copyright (c) 2016-2017 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.util

import java.nio.ByteBuffer
import java.util.UUID

object UUIDUtil {
  implicit class UUIDConverter(uuid:UUID) {
    def asByteArray:Array[Byte] = {
      val bb = ByteBuffer.wrap(new Array[Byte](16))
      bb.putLong(uuid.getMostSignificantBits)
      bb.putLong(uuid.getLeastSignificantBits)
      bb.array()
    }
  }

  implicit class ArrayConverter(bytes:Array[Byte]) {
    def asUuid:UUID = {
      val bb = ByteBuffer.wrap(bytes)
      val firstLong = bb.getLong()
      val secondLong = bb.getLong()
      new UUID(firstLong, secondLong)
    }
  }
}