/**
  * codebook.runtime.util.UIDPublisher
  *
  * Copyright (c) 2016-2017 Osamu Takahashi
  * Copyright (c) 2016-2017 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.util

/**
  * Twitter's snowflake style uid publisher trait
  */
trait UIDPublisher {
  /**
    * @return A publisher unit id(0-1023)
    */
  def unitId:Int

  private var _currentTime:Long = 0
  private var _seq:Int = 0
  private lazy val _unitIdField = (unitId & 0x3ff) << 12
  private var _currentTimeField:Long = 0

  private val DATE_BASE = 1454252400000L // 2016/1/1

  private def _newCurrentTime(t:Long):Unit = {
    _currentTime = t
    _currentTimeField = (_currentTime - DATE_BASE) << 22
    _seq = 0
  }

  /**
    * publishing new uid
    * @return a new uid
    */
  def publish:Long = {
    val t = System.currentTimeMillis()
    if (_currentTime == 0 || _currentTime < t) {
      _newCurrentTime(t)
    } else {
      _seq += 1
      if (_seq > 4095) {
        _newCurrentTime(_currentTime + 1)
      }
    }
    _currentTimeField + _unitIdField + _seq
  }

  def safePublish: Long = synchronized(publish)
}
