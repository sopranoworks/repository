/**
  * codebook.runtime.util.ByteStringHelper
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Ossamu Takahashi
  */
package codebook.runtime.util

import akka.util.ByteString
import codebook.runtime.protocol.VLong

/**
 * The case class for reading from target ByteString
 * @param bytes target ByteString
 */
case class ByteStringReader(bytes:ByteString) {
  private var _pos = 0

  /**
   * The reading byte value from ByteString method
   * @return a byte value
   */
  def readByte:Byte = {
    val v = bytes(_pos)
    _pos += 1
    v
  }

  /**
   * The reading LITTLE ENDIAN short value from ByteString method
   * @return a short value
   */
  def readShortLE:Short = {
    val v = ((bytes(_pos).toInt & 0xff) + ((bytes(_pos + 1).toInt & 0xff) << 8)).toShort
    _pos += 2
    v
  }

  /**
   * The reading LITTLE ENDIAN Int value from ByteString method
   * @return a int value
   */
  def readIntLE:Int = {
    val v = (bytes(_pos).toInt & 0xff) + ((bytes(_pos + 1).toInt & 0xff) << 8) + ((bytes(_pos + 2).toInt & 0xff) << 16) + ((bytes(_pos + 3).toInt & 0xff) << 24)
    _pos += 4
    v
  }

  /**
   * The reading LITTLE ENDIAN Long value from ByteString method
   * @return a long value
   */
  def readLongLE:Long = {
    val v = (bytes(_pos).toLong & 0xff) + ((bytes(_pos + 1).toLong & 0xff) << 8) + ((bytes(_pos + 2).toLong & 0xff) << 16) + ((bytes(_pos + 3).toLong & 0xff) << 24) +
      ((bytes(_pos + 4).toLong & 0xff) << 32) + ((bytes(_pos + 5).toLong & 0xff) << 40) + ((bytes(_pos + 6).toLong & 0xff) << 48) + ((bytes(_pos + 7).toLong & 0xff) << 56)
    _pos += 8
    v
  }

  def readFloatLE:Float =
    java.lang.Float.intBitsToFloat(readIntLE)

  def readDoubleLE:Double =
    java.lang.Double.longBitsToDouble(readLongLE)

  /**
   * The reading BIG ENDIAN short value from ByteString method
   * @return a short value
   */
  def readShortBE:Short = {
    val v = ((bytes(_pos + 1).toInt & 0xff) + ((bytes(_pos).toInt & 0xff) << 8)).toShort
    _pos += 2
    v
  }

  /**
   * The reading BIG ENDIAN Int value from ByteString method
   * @return a int value
   */
  def readIntBE:Int = {
    val v = (bytes(_pos + 3).toInt & 0xff) + ((bytes(_pos + 2).toInt & 0xff) << 8) + ((bytes(_pos + 1).toInt & 0xff) << 16) + ((bytes(_pos).toInt & 0xff) << 24)
    _pos += 4
    v
  }

  /**
   * The reading BIG ENDIAN Long value from ByteString method
   * @return a long value
   */
  def readLongBE:Long = {
    val v = (bytes(_pos + 7).toLong & 0xff) + ((bytes(_pos + 6).toLong & 0xff) << 8) + ((bytes(_pos + 5).toLong & 0xff) << 16) + ((bytes(_pos + 4).toLong & 0xff) << 24) +
      ((bytes(_pos + 3).toLong & 0xff) << 32) + ((bytes(_pos + 2).toLong & 0xff) << 40) + ((bytes(_pos + 1).toLong & 0xff) << 48) + ((bytes(_pos).toLong & 0xff) << 56)
    _pos += 8
    v
  }

  def readFloatBE:Float =
    java.lang.Float.intBitsToFloat(readIntBE)

  def readDoubleBE:Double =
    java.lang.Double.longBitsToDouble(readLongBE)

  /**
   * The reading specific bytes from ByteString method
   * @param l specific byte length
   * @return specific bytes
   */
  def readBytes(l:Int):ByteString = {
    if (l <=0) throw new IllegalArgumentException(s"invalid read bytes:$l")
    val v = bytes.slice(_pos,_pos + l)
    _pos += l
    v
  }

  def skip(l:Int):Unit = {
    if (l <=0) throw new IllegalArgumentException(s"invalid skip bytes:$l")
    _pos += l
  }

  def rewind():Unit = {
    _pos = 0
  }

  def rewind(l:Int):Unit = {
    _pos -= l
    if (_pos < 0) {
      _pos = 0
      throw new IllegalArgumentException(s"invalid rewind bytes:$l")
    }
  }

  /**
   * The returning left byte length method
   * @return left byte length
   */
  def length:Int = bytes.length - _pos
}

sealed trait BitMask {
  protected def _bitMask(bits:Int) = bits match {
    case 0 => 0
    case 1 => 1
    case 2 => 3
    case 3 => 7
    case 4 => 15
    case 5 => 31
    case 6 => 63
    case 7 => 127
    case 8 => 255
    case _ => throw new IllegalArgumentException
  }
}

/**
  * reading bits field from byte string reader class
  * @param reader the source byte string reader
  */
case class ByteStringBitsReader(reader:ByteStringReader) extends BitMask {
  private var _bitLeft = 0
  private var _lastByte:Option[Int] = None

  /**
    * reading bits method
    * @param bits how many bits
    * @return
    */
  def readBits(bits:Int):Long = {
    if (bits > 64) throw new IllegalArgumentException

    var l = bits
    var v = 0L

    while(l > 0) {
      val b = _lastByte.getOrElse {
        val bb = reader.readByte
        _lastByte = Some(bb)
        _bitLeft = 8
        bb.toInt
      }

      if (l >= _bitLeft) {
        v = (v << _bitLeft) + (b & _bitMask(_bitLeft))
        l -= _bitLeft
        _bitLeft = 0
        _lastByte = None
      } else {
        v = (v << l) + ((b >>> (_bitLeft - l)) & _bitMask(l))
        _bitLeft -= l
        l = 0
      }
    }
    v
  }
}

class ByteStringBitsWriter extends BitMask {
  private var _bitLeft = 8
  private var _lastByte = 0
  private var _bytes = List.empty[Byte]

  def writeBits(v:Long,l:Int):Unit = {
    var bits = l
    while(bits > 0) {
      if (bits >= _bitLeft) {
        _bytes ::= ((_lastByte << _bitLeft) + ((v >>> (bits - _bitLeft)) & _bitMask(_bitLeft))).toByte
        bits -= _bitLeft
        _lastByte = 0
        _bitLeft = 8
      } else {
        _lastByte = (_lastByte << bits) + (v & _bitMask(bits)).toInt
        _bitLeft -= bits
        bits = 0
      }
    }
  }
  def toArray:Array[Byte] = {
    if (_bitLeft < 8) {
      _bytes ::= ((_lastByte << _bitLeft) & 0xff).toByte
      _lastByte = 0
      _bitLeft = 8
    }
    _bytes.reverse.toArray
  }
}

object ByteStringBitsWriter {
  def apply[T](f:ByteStringBitsWriter => T):ByteString = {
    val writer = new ByteStringBitsWriter
    f(writer)
    ByteString(writer.toArray)
  }
}

object ByteStringHelper {
  implicit def byteStringToReader(bytes:ByteString) = ByteStringReader(bytes)

  implicit def byteToByteString(b:Byte):ByteString = ByteString(b)

  trait ByteStringConversion {
    implicit def shortToByteString(s: Short): ByteString
    implicit def intToByteString(i: Int): ByteString
    implicit def longToByteString(l: Long): ByteString
    implicit def floatToByteString(f: Float): ByteString
    implicit def doubleToByteString(d: Double): ByteString
  }

  object LE extends ByteStringConversion {
    implicit def shortToByteString(s: Short): ByteString =
      ByteString(Array[Byte]((s & 0xff).toByte, ((s >> 8) & 0xff).toByte))

    implicit def intToByteString(i: Int): ByteString =
      ByteString(Array[Byte]((i & 0xff).toByte, ((i >> 8) & 0xff).toByte, ((i >> 16) & 0xff).toByte, ((i >> 24) & 0xff).toByte))

    implicit def longToByteString(l: Long): ByteString =
      ByteString(Array[Byte]((l & 0xff).toByte, ((l >> 8) & 0xff).toByte, ((l >> 16) & 0xff).toByte, ((l >> 24) & 0xff).toByte,
        ((l >> 32) & 0xff).toByte, ((l >> 40) & 0xff).toByte, ((l >> 48) & 0xff).toByte, ((l >> 56) & 0xff).toByte))

    implicit def floatToByteString(f: Float): ByteString =
      intToByteString(java.lang.Float.floatToIntBits(f))

    implicit def doubleToByteString(d: Double): ByteString =
      longToByteString(java.lang.Double.doubleToLongBits(d))
  }

  object BE extends ByteStringConversion {
    implicit def shortToByteString(s: Short): ByteString =
      ByteString(Array[Byte](((s >> 8) & 0xff).toByte, (s & 0xff).toByte))

    implicit def intToByteString(i: Int): ByteString =
      ByteString(Array[Byte](((i >> 24) & 0xff).toByte, ((i >> 16) & 0xff).toByte, ((i >> 8) & 0xff).toByte, (i & 0xff).toByte))

    implicit def longToByteString(l: Long): ByteString =
      ByteString(Array[Byte](((l >> 56) & 0xff).toByte, ((l >> 48) & 0xff).toByte, ((l >> 40) & 0xff).toByte, ((l >> 32) & 0xff).toByte,
        ((l >> 24) & 0xff).toByte, ((l >> 16) & 0xff).toByte, ((l >> 8) & 0xff).toByte, (l & 0xff).toByte))

    implicit def floatToByteString(f: Float): ByteString =
      intToByteString(java.lang.Float.floatToIntBits(f))

    implicit def doubleToByteString(d: Double): ByteString =
      longToByteString(java.lang.Double.doubleToLongBits(d))
  }

  case class ByteStringEncodable[T](v:T) {
    def toByteString(implicit f:T => ByteString):ByteString = f(v)
  }
  case class ByteStringEncodableList[T](v:List[T]) {
    def toByteString(implicit f:T => ByteString):ByteString =
      v.foldLeft(VLong(v.length.toLong).toByteString)((b, e) => b ++ f(e))
  }

  implicit class ByteStringHexDumper(bytes:ByteString) {
    def dump():String = bytes.map("%02x".format(_)).mkString("ByteString(",",",")")
  }
}

object ByteStringStringHelper {
  implicit def decodeString(reader:ByteStringReader):String = {
    val l = VLong(reader).v
    if (l == 0) "" else {
      val bytes = reader.readBytes(l.toInt)
      bytes.decodeString("UTF-8")
    }
  }
}

object ByteStringDecodingListHelper {
  implicit def decodeList[T](reader:ByteStringReader,f:ByteStringReader => T):List[T] = {
    val l = VLong(reader).v.toInt
    0.until(l).map(_ => f(reader)).toList
  }
}
