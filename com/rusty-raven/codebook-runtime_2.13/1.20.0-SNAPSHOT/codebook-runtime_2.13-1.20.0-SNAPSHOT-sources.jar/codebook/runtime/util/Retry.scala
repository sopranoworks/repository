package codebook.runtime.util

import scala.annotation.tailrec

object Retry {
  @tailrec
  def retry[T](fn: => T,n: Int = 3): T = {
    util.Try { fn } match {
      case util.Success(x) => x
      case _ if n > 1 => retry(fn,n-1)
      case util.Failure(e) => throw e
    }
  }
}
