package codebook.runtime.util

object OptionHelper {
  implicit class FailureLogger[T](r:Option[T]) {
    def ~>[U](f : => U):Option[T] = {
      if (r.isEmpty) f
      r
    }
  }
}
