package codebook.runtime.util

trait Counter[T] {
  def inc:T
  def dec:T
  def reset():Unit
  def value:T
}

case class LongCounter(private var v:Long = 0) extends Counter[Long] {
  override def inc: Long = {
    v += 1
    v
  }

  override def dec: Long = {
    v -= 1
    v
  }

  override def reset(): Unit = {
    v = 0
  }

  override def value: Long = v
}

case class IntCounter(private var v:Int = 0) extends Counter[Int] {
  override def inc: Int = {
    v += 1
    v
  }

  override def dec: Int = {
    v -= 1
    v
  }

  override def reset(): Unit = {
    v = 0
  }

  override def value: Int = v
}
