package codebook.runtime.util

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success}

object FutureHelper {
  implicit class FutureChecker[T](future:Future[T]) {
    def isFailed:Boolean = future.value match {
      case Some(Success(_)) => false
      case Some(Failure(_)) => true
      case None => false
    }
  }
  def retryUntilSuccess[T](f: => Future[T], sleep:Int)(implicit ec: ExecutionContext): Future[T] = {
    f recoverWith {
      case _ =>
        Thread.sleep(sleep)
        retryUntilSuccess(f,sleep)
    }
  }
}
