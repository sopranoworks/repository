package codebook.runtime.util

import scala.io.Source

object SourceHelper {
  implicit class SourceAfterClose(source: Source) {
    def getLinesThenClose: Iterator[String] = {
      val r = source.getLines()
      source.close()
      r
    }
  }
}
