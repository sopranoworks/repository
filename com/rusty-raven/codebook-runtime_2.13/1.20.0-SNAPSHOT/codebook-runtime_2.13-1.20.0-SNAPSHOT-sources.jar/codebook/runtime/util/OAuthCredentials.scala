package codebook.runtime.util

import akka.http.scaladsl.model.HttpMethod
import akka.http.scaladsl.model.headers.GenericHttpCredentials
import org.apache.commons.codec.binary.Base64
import org.apache.commons.codec.digest.HmacUtils
import org.apache.commons.codec.net.URLCodec

object OAuthCredentials {
  val codec = new URLCodec("UTF-8")

  def apply(method:HttpMethod,url:String,consumerKey:String,consumerSecret:String,oauthToken:String,oauthTokenSecret:Option[String] = None):GenericHttpCredentials = {
    val params:List[(String,String)] = List(
      ("oauth_consumer_key",consumerKey),
      ("oauth_nonce",System.currentTimeMillis().toString),
      ("oauth_signature_method","HMAC-SHA1"),
      ("oauth_timestamp",(System.currentTimeMillis() / 1000).toString),
      ("oauth_token",oauthToken),
      ("oauth_version","1.0")
    )

    val key = codec.encode(consumerSecret) + "&" + oauthTokenSecret.map(codec.encode).getOrElse("")
    val parameterString = params.map{case(k,v)=>s"$k=${codec.encode(v)}"}
    val signatureBaseString = method.value + "&" + codec.encode(url) + "&" + codec.encode(parameterString.mkString("&"))
    val signature = Base64.encodeBase64String(HmacUtils.hmacSha1(key,signatureBaseString))

    GenericHttpCredentials("OAuth",parameterString.mkString(",") + s",oauth_signature=${codec.encode(signature)}")
  }
}