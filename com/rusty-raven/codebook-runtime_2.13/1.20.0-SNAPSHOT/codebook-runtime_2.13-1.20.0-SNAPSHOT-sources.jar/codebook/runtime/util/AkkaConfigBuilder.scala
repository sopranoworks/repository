package codebook.runtime.util

import com.typesafe.config.{Config, ConfigFactory}

trait HasAkkaConfig {
  def akkaConfig:String = ""
  def akkaExtensions:Set[String] = Set.empty[String]
  def roles:List[String] = List.empty[String]
  def dataCenter:Option[String] = None
}

object AkkaConfigBuilder {
  case class AkkaConfig(config:String) {
    override def toString:String = config
    def toConfig:Config = ConfigFactory.parseString(config).resolve()
  }
  def apply(objs:HasAkkaConfig *):AkkaConfig = {
    var extendsion = Set.empty[String]
    var roles = Set.empty[String]
    var dataCenter:Option[String] = None
    AkkaConfig(objs.foldLeft("") {
      (s,o) =>
        if (o.akkaExtensions.nonEmpty)
          extendsion ++= o.akkaExtensions
        if (o.roles.nonEmpty)
          roles ++= o.roles
        if (o.dataCenter.nonEmpty)
          dataCenter = o.dataCenter
        s + o.akkaConfig
    } + s"akka.extensions = [ ${extendsion.map(e=>"\"" + e + "\"").mkString(",")} ]\n"
      + (if (roles.nonEmpty) s"akka.cluster.roles = [ ${roles.map(r=>s""""$r\"""").mkString(",")} ]\n" else "")
      + dataCenter.map(dc=>s"""akka.cluster.multi-data-center.self-data-center = "$dc"\n""").getOrElse("")
    )
  }
}
