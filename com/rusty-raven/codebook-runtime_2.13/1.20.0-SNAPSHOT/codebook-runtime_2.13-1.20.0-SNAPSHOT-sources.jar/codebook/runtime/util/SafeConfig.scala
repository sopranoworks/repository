/**
  * codebook.runtime.util.SafeConfig
  *
  * Copyright (c) 2016-2017 Osamu Takahashi
  * Copyright (c) 2016-2017 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.util

import com.typesafe.config.Config
import scala.jdk.CollectionConverters._

object SafeConfig {
  implicit class SafeConfigReader(config:Config) {
    def has (path:String):Option[Config] = if (config.hasPath(path)) Some(config) else None

    def safeRead[T](key:String)(f:(Config,String) => T):Option[T] = try {
      Some(f(config,key))
    } catch {
      case _ : Throwable =>
        None
    }

    def getBoolean(path:String,default:Boolean):Boolean = this getBooleanOpt path getOrElse default
    def getInt(path:String,default:Int):Int = this getIntOpt path getOrElse default
    def getIntList(path:String,default:List[Int]):List[Int] = this getIntListOpt path getOrElse default
    def getLong(path:String,default:Long):Long = this getLongOpt path getOrElse default
    def getLongList(path:String,default:List[Long]):List[Long] = this getLongListOpt path getOrElse default
    def getString(path:String,default:String):String = this getStringOpt path getOrElse default
    def getStringList(path:String,default:List[String]):List[String] = this getStringListOpt path getOrElse default

    def getBooleanOpt(path:String):Option[Boolean] = this has path flatMap(_=>safeRead(path) { _.getBoolean(_) })
    def getIntOpt(path:String):Option[Int] = this has path flatMap(_=>safeRead(path) { _.getInt(_) })
    def getIntListOpt(path:String):Option[List[Int]] = this has path flatMap(_=>safeRead(path) { _.getIntList(_).asScala.map(Integer2int).toList })
    def getLongOpt(path:String):Option[Long] = this has path flatMap(_=>safeRead(path) { _.getLong(_) })
    def getLongListOpt(path:String):Option[List[Long]] = this has path flatMap(_=>safeRead(path) { _.getLongList(_).asScala.map(Long2long).toList })
    def getStringOpt(path:String):Option[String] = this has path flatMap(_=>safeRead(path) { _.getString(_) })
    def getStringListOpt(path:String):Option[List[String]] = this has path flatMap(_=>safeRead(path) { _.getStringList(_).asScala.toList })
    def getConfigOpt(path:String):Option[Config] = this has path flatMap(_=>safeRead(path) { _.getConfig(_)})
    def getConfigListOpt(path:String):Option[List[Config]] = this has path flatMap(_=>safeRead(path) {_.getConfigList(_).asScala.toList })
  }
}
