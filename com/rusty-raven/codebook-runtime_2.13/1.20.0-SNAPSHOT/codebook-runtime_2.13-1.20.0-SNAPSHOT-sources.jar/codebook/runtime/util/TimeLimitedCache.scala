package codebook.runtime.util

import scala.concurrent.duration.Duration

class TimeLimitedCache[K,V](maxHoldingDuration:Duration, updateOnAccess:Boolean) {
  private case class Value(v:V,timestamp:Long,locked:Boolean = false)
  private var _cache:Map[K,Value] = Map.empty
  private val d = maxHoldingDuration.toMillis

  def get(key:K):Option[V] = {
    val now = System.currentTimeMillis()
    _cache.get(key).flatMap {
      v =>
        if (v.locked || v.timestamp + d > now) {
          if (updateOnAccess) {
            synchronized {
              _cache += key -> v.copy(timestamp = now)
            }
          }
          Some(v.v)
        } else {
          synchronized {
            _cache -= key
          }
          None
        }
    }
  }
  
  def set(key:K,v:V):Unit =
    this += key->v

  def +=(kv:(K,V)):Unit = 
    synchronized {
      _cache += kv._1 -> Value(kv._2, System.currentTimeMillis())
    }

  def -=(key:K):Unit =
    synchronized {
      _cache -= key
    }

  def lock(key:K):Boolean =
    _cache.get(key).exists {
      v =>
        synchronized {
          _cache += key -> v.copy(locked = true)
        }
        true
    }
    
  def unlock(key:K):Boolean = 
    _cache.get(key).exists {
      v =>
        synchronized {
          _cache += key -> v.copy(locked = false)
        }
        true
    }
    
  def clean():Unit = {
    val now = System.currentTimeMillis()
    synchronized {
      _cache = _cache.filter {
        case (_, v) => v.locked || v.timestamp + d > now
      }
    }
  }
}
