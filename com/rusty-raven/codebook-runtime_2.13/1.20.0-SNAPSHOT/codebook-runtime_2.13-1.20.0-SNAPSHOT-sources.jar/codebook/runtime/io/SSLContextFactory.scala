package codebook.runtime.io

import java.io.FileInputStream
import java.security.KeyStore

import com.typesafe.config.Config
import javax.net.ssl.{KeyManagerFactory, SSLContext, TrustManagerFactory}
import org.slf4j.LoggerFactory

object SSLContextFactory {
  import codebook.runtime.util.SafeConfig._

  private val _logger = LoggerFactory.getLogger("SSLContextFactory")

  var tlsSignature = "TLSv1.1"

  def apply(config:Config):Option[SSLContext] = {
    try {
      if (config.getBoolean("enabled", false)) {
        val kmf = KeyManagerFactory.getInstance("SunX509")

        for {
          keystore <- config.getStringOpt("keystore")
          password <- config.getStringOpt("password")
        } yield {
          val p = password.toCharArray()
          val ks = KeyStore.getInstance("JKS")
          ks.load(new FileInputStream(keystore),p)
          kmf.init(ks,p)

          val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm)
          tmf.init(ks)

          val sslcontext = SSLContext.getInstance(tlsSignature)
          sslcontext.init(kmf.getKeyManagers, tmf.getTrustManagers, null)

          sslcontext
        }
      } else {
        None
      }
    } catch {
      case e : Throwable =>
        _logger.error(e.getMessage)
        _logger.error(e.getStackTrace.map(_.toString).mkString("\n"))
        None
    }
  }
}
