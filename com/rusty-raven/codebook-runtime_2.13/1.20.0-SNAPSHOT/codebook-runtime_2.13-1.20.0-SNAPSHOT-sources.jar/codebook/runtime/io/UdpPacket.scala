package codebook.runtime.io

import akka.util.ByteString

import java.net.InetSocketAddress

case class UdpPacket(data:ByteString, remote:InetSocketAddress)
