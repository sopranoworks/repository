/**
  * codebook.runtime.packet.PacketReader
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.io

import akka.actor._
import akka.io.Tcp.SO.{KeepAlive, TcpNoDelay}
import akka.io.{IO, Tcp}
import codebook.runtime.packet.PacketReader
import codebook.runtime.protocol._
import codebook.runtime.util.HasAkkaConfig

import java.net.InetSocketAddress
import javax.net.ssl.SSLContext

/**
  * The tcp server trait
  * This is the base of all tcp connection type server port.
  */
trait TcpServerPort extends Actor with ActorLogging {

  import Tcp._
  import context.system

  def port:Int
  def localAddress:Option[String] = None
  def sslContext:Option[SSLContext] = None

  override def preStart(): Unit = {
    log.info(s"ServerPort is starting with port: $localAddress:$port")
    IO(Tcp) ! Bind(self,localAddress.map(addr=>new InetSocketAddress(addr,port)).getOrElse(new InetSocketAddress(port)),options = List(KeepAlive(true),TcpNoDelay(true)))
  }

  override def preRestart(reason: Throwable, message: Option[Any]): Unit = {
    log.error(reason.getStackTrace.mkString("\n"))
  }

  def createUserServiceActor(socket:ActorRef):ActorRef

  def onUserServiceActorTerminate(actor:ActorRef):Unit = {}

  def receive: Receive = process
  
  def process: Receive = {
    case b @ Bound(localAddress) =>

    case CommandFailed(_: Bind) =>
      log.error("Starting ServerPort Failure")
      context.stop(self)

    case c @ Connected(remote, local) =>
      //log.info("New incoming connection on server")
      val connection = sender()
      val handler = context.actorOf(Props(new TLSAdaptor(connection,sslContext)))
      val serv = createUserServiceActor(handler)
      context.watch(serv)
      handler ! Register(serv)
      connection ! Register(handler)

    case Terminated(x) =>
      log.info(s"Terminated user service actor: ${x.path}")
      onUserServiceActorTerminate(x)
  }
}

object TcpServerPort extends HasAkkaConfig {
  override def akkaConfig: String =
s"""
akka {
  $defaultDispatcherName {
    type = PinnedDispatcher
    executor = "thread-pool-executor"
    mailbox-type = "akka.dispatch.UnboundedControlAwareMailbox"
  }
}
"""
  def defaultDispatcherName:String = "tcp-server-port-dispatcher"
}
