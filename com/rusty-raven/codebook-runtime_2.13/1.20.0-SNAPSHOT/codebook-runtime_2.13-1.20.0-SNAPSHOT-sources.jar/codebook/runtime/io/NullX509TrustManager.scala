/**
  * codebook.runtime.io.NullX509TrustManager
  *
  * Copyright (c) 2016-2017 Osamu Takahashi
  * Copyright (c) 2016-2017 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.io

import java.security.cert.X509Certificate
import javax.net.ssl.{TrustManager, X509TrustManager}

class NullX509TrustManager extends X509TrustManager {
  override def getAcceptedIssuers: Array[X509Certificate] = null

  override def checkClientTrusted(x509Certificates: Array[X509Certificate], s: String): Unit = {}

  override def checkServerTrusted(x509Certificates: Array[X509Certificate], s: String): Unit = {}
}

object NullX509TrustManager {
  def apply() = Array[TrustManager](new NullX509TrustManager)
}
