package codebook.runtime.io

import akka.actor.{Actor, ActorLogging, ActorRef}
import akka.io.Tcp.Register
import akka.io.{IO, Udp}

import java.net.InetSocketAddress

trait UdpPort extends Actor with ActorLogging {

  def port:Int = 0
  def localAddress:String = "localhost"

  override def preStart(): Unit = {
    import context.system
    IO(Udp) ! Udp.Bind(self, new InetSocketAddress(localAddress, port))
  }
  
  def receive:Receive = {
    case Udp.Bound(local) =>
      context.become(process(sender(),local))
  }

  def process(socket:ActorRef,local:InetSocketAddress, listener:Option[ActorRef] = None):Receive = {
    case Udp.Received(data, remote) =>
      listener.foreach(_.forward(UdpPacket(data,remote)))
    case UdpPacket(data,remote) =>
      socket ! Udp.Send(data,remote)
    case Udp.Unbind =>
      socket ! Udp.Unbind
    case Udp.Unbound =>
      context.stop(self)

    case Register(after, _, _) =>
      context.become(process(socket,local,Some(after)))
  }
}
