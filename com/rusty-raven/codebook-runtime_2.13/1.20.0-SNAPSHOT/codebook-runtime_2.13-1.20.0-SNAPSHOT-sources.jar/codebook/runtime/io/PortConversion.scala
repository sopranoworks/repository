/**
  * codebook.runtime.packet.TcpClientPort
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.io

import akka.actor.ActorRef
import akka.io.Tcp.{Close, Write}
import akka.util.ByteString
import codebook.runtime.packet.{DummyPacketCipher, Packet, PacketCipher}
import codebook.runtime.protocol.{Request, Response, SystemMessages}

object PortConversion {
  /**
    * The utility class for TCP socket actor operation class
    * This class usually use in implicit conversion.
    * @param port a TCP socket handling actor
    */
  implicit class TcpPort(port:ActorRef) {

    def send(bytes:ByteString):Unit = port ! Write(bytes)

    /**
      * The sending packet to TCP socket method
      * @param packet a packet to send
      */
    def send(packet:Packet):Unit = send(packet.toByteString)

    /**
      * The sending Request to TCP socket method
      * @param req a request to send
      */
    def send(req:Request):Unit = send(req.toByteString)

    /**
      * The sending Response to TCP socket method
      * @param res a response to send
      */
    def send(res:Response)(implicit packetCipher: PacketCipher = null):Unit =
      if (packetCipher != null)
        send( Packet(res.toByteString).encode(packetCipher) )
      else
        send( Packet(res.toByteString))

    /**
      * The requesting to close the TCP socket method
      */
    def close():Unit = {
      port ! Close
      port ! SystemMessages.GoodBy
    }
  }
}