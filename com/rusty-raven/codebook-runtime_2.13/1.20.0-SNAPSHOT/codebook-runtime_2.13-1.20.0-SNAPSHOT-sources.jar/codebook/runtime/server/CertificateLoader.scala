package codebook.runtime.server

import java.io.InputStream
import java.nio.ByteBuffer
import java.security.cert.{CertificateFactory, X509Certificate}

import akka.actor.{Actor, ActorLogging}
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.HttpRequest
import akka.http.scaladsl.unmarshalling.Unmarshal
import akka.stream.ActorMaterializer
import akka.util.ByteString

import scala.concurrent.Future

class CertificateLoader extends Actor with ActorLogging {
  import codebook.runtime.util.FutureHelper._
  private var _certificates = Map.empty[String,Future[X509Certificate]]

  private implicit val materializer: ActorMaterializer = ActorMaterializer()
  import context.system
  import context.dispatcher

  import java.io.IOException

  class ByteBufferBackedInputStream(var buf: ByteBuffer) extends InputStream {
    @throws[IOException]
    override def read(): Int = {
      if (!buf.hasRemaining) return -1
      buf.get & 0xFF
    }

    @throws[IOException]
    override def read(bytes: Array[Byte], off: Int, len: Int): Int = {
      if (!buf.hasRemaining) return -1
      val l = Math.min(len, buf.remaining)
      buf.get(bytes, off, l)
      l
    }
  }

  private def createLoadRequest(url:String) = {
    for {
      res<-Http().singleRequest(HttpRequest(uri = url))
      body<-Unmarshal(res.entity).to[ByteString]
      r   <-Future {
              val in = new ByteBufferBackedInputStream(body.asByteBuffer)
              val cf = CertificateFactory.getInstance("X.509")
              cf.generateCertificate(in).asInstanceOf[X509Certificate]
            }
    } yield {
      r
    }
  }

  def receive:Receive = {
    case url:String =>
      _certificates.get(url) match {
        case Some(cert) if !cert.isFailed =>
          sender() ! cert
        case _ =>
          val f = createLoadRequest(url)
          _certificates += url->f
          sender() ! f
      }
  }
}
