package codebook.runtime.server

import akka.actor.{Actor, ActorContext, ActorLogging, ActorRef, Props}
import akka.cluster.{Cluster, Member}
import org.slf4j.LoggerFactory

import scala.util.{Failure, Success}

trait RoleFinder extends ClusterEventListener {
  import codebook.runtime.util.TimeLimits._

  def roleName:String
  def identifierPrefix:String = "cluster_node"
  def identifierSeparator:String = ":"
  val destinationActorName:String = "CargoHandler"
  def lateArrivalPriority:Boolean = true

  private val _logger = LoggerFactory.getLogger(roleName.capitalize + "Finder")
  private var _keeper:Option[ActorRef] = None
  private var _cluster:Option[Cluster] = None
  private var _servers = Map.empty[Int,ActorRef]
  private var _serverIdSet = Set.empty[Int]

  def connectorFor(n:Int):Option[ActorRef] = _servers.get(n)

  override val actorName: String = roleName.capitalize + "Finder"

  private def _checkRole(member: Member):Option[Int] = {
    if (member.roles.contains(roleName)) {
      member.roles.find(_.startsWith(identifierPrefix + identifierSeparator)).flatMap {
        e =>
          e.split(identifierSeparator).toList match {
            case _ :: n :: Nil =>
              try {
                Some(n.toInt)
              } catch {
                case _: Throwable =>
                  None
              }
            case _ =>
              None
          }
      }
    } else { None }
  }

  case class MemberAdded(n:Int,connector:ActorRef)
  case class MemberRemoved(n:Int,ttl:Int = 3)
  case class MemberCheckAgain(n:Int,member: Member)

  override def onStart(members: Set[Member], self:ActorRef, context:ActorContext): Unit = {
    members.foreach(onMemberUp)
  }

  private def resolveRoleConnector(n:Int,member: Member, cluster:Cluster, keeper:ActorRef):Unit = {
    import cluster.system.dispatcher
    if (_serverIdSet.contains(n)) {
      _logger.info(s"Found $roleName server id:$n[${member.address.toString + "/user/" + destinationActorName}]")
      cluster.system.actorSelection(member.address.toString + "/user/" + destinationActorName).resolveOne(_10s).onComplete {
        case Success(act) =>
          keeper ! MemberAdded(n, act)
        case Failure(e) =>
          _logger.warn(s"Resolve role connector failure: ${e.toString} ${e.getMessage}")
          cluster.system.scheduler.scheduleOnce(_10s, keeper, MemberCheckAgain(n, member))
      }
    } else {
      _logger.info(s"Found $roleName server id:$n[${member.address.toString + "/user/CargoHandler"}], but already removed")
    }
  }

  override def onMemberUp(member: Member): Unit = {
    for {
      n <- _checkRole(member)
      cluster <- _cluster
      keeper <- _keeper
    } {
      _serverIdSet += n
      resolveRoleConnector(n,member,cluster,keeper)
    }
  }

  override def onMemberRemoved(member: Member): Unit = {
    for {
      n <- _checkRole(member)
      keeper <- _keeper
    } {
      _serverIdSet -= n
      keeper ! MemberRemoved(n)
    }
  }

  class MemberKeeper extends Actor with ActorLogging {
    def receive:Receive = {
      case MemberAdded(n,conn) =>
        log.info(s"Incoming new member:$n")
        val exists = _serverIdSet.contains(n)

        if (lateArrivalPriority || !exists) {
          if (exists) {
            log.info(s"${roleName.capitalize} connector overwrote id:$n")
          } else {
            log.info(s"${roleName.capitalize} connector added id:$n")
          }
          _servers += n -> conn
        } else {
          _logger.warn(s"Duplicated $roleName id:$n, Did not overwrite.")
        }

      case m @ MemberRemoved(n,ttl) =>
        log.info(s"Member Removed:$n(ttl = $ttl)")
        if (_servers.contains(n)) {
          _servers -= n
        } else {
          if (ttl > 0) {
            import context.dispatcher
            context.system.scheduler.scheduleOnce(_5s, self, m.copy(ttl = m.ttl - 1))
          }
        }

      case MemberCheckAgain(n,member) =>
        log.info(s"Retry resolving actor address for $member id:$n")
        _cluster.foreach(c => resolveRoleConnector(n,member,c,self))

      case e =>
        log.warning(s"Unhandled message received:$e(${e.getClass.getName})")
    }
  }

  override def startWithCluster(cluster: Cluster, manager :ClusterManager): Unit = {
    super.startWithCluster(cluster,manager)
    if (_keeper.isEmpty) {
      _cluster = Some(cluster)
      _keeper = Some(cluster.system.actorOf(Props(new MemberKeeper)))
    }
  }
}
