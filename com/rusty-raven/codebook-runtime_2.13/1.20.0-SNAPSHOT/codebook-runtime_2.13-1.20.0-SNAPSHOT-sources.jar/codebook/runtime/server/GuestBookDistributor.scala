package codebook.runtime.server

import akka.actor.Actor.Receive
import codebook.runtime.server.reservationdesk.DeriveGuestBookRequest

import scala.concurrent.duration.{Duration, FiniteDuration}

class GuestBookDistributor(nodeId:Int,val residence: ReservationDesk#Residence) extends Distributor {

  override def actorName: String = "GuestBookDistributor"

  override def distributorName: String = actorName

  override def distributionInterval: FiniteDuration = Duration(10,"s")

  override def receiverRole: String = GuestBookDistributor.receiverRole

  def process:Receive = {
    case Tick =>
      logger.info(s"Distribute agent $nodeId GuestBook To:${receivers.values.size} receivers")
      val msg = new DeriveGuestBookRequest(System.currentTimeMillis(),nodeId,residence.guestBook.toList)
      receivers.values.foreach(_ ! msg)
  }

  override def eventHandler: Receive = process orElse super.eventHandler
}

object GuestBookDistributor {
  def receiverRole = "gb_recv"
}
