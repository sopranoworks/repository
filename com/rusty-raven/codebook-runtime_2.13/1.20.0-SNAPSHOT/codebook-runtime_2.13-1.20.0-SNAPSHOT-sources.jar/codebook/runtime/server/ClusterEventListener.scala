package codebook.runtime.server
import akka.actor.Actor.Receive
import akka.actor.{Actor, ActorContext, ActorLogging, ActorRef, Props}
import akka.cluster.{Cluster, Member}
import akka.cluster.ClusterEvent._

trait ClusterEventListener extends ClusterService {

  private var _worker:Option[ActorRef] = None
  def actorName:String

  def worker: Option[ActorRef] = _worker

  def onStart(members:Set[Member],listener:ActorRef,actorContext: ActorContext):Unit = {}

  def onMemberUp(member: Member): Unit = {}

  def onMemberUnreachable(member: Member): Unit = {}

  def onMemberReachable(member: Member): Unit = {}

  def onMemberRemoved(member: Member): Unit = {}

  
  class Listener extends Actor with ActorLogging {
    override def preStart(): Unit = {
      log.info("starting ClusterEventListener")
      val cluster = Cluster(context.system)
      cluster.subscribe(self,
        initialStateMode = InitialStateAsEvents,
        classOf[MemberEvent],
        classOf[ReachabilityEvent])
      onStart(cluster.state.members,self,context)
    }

    def receive: Receive = eventHandler
  }


  protected def eventHandler:Receive = {
    case MemberUp(member) =>
      onMemberUp(member)
    case UnreachableMember(member) =>
      onMemberUnreachable(member)
    case ReachableMember(member) =>
      onMemberReachable(member)

    case MemberRemoved(member, previousStatus) =>
      onMemberRemoved(member)
    case e: MemberEvent => // ignore

  }

  override def startWithCluster(cluster: Cluster, manager :ClusterManager): Unit = {
    if (_worker.isEmpty) {
      _worker = Some(cluster.system.actorOf(Props(new Listener),actorName))
    }
  }
}
