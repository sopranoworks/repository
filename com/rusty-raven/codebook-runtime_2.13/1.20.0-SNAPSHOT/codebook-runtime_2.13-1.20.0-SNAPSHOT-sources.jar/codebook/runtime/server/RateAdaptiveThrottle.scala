package codebook.runtime.server
import akka.util.ByteString

trait RateAdaptiveThrottle[S,D] { _ : UserServiceActorBase[S,D] with LimitedIntervalFeeder[S,D] =>
  val MAX_PACKET_SIZE = 1500

  override def checkResponse(bytes: ByteString): ByteString = {
    val l = bytes.length
    if (l > MAX_PACKET_SIZE) {
      val p = l / MAX_PACKET_SIZE + (if (l % MAX_PACKET_SIZE != 0) 1 else 0) - 1
      penalty = minimumExecutionInterval * p
    }
    bytes
  }
}
