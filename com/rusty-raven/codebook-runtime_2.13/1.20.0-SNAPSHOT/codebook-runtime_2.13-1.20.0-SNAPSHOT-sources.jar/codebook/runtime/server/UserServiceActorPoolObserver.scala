package codebook.runtime.server

import akka.actor.ActorRef

trait UserServiceActorPoolObserver {
  def onRegister(uid:Long,actor:ActorRef):Unit
  def onUnregister(uid:Long,actor:ActorRef):Unit
}
