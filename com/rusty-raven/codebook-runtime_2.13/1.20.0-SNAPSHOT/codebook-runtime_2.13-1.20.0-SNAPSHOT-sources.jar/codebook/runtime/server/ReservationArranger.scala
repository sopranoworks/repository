package codebook.runtime.server
import akka.actor.{Actor, ActorLogging, ActorPath, ActorRef, ActorSelection, Address, Props}
import akka.cluster.{Cluster, Member}
import akka.cluster.ClusterEvent.{MemberEvent, MemberRemoved, MemberUp}
import akka.pattern.ask
import akka.util.Timeout
import codebook.runtime.server.reservationdesk._
import codebook.runtime.util.HasAkkaConfig
import org.joda.time.DateTime

import scala.concurrent.Future

trait ReservationArranger extends ClusterService with HasAkkaConfig {
  def reservationActorName = "ReservationDesk"

  override def akkaConfig: String = super.akkaConfig +
s"""
akka {
  actor {
    serializers {
      resreqser = "codebook.runtime.server.ReservationRequestSerializer"
      resresser = "codebook.runtime.server.ReservationResponseSerializer"
    }
    serialization-bindings {
      "codebook.runtime.server.reservationdesk.ReservationRequest" = resreqser
      "codebook.runtime.server.reservationdesk.ReservationResponse" = resresser
    }
  }
}
reservation-arranger-dispatcher {
  executor = "thread-pool-executor"
  type = PinnedDispatcher
}
"""
  def serviceRole:String


  private var _operator:Option[ActorRef] = None
  private var _ready = false

  def operator: Option[ActorRef] = _operator

  case class Destination(maxRooms:Int,freeRooms:Int,operator:ActorSelection,lastUpdate:Option[DateTime],roles:Set[String])

  private var _reservationDesks = Map.empty[Address,Destination]

  private object CheckVacancies

  def numReservationDesk:Int = _reservationDesks.values.count(_.lastUpdate.isDefined)
  def isReady:Boolean = _ready
  
  implicit private def resultStatusToShort(v:ResultStatus.Value):Short = v.id.toShort

  class Operator(cluster:Cluster) extends Actor with ActorLogging {
    import codebook.runtime.util.TimeLimits._

    private var _timestamp = 0L

    def timestamp: Long = {
      val t = _timestamp
      _timestamp += 1L
      t
    }

    override def preStart(): Unit = {
      context.system.scheduler.schedule(_10s,_10s,self,CheckVacancies)(context.dispatcher)
      cluster.state.members.foreach(_addReservationDesk)
      self ! CheckVacancies
    }

    override def postStop(): Unit = {
      cluster.unsubscribe(self)
    }

    def pickUpDestination:Option[ActorSelection] =
      _reservationDesks.values
        .filter(_.freeRooms > 0).toSeq
        .sortWith(_.freeRooms > _.freeRooms)
        .headOption.map(_.operator)

    def pickUpDestinationWithSpecificRole(role: String):Option[ActorSelection] =
      _reservationDesks.values.find(_.roles.contains(role)).map(_.operator)

    def updateVacancy(res: GetVacancyResponse, ref: ActorRef): Unit = {
      _reservationDesks.get(ref.path.address).foreach(d => _reservationDesks += ref.path.address->Destination(res.rooms,res.free,d.operator,Some(DateTime.now()),d.roles))
      if (!_ready) {
        if (_reservationDesks.values.forall(_.lastUpdate.isDefined))
          _ready = true
      }
    }

    def checkVacancies(): Unit =
      _reservationDesks.values.foreach(_.operator ! new GetVacancyRequest(timestamp))

    private def _addReservationDesk(member:Member):Boolean =
      if (member.hasRole(serviceRole)) {
        log.info(s"Found new ReservationDesk at ${member.address}")
        _reservationDesks += member.address -> Destination(0, 0, context.actorSelection(ActorPath.fromString(member.address.toString + s"/user/$reservationActorName")),None,member.roles)
        true
      } else false
    
    def receive:Receive = {
      case MemberUp(member) =>
        if (_addReservationDesk(member)) self ! CheckVacancies
      case MemberRemoved(member,_) =>
        if (member.hasRole(serviceRole)) {
          _reservationDesks -= member.address
        }

      case req : GetVacancyResponse =>
        log.info(s"Received vacancy information for $serviceRole from ${sender().path.address} (free:${req.free},reserved:${req.reserved},max:${req.rooms})")
        updateVacancy(req,sender())
      case CheckVacancies =>
        checkVacancies()
        
      case req : MakeReservationRequest =>
        pickUpDestination match {
          case Some(dest) =>
            dest.forward(req)
          case None =>
            log.warning("No room for reservation")
            sender() ! new MakeReservationErrorResponse(req.timestamp,ResultStatus.NoRoom)
        }

      case req : MakeReservationWithSpecificRoleRequest =>
        pickUpDestinationWithSpecificRole(req.role.str) match {
          case Some(dest) =>
            log.info(s"Send reservation request to the node which has a role of ${req.role.str}")
            dest.forward(new MakeReservationRequest(req.timestamp,req.uid))
          case None =>
            log.warning(s"No room for reservation with roles '$roles'")
            sender() ! new MakeReservationErrorResponse(req.timestamp,ResultStatus.NoRoom)
        }
    }
  }

  override def startWithCluster(cluster: Cluster, manager :ClusterManager): Unit = {
    cluster.system.log.info("Starting reservation arranger")
    val operator = cluster.system.actorOf(Props(new Operator(cluster)).withDispatcher("reservation-arranger-dispatcher"))
    cluster.subscribe(operator,classOf[MemberEvent])
    _operator = Some(operator)
  }

  def makeReservation(uid:Long)(implicit timeout:Timeout, sender: ActorRef = Actor.noSender):Future[ReservationResponse] = {
    _operator.map(_.ask(new MakeReservationRequest(DateTime.now().toDate.getTime,uid)).mapTo[ReservationResponse])
      .getOrElse(Future.successful(new MakeReservationErrorResponse(DateTime.now().toDate.getTime,ResultStatus.NotInitialized)))
  }

  def makeReservationWithSpecificRole(uid:Long,role:String)(implicit timeout:Timeout, sender: ActorRef = Actor.noSender):Future[ReservationResponse] = {
    _operator.map(_.ask(new MakeReservationWithSpecificRoleRequest(DateTime.now().toDate.getTime,uid,String32(role))).mapTo[ReservationResponse])
      .getOrElse(Future.successful(new MakeReservationErrorResponse(DateTime.now().toDate.getTime,ResultStatus.NotInitialized)))
  }
}
