package codebook.runtime.server

import akka.actor.{ActorRef, ActorSelection, FSM}
import akka.dispatch.ControlMessage
import akka.io.Tcp.{Close, Command}
import akka.util.ByteString
import codebook.runtime.packet.{DummyPacketCipher, Packet, PacketCipher}
import codebook.runtime.protocol._
import codebook.runtime.util.{ByteStringReader, IntCounter, LongCounter}

import scala.concurrent.Future
import scala.reflect.ClassTag
import scala.util.{Failure, Success}

trait ExtraActorState

class UserServiceActorState[D](var data:D) {
  val corruptedRequestCount:IntCounter = IntCounter()
  val decodedRequestCount:LongCounter = LongCounter()
  val requestQueue:RequestQueue = new OptimizedRequestQueue {}
  var waitingForFutureResponse:Boolean = false
  var apiBeginningProcessingTime:Long = 0
  var extraActorStates:Map[Int, ExtraActorState] = Map.empty
  var futureDelayedSlot:List[Any] = List.empty
}

trait UserServiceActorBase[S,D] extends FSM[S,UserServiceActorState[D]] with ApiHandlerSetter[S,D] {
  import codebook.runtime.io.PortConversion._
  import codebook.runtime.util.TimeLimits._

  private case class DecodingException(msg:String, bytes:ByteString, exception: Exception) extends Exception

  private object WaitingTerminationTimeout

  private val _profiler:ActorSelection = context.system.actorSelection(ApiProfiler.actorPath)

  def createStateData(data:D):UserServiceActorState[D] = new UserServiceActorState(data)

  case class FutureResponse(res:Option[Response],nextState:S,nextData:D) extends ControlMessage

  def decoder:Decoder
  def socket:ActorRef

  val packetCipher:PacketCipher = new DummyPacketCipher

  def pool:Option[UserServiceActorPool] = None
  def reservationDesk:Option[ReservationDesk] = None
  def uid:Option[Long] = None

  def apiLoggingEnabled:Boolean = true

  def printUid:String = ""

  type ApiResponse = (Option[Response],D,Option[S])

  def apiResponse[REQ <: Request : ClassTag,RES <: Response : ClassTag](f:(REQ,D) => (Option[RES],D,Option[S]) ):StateFunction = {
    case Event(req:REQ,stateData:UserServiceActorState[D]) =>
      if (stateData.waitingForFutureResponse) {
        stateData.futureDelayedSlot ::= req
        stay().using(stateData)
      } else {
        if (apiLoggingEnabled) {
          log.info(s"${printUid} apiResponse:$req")
        }
        val t = System.currentTimeMillis()

        try {
          val (optRes, data, next) = f(req, stateData.data)
          val d = System.currentTimeMillis() - t
          optRes.foreach(res => self ! res)
          stateData.data = data
          _profiler.tell(ApiProfileMessage(req, d, None), self)
          next.map(goto).getOrElse(stay()).using(stateData)
        } catch {
          case e: Throwable =>
            val d = System.currentTimeMillis() - t
            _profiler.tell(ApiProfileMessage(req, d, Some(e)), self)
            stay()
        }
      }
  }

  def futureApiResponse[REQ <: Request : ClassTag,RES <: Response : ClassTag,RES2 <: Response : ClassTag](f:(REQ,D) => Future[(Option[RES],D,Option[S])], whenFailure:(REQ,D) => (Option[Response],D,Option[S]) = (req:REQ,d:D) => (Some(req.errorResponse(ResultStatus.Failure)),d,None)):StateFunction = {
    case Event(req:REQ,stateData) =>
      if (stateData.waitingForFutureResponse) {
        stateData.futureDelayedSlot ::= req
        
      } else {
        if (apiLoggingEnabled) {
          log.info(s"${printUid} futureApiResponse:$req")
        }
        stateData.apiBeginningProcessingTime = System.currentTimeMillis()
        stateData.waitingForFutureResponse = true
        val ex = self
        f(req, stateData.data).onComplete {
          case Success((res, data, next)) =>
            self.forward(FutureResponse(res, next.getOrElse(stateName), data))
            val d = System.currentTimeMillis() - stateData.apiBeginningProcessingTime
            _profiler.tell(ApiProfileMessage(req, d, None), ex)
          case Failure(e) =>
            val (res, data, next) = whenFailure(req, stateData.data)
            self.forward(FutureResponse(res, next.getOrElse(stateName), data))
            log.error(e, message = s"${printUid} Exception $e catch during API $f")
            val d = System.currentTimeMillis() - stateData.apiBeginningProcessingTime
            _profiler.tell(ApiProfileMessage(req, d, Some(e)), ex)
        }(context.dispatcher)
      }
      stay().using(stateData)
  }

  def preLogout(data:D):Unit = {}
  def postLogout(data:D):Unit = {}

  def logout():Unit = {
    preLogout(stateData.data)
    cleanUps.foreach(_(stateData.data))
    extraActorStateCleanUps.foreach(_(stateData))
    for {
      p <- pool
      u <- uid
    } {
      p.unregister(u)

      import context.dispatcher

      reservationDesk.foreach(rd =>
        rd.checkOut(u)
      )
    }
    postLogout(stateData.data)
  }

  def close():Unit = {
    socket ! Close
    context.system.scheduler.scheduleOnce(_10s,self,WaitingTerminationTimeout)(context.dispatcher)
  }

  def onConnected():State = {
    stay()
  }

  def onClosed():State = {
    logout()
    stop() // never call any other method like stay() after stop()
  }

  def onCorruptRequest():State = {
    close()
    stay()
  }

  def onInvalidPacketReceived():State = {
    close()
    stay()
  }

  def onInvalidTLSSession():State = {
    close()
    stay()
  }

  def onUnhandledRequest(req: Request):State = {
    log.warning(s"${printUid} Unhandled request received[$req]. Send common error.(State = $stateName)")
    sendResponse( req.errorResponse(ResultStatus.InvalidState) )
    stay()
  }

  def decodePacketPayload(reader:ByteStringReader):Option[Request] =
    decoder.decodeRequest(reader)

  def encodePacket(bytes:ByteString):Packet =
    new Packet(bytes).encode(packetCipher)

  def checkResponse(bytes:ByteString):ByteString = bytes

  def execute():Unit = {
    stateData.requestQueue.pop.foreach(self.forward(_))
  }
  
  def pushRequest(req:Request):Unit = {
    stateData.requestQueue.push(req)
    if (!stateData.waitingForFutureResponse) execute()
  }

  def sendResponse(res:Response):Unit =
    socket.send(encodePacket(checkResponse(res.toByteString)))

  override def preStart(): Unit = {
    super.preStart()
    bootUps.foreach(_())
  }

  override def commandDecoder:StateFunction = {
    case Event(packet: Packet, _) =>
      try {
        packet.decode(packetCipher).foreach {
          pkt =>
            try {
              decodePacketPayload(ByteStringReader(pkt.bytes)).foreach {
                req =>
                  pushRequest(req)
                  stateData.corruptedRequestCount.reset()
                  stateData.decodedRequestCount.inc
              }
            } catch {
              case e : Exception =>
                throw DecodingException("", pkt.bytes, e)
            }
        }
        stay()
      } catch {
//        case _ : IndexOutOfBoundsException =>
        case DecodingException(_, bytes, e) =>
          import codebook.runtime.util.ByteStringHelper._

          log.error(s"data:${bytes.dump()}")

          log.error(s"$printUid Decoding Request Failure")
          log.error(e.getClass.getName)
          log.error(e.getMessage)
          log.error(e.getStackTrace.map(_.toString).mkString("\n"))
          stateData.corruptedRequestCount.inc
          onCorruptRequest()

        case e : Exception =>

          log.error(s"$printUid Decoding Request Failure")
          log.error(e.getClass.getName)
          log.error(e.getMessage)
          log.error(e.getStackTrace.map(_.toString).mkString("\n"))
          stateData.corruptedRequestCount.inc
          onCorruptRequest()
      }
    case Event(res: Response, _) =>
      sendResponse(res)
      stay()

    case Event(FutureResponse(res,next,data), sd) =>
      res.foreach(self.forward(_))
      sd.data = data
      sd.waitingForFutureResponse = false
      // Derive a message via mailbox because of order of response and state change
      sd.futureDelayedSlot.foreach(self ! _)
      sd.futureDelayedSlot = Nil
      goto(next).using(sd)

    case Event(SystemMessages.Connected,_) =>
      onConnected()
    case Event(SystemMessages.Closed, _) =>
      onClosed()
    case Event(WaitingTerminationTimeout, _) =>
      onClosed()

    case Event(SystemMessages.InvalidPacketReceived, _) =>
      onInvalidPacketReceived()

    case Event(SystemMessages.InvalidTLSSession, _) =>
      onInvalidTLSSession()

    case Event(cmd: Command, _) =>
      socket ! cmd
      stay()

    case Event(req: Request, _) =>
      onUnhandledRequest(req)
  }
//  addUncategorizedHandlers(commandDecoder)
}
