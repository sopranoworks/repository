package codebook.runtime.server
import akka.actor.{Actor, ActorLogging, ActorRef, ActorSystem, Props}
import codebook.runtime.protocol.Request
import codebook.runtime.util.TimeLimits._60s

case class ApiProfileMessage(req:Request, duration:Long, error:Option[Throwable] = None)

case class ApiProfileEntry(min:Long, avg:Long, max:Long, total:Long, count:Long, errorCount:Long)

case class ApiProfileEntries(entries:Map[String,ApiProfileEntry])

object ApiProfiler {
  val actorName = "ApiProfiler"
  val actorPath = "/user/" + actorName

  private var _worker:Option[ActorRef] = None
  private var _reporter:Option[ActorRef] = None

  def setReporter(rep:ActorRef):Unit = _reporter = Some(rep)

  private case object Report

  class Worker extends Actor with ActorLogging {
    def receive: Receive = process(Map.empty)

    override def preStart(): Unit = {
      context.system.scheduler.schedule(_60s,_60s,self,Report)(context.dispatcher)
    }

    def process(entries:Map[String,ApiProfileEntry]):Receive = {
      case ApiProfileMessage(api, d, e) =>
        val name = api.getClass.getSimpleName
        context.become(process(entries.get(name) match {
          case Some(ent) =>
            entries + (name->(if (e.isEmpty) {
              ApiProfileEntry(
                min = if (d < ent.min) d else ent.min,
                avg = ent.total + d / (ent.count + 1),
                max = if (d > ent.max) d else ent.max,
                total = ent.total + d,
                count = ent.count + 1,
                errorCount = ent.errorCount
              )
            } else {
              ent.copy(errorCount = ent.errorCount + 1)
            }))
          case None =>
            entries + (name->ApiProfileEntry(d,d,d,d,if (e.isEmpty) 1 else 0,if (e.nonEmpty) 1 else 0))
        }),discardOld = true)

      case Report =>
        _reporter match {
          case Some(rep) =>
            rep ! ApiProfileEntries(entries)

          case None =>
            entries.foreach {
              case (k,v) =>
                log.info(s"$k min:${v.min} avg:${v.avg} max:${v.max} count:${v.count} error:${v.errorCount}")
            }
        }
    }
  }

  def report():Unit = {
    _worker.foreach(_ ! Report)
  }

  def start()(implicit system:ActorSystem):Unit = {
    _worker = Some( system.actorOf(Props(new Worker),actorName) )
  }
}
