package codebook.runtime.server

import akka.actor.{ActorRef, ActorSystem}
import akka.cluster.routing.{ClusterRouterGroup, ClusterRouterGroupSettings}
import akka.routing.{Group, RoundRobinGroup}

trait ClusterServiceConnector {
  private var _client:Option[ActorRef] = None

  def apply():Option[ActorRef] = _client

  def path:String

  def group:Group = RoundRobinGroup(Nil)
  def useRoles:Set[String]
  def name:String

  def start()(implicit system:ActorSystem):Unit = {
    val connector = system.actorOf(ClusterRouterGroup( group, ClusterRouterGroupSettings(
      totalInstances = 100,
      routeesPaths = List(path),
      allowLocalRoutees = true,
      useRoles = useRoles)).props(),name = name
    )
    _client = Some(connector)
  }

}
