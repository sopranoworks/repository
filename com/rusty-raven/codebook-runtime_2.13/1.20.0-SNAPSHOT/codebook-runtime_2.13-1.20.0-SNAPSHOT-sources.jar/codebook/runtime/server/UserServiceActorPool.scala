/**
  * codebook.runtime.server.UserServiceActorPool
  *
  * Copyright (c) 2016 Osamu Takahashi
  * Copyright (c) 2016 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server

import akka.actor.ActorRef
import akka.event.slf4j.SLF4JLogging

/**
  * The user service actor pool class
  * This is used as user database in system.
  */
class UserServiceActorPool extends SLF4JLogging {
  private var _serviceActors:Map[Long,ActorRef] = Map()
  private var _actorToUidRef:Map[ActorRef,Long] = Map()
  private var _observer:List[UserServiceActorPoolObserver] = List.empty

  /**
    * The registering user service actor to the pool method
    * @param id internal user id
    * @param actor a user service actor
    */
  def register(id:Long,actor:ActorRef):Unit = {
    synchronized {
      _serviceActors += (id->actor)
      _actorToUidRef += (actor->id)
    }
    _observer.foreach(_.onRegister(id,actor))
  }

  /**
    * The unregistering user service actor method
    * @param id target internal user id to unregister
    */
  def unregister(id:Long):Unit = {
    var actor:Option[ActorRef] = None
    synchronized {
      _serviceActors.get(id).foreach{
        u =>
          _serviceActors -= id
          _actorToUidRef -= u
          actor = Some(u)
      }
    }
    for {
      u <- actor
      o <- _observer
    } {
      o.onUnregister(id,u)
    }
  }

  def unregister(act:ActorRef):Unit = {
    _actorToUidRef.get(act).foreach(unregister)
  }

  /**
    * The checking containing the user method
    * @param id target internal user id to check containing
    * @return The pool contains or not (bool)
    */
  def contains(id:Long): Boolean =
    _serviceActors.contains(id)

  /**
    * The querying specific id user service actor method
    * @param id target internal user id
    * @return specific user service actor if contains
    */
  def apply(id:Long):Option[ActorRef] = _serviceActors.get(id)

  def apply(act:ActorRef):Option[Long] = _actorToUidRef.get(act)

  /**
    * The returning whole pool method
    * @return whole pool
    */
  def apply():Map[Long,ActorRef] = _serviceActors

  def foreach(f:(Long,ActorRef) => Unit):Unit = {
    _serviceActors.foreach{
      case (uid,act) =>
        f(uid,act)
    }
  }

  def all: Iterable[ActorRef] = _serviceActors.values

  def size:Int = _serviceActors.size

  def addObserver(observer: UserServiceActorPoolObserver):Unit =
    _observer ::= observer
}

object UserServiceActorPool extends UserServiceActorPool
