/**
  * codebook.runtime.server.ServerFinder
  *
  * Copyright (c) 2016-2017 Osamu Takahashi
  * Copyright (c) 2016-2017 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server

import akka.actor.{Actor, ActorLogging, ActorRef, ActorSystem, PoisonPill, Props}
import akka.cluster.Cluster
import akka.event.{EventBus, LookupClassification}
import org.slf4j.Logger

import scala.concurrent.{Await, ExecutionContext, Future}
import scala.concurrent.duration.Duration
import scala.util.Success

/**
  *
  * @tparam T the real type of server address
  */
trait ServerAddressBase[T <: ServerAddressBase[T]] {
  def serialize:String
}

case class ServerList[T](incoming:Map[String,T],staying:Map[String,T],outgoing:Map[String,T])

/**
  *
  * @tparam T
  */
trait ServerFinder[T <: ServerAddressBase[T]] {
  import codebook.runtime.util.FutureHelper._
  def key:String
  def initialId:Int = 0
  def myAddress:Option[T] = None
  def pollingDuration = 30
  def makeSignature(k:String,i:Int):String = s"$k:$i"
  def signature: String = makeSignature(key,_myRealId)//s"$key:${_myRealId}"

  def startWithDistributionService:Boolean = true

  def logger:Logger

  private var _distribute:Boolean = startWithDistributionService

  protected var _myRealId:Int = initialId

  final def myId:Int = _myRealId

  protected var _worker:Option[ActorRef] = None

  var cluster:Option[Cluster] = None
  implicit def executionContext: ExecutionContext

  private case object Refresh
  
  /**
    *
    */
  class ServerFinderNotificationBus extends EventBus with LookupClassification {
    override type Event = ServerList[T]
    override type Classifier = Int
    override type Subscriber = ActorRef

    override protected def mapSize(): Int = 16

    override protected def compareSubscribers(a: ActorRef, b: ActorRef): Int =
      a.compareTo(b)

    override protected def classify(event: ServerList[T]): Int = 0

    override protected def publish(event: ServerList[T], subscriber: ActorRef): Unit =
      subscriber ! event
  }

  object ServerFinderNotificationBus extends ServerFinderNotificationBus

  protected def finderName:String = "ServerFinder"

  protected def isReadyToStartFinding:Boolean = true

  protected def queryServer():Future[List[(String,String)]]

  protected def reserveBeaconKey(sign:String):Future[Boolean] = Future.successful(true)
  protected def cancelReservationOfBeaconKey(sign:String):Unit = {}

  protected def sendBeacon(sign:String):Unit
  protected def clearBeacon(sign:String):Unit

  protected def clearBeaconFor(i:Int):Unit = clearBeacon(makeSignature(key,i))

  def servers: Future[Map[String, T]] =
    for {
      srvs<-queryServer()
    } yield {
      srvs.flatMap(
        v => deserialize(v._2).map(v._1 -> _).filter(_._1 != signature)
      ).toMap
    }

  protected def deserialize(src:String):Option[T]

  private case class FoundServers(servers:Map[String,T])

  class Worker extends Actor with ActorLogging {
    override def preStart(): Unit = {
      context.system.scheduler.schedule(Duration.Zero,Duration(pollingDuration,"s"),self,Refresh)(context.dispatcher)
    }

    private def _checkServers(previousServers:Map[String,T]):Unit = {
      val me = self
      servers.onComplete {
        case Success(srvs) =>
          val now = srvs.keys.toList
          val prev = previousServers.keys.toList
          val stay = now.intersect(prev)
          val incoming = now.diff(stay)
          val outgoing = prev.diff(stay)

          if (incoming.nonEmpty)
            log.info(s"incoming servers:$incoming")

          ServerFinderNotificationBus.publish(ServerList(incoming.flatMap(s=>srvs.get(s).map(s->_)).toMap,stay.flatMap(s=>previousServers.get(s).map(s->_)).toMap,outgoing.flatMap(s=>previousServers.get(s).map(s->_)).toMap))
          me ! FoundServers(srvs)
        case _ =>
      }
    }

    def receive: Receive = process(Map.empty[String,T])

    def process(previousServers:Map[String,T]):Receive = {
      case Refresh =>
        /*val svc = */_checkServers(previousServers)
        if (_distribute) {
          sendBeacon(signature)
        }
//        context.become(process(svc),discardOld = true)
      case FoundServers(servers) =>
        context.become(process(servers),discardOld = true)

    }
  }

  def tryReserve(upperLimit:Int):Future[Boolean] = {
    _myRealId = myId
    reserveBeaconKey(signature).flatMap {
      res =>
        if (res) Future.successful(true) else {
          _myRealId += 1
          if (_myRealId < upperLimit) tryReserve(upperLimit) else Future.successful(false)
        }
    }.recoverWith {
      case e =>
        logger.warn(s"Trying to reserve node id with $finderName is not ready, waiting while...")
        Future.failed(e)
    }
  }

  def reserve(upperLimit:Int):Boolean = {
    Await.result(retryUntilSuccess(tryReserve(upperLimit), 15000), Duration.Inf)
  }
  def cancelReservation():Unit = {}

  def startServerDistributionService():Unit =
    _distribute = true
  
  def start()(implicit system:ActorSystem):Boolean = {
    if (_worker.isEmpty) {
      _worker = Some(system.actorOf(Props(new Worker)))
      true
    } else false
  }
  def stop():Unit = {
    _worker.foreach {
      wk =>
        wk ! PoisonPill
        clearBeacon(signature)
    }
  }
  def subscribe(listener:ActorRef):Unit = {
    ServerFinderNotificationBus.subscribe(listener,0)
  }
  def unsubscribe(listener:ActorRef):Unit = {
    ServerFinderNotificationBus.unsubscribe(listener)
  }
}
