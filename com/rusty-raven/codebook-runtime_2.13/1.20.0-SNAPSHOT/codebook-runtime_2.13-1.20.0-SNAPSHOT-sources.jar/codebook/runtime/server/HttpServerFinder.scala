package codebook.runtime.server
import akka.actor.ActorSystem
import akka.http.scaladsl.client.RequestBuilding.Get
import akka.http.scaladsl.Http
import akka.http.scaladsl.marshallers.sprayjson.SprayJsonSupport._
import akka.http.scaladsl.server.Directives._
import akka.http.scaladsl.unmarshalling.Unmarshal
import akka.stream.ActorMaterializer
import spray.json.DefaultJsonProtocol._

import scala.concurrent.{ExecutionContext, Future}
import scala.util.Success

trait HttpServerFinder[T <: ServerAddressBase[T]] extends ServerFinder[T] {
  val serviceType:String = "http"
  def serviceAddress:String
  def servicePort:Int
  def interface:String

  def memberList:List[T]

  implicit def system:ActorSystem
  implicit val materializer:ActorMaterializer = ActorMaterializer()
  implicit val executionContext: ExecutionContext = system.dispatcher

  override def startWithDistributionService: Boolean = false

  case class ServerAddresses(addresses: List[String])
  implicit val serversFormat = jsonFormat1(ServerAddresses)

  override protected def queryServer(): Future[List[(String, String)]] =
    Http().singleRequest(Get(s"$serviceType://$serviceAddress:$servicePort/servers")).flatMap {
      res=>
        Unmarshal(res).to[ServerAddresses].map(_.addresses.map(e=>(e,e)))
    }

  // Nothing to do
  override protected def sendBeacon(sign: String): Unit = {}

  // Nothing to do
  override protected def clearBeacon(sign: String): Unit = {}

  private val route =
    path("servers") {
      get {
        complete {
          ServerAddresses(cluster match {
            case Some(c) =>
              memberList.map(_.serialize)
            case None =>
              myAddress.map(addr => List(addr.serialize)).getOrElse(Nil)
          })
        }
      }
    }

  private var _binding:Option[Http.ServerBinding] = None

  override def startServerDistributionService():Unit =
    Http(system).bindAndHandle(route,interface = interface,port = servicePort).onComplete {
      case Success(bind) =>
        _binding = Some(bind)
      case _ =>
    }
  
  override def start()(implicit system: ActorSystem): Boolean = {
    super.start()
  }

  override def stop(): Unit = {
    super.stop()
  }
}
