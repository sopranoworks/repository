/**
  * codebook.runtime.server.InterConnections
  *
  * Copyright (c) 2016-2017 Osamu Takahashi
  * Copyright (c) 2016-2017 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server

import akka.actor.{Actor, ActorLogging, ActorRef, ActorSystem, Props}
import codebook.runtime.util.HasAkkaConfig

import scala.concurrent.Future
import scala.reflect.ClassTag
import scala.util.{Failure, Success}

trait InterConnectionAddress {
  def interConnectionAddress:String
  def interConnectionPort:Int
}

/**
  * @note ActorSystem's name must be matched with it's host name.
  * @tparam T
  */
trait InterConnections[T <: ServerAddressBase[T] with InterConnectionAddress] extends HasAkkaConfig {
  private var _servers = Map.empty[String,(T,ActorRef)]

  def actorName:String = "InterConnectionFinder"
  def serverFinder: ServerFinder[T]

  def host:String
  def port:Int

  def transportType = "tcp"

  override def akkaConfig:String =
s"""
akka {
  actor {
    provider = "cluster"
  }
  remote {
    log-remote-lifecycle-events = off
    artery {
      enabled = on
      transport = $transportType
      canonical.hostname = "$host"
      canonical.port = $port
    }
  }
}
"""

  def servers: Map[String, (T, ActorRef)] = _servers
  def toIterable:Iterable[(T,ActorRef)] = _servers.values

  private class Worker extends Actor with ActorLogging {
    import codebook.runtime.util.TimeLimits._

    implicit val exec = context.dispatcher

    private def _connectIncomingServers(remotes:Iterator[(String,T)]):Unit = {
      log.info(s"_connectIncomingServers:$remotes")
      remotes.foreach {
        r=>
          log.info(s"connecting:$r")
          context.system.actorSelection(s"akka://${r._1}@${r._2.interConnectionAddress}:${r._2.interConnectionPort}/user/$actorName").resolveOne(_10s).zip(Future(r))
            .onComplete {
              case Success(v) =>
                log.info("Success")
                synchronized {
                  _servers += v._2._1->(v._2._2,v._1)
                }
              case Failure(e) =>
                log.error(e.getMessage)
            }}
    }

    private def _disconnectOutgoingServers(outgoings:Iterator[(String,T)]):Unit = {
      outgoings.foreach(
        r=>
          _servers.get(r._1).foreach {
            v=>
              context.stop(v._2)
              _servers -= r._1
          })
    }
    
    def receive: Receive = {
      case ntf : ServerList[_]  =>
        log.info("receive")
        _connectIncomingServers(ntf.asInstanceOf[ServerList[T]].incoming.iterator)
        _disconnectOutgoingServers(ntf.asInstanceOf[ServerList[T]].outgoing.iterator)
    }
  }

  def start()(implicit system:ActorSystem):Unit = {
    val act = system.actorOf(Props(new Worker))
    serverFinder.subscribe(act)
  }
}
