package codebook.runtime.server

import akka.actor.{Actor, ActorContext, ActorLogging, ActorRef, Address, Props}
import akka.cluster.{Cluster, Member}
import codebook.runtime.server.GuestBookDistributor.receiverRole
import codebook.runtime.util.TimeLimits.{_10s, _5s}
import org.slf4j.LoggerFactory

import scala.concurrent.duration.FiniteDuration
import scala.util.{Failure, Success}

trait Distributor extends ClusterEventListener {
  def distributorName:String

  protected val logger = LoggerFactory.getLogger(distributorName)
  private var _keeper:Option[ActorRef] = None
  private var _cluster:Option[Cluster] = None
  private var _receivers = Map.empty[Address,ActorRef]

  private case class MemberAdded(addr:Address,connector:ActorRef)
  private case class MemberRemoved(addr:Address,ttl:Int = 3)
  private case class MemberCheckAgain(member: Member)

  protected case object Tick

  def receivers: Map[Address, ActorRef] = _receivers
  val receiverName = "CargoHandler"
  def receiverRole:String

  private def resolveAreaConnector(member: Member, cluster:Cluster, keeper:ActorRef):Unit = {
    import cluster.system.dispatcher
    logger.info(s"Found receiver id:[${member.address.toString + "/user/" + receiverName}]")
    cluster.system.actorSelection(member.address.toString + "/user/" + receiverName).resolveOne(_10s).onComplete {
      case Success(act) =>
        keeper ! MemberAdded(member.address,act)
      case Failure(_) =>
        cluster.system.scheduler.scheduleOnce(_10s,keeper,MemberCheckAgain(member))
    }
  }

  def distributionInterval:FiniteDuration

  override def onStart(members: Set[Member], self:ActorRef, context:ActorContext): Unit = {
    logger.info(s"$distributorName started with ${members.size} members")
    members.foreach(onMemberUp)
    context.system.scheduler.schedule(distributionInterval,distributionInterval,self,Tick)(context.system.dispatcher)
//    _cluster match {
//      case Some(c) => c.system.scheduler.schedule(distributionInterval,distributionInterval,self,Tick)(c.system.dispatcher)
//      case None => logger.error(s"$distributorName start failure")
//    }
  }

  override def onMemberUp(member: Member): Unit = {
    logger.info(s"onMemberUp:${member.roles}")
    if (member.hasRole(receiverRole)) {
      for {
        cluster <- _cluster
        keeper <- _keeper
      } {
        resolveAreaConnector(member,cluster,keeper)
      }
    }
  }

  override def onMemberRemoved(member: Member): Unit = {
    if (member.hasRole(receiverRole)) {
      for {
        keeper <- _keeper
      } {
        keeper ! MemberRemoved(member.address)
      }
    }
  }

  private class MemberKeeper extends Actor with ActorLogging {
    def receive:Receive = {
      case MemberAdded(addr,conn) =>
        log.info(s"Receiver added :$addr")
        _receivers += addr->conn

      case m @ MemberRemoved(addr,ttl) =>
        if (_receivers.contains(addr)) {
          _receivers -= addr
        } else {
          if (ttl > 0) {
            import context.dispatcher
            context.system.scheduler.scheduleOnce(_5s, self, m.copy(ttl = m.ttl - 1))
          }
        }

      case MemberCheckAgain(member) =>
        log.info(s"Retry resolving actor address for $member")
        _cluster.foreach(c => resolveAreaConnector(member,c,self))

      case e =>
        log.warning(s"Unhandled message received:$e(${e.getClass.getName})")
    }
  }

  override def startWithCluster(cluster: Cluster, manager :ClusterManager): Unit = {
    _cluster = Some(cluster)
    super.startWithCluster(cluster,manager)
    if (_keeper.isEmpty) {
      _keeper = Some(cluster.system.actorOf(Props(new MemberKeeper)))
    }
  }
}
