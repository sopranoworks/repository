package codebook.runtime.server

import scala.concurrent.duration.Duration

trait LimitedIntervalFeeder[S,D] { _ : UserServiceActorBase[S,D] =>
  val minimumExecutionInterval:Long = 200L

  class ExtendedUserServiceActorState(data:D) extends UserServiceActorState(data) {
    var lastExecution:Long = 0L
    var penalty = 0L
    var penaltyWaiting = false
  }

  override def createStateData(data:D):UserServiceActorState[D] = new ExtendedUserServiceActorState(data)

  private case object Fire

  final def penalty_=(d:Long):Unit = stateData.asInstanceOf[ExtendedUserServiceActorState].penalty += math.abs(d)
  final def penalty: Long = stateData.asInstanceOf[ExtendedUserServiceActorState].penalty

  override def execute():Unit = {
    val state = stateData.asInstanceOf[ExtendedUserServiceActorState]
    val t = System.nanoTime() / (1000L * 1000L)
    val d = minimumExecutionInterval + state.penalty

    if (t - state.lastExecution >= minimumExecutionInterval + state.penalty) {
      stateData.requestQueue.pop.foreach {
        req =>
          self ! req
          state.lastExecution = t
          state.penalty = 0
      }
    } else {
      if (!state.penaltyWaiting) {
        val ts = state.lastExecution + d - t
        setTimer("RequestInterval",Fire,Duration(ts,"ms"))
        state.penaltyWaiting = true
      }
    }
  }

  def intervalExecution:StateFunction = {
    case Event(Fire,_) =>
      if (!stateData.waitingForFutureResponse) {
        execute()
        stateData.asInstanceOf[ExtendedUserServiceActorState].penaltyWaiting = false
      }
      stay()
  }

  addUncategorizedHandlers(intervalExecution)
}
