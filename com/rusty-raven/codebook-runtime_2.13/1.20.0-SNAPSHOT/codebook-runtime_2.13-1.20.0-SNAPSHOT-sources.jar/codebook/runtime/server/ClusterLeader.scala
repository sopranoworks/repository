package codebook.runtime.server

import akka.actor.{ActorRef, Address}

case class ClusterLeader(address: Address, ref: ActorRef)
