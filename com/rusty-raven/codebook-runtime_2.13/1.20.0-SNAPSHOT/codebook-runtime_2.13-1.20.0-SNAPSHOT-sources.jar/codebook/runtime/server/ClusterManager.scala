package codebook.runtime.server

import akka.actor.{Actor, ActorLogging, ActorRef, ActorSystem, Address, Props}
import akka.cluster.{Cluster, Member}
import akka.cluster.ClusterEvent._
import akka.remote.{AssociatedEvent, AssociationErrorEvent, DisassociatedEvent, GracefulShutdownQuarantinedEvent, RemotingLifecycleEvent}
import codebook.runtime.util.HasAkkaConfig
import org.joda.time.DateTime
import org.slf4j.{Logger, LoggerFactory}

import scala.concurrent.Await
import scala.concurrent.duration.Duration

class ClusterServerAddress(val host:String,val port:Int,val systemName:String,val category:String,val lastUpdate:Long) extends ServerAddressBase[ClusterServerAddress] {
  override def serialize: String = s"$host:$port:$systemName:$category:$lastUpdate"
  def toAddress:Address = Address("akka", systemName, host, port)
}

object ClusterServerAddress {
  def apply(host:String,port:Int,systemName:String,category:String,lastUpdate:Long) = new ClusterServerAddress(host,port,systemName,category,lastUpdate)
  def deserialize(src:String):Option[ClusterServerAddress] =
    src.split(":").toList match {
      case host :: port :: systemName :: category :: lastUpdate :: _ =>
        Some(ClusterServerAddress(host,port.toInt,systemName,category,lastUpdate.toLong))
      case _ =>
        None
    }
  def apply(address: Address):ClusterServerAddress =
    new ClusterServerAddress(address.host.get, address.port.get, address.system, "", System.currentTimeMillis())
}

trait ClusterService {
  def startWithCluster(cluster:Cluster,manager:ClusterManager):Unit
}

trait ClusterManager extends ServerFinder[ClusterServerAddress] with HasAkkaConfig {
  override def key: String = "cluster_node"
  override def deserialize(src: String): Option[ClusterServerAddress] =
    ClusterServerAddress.deserialize(src)

  override def myAddress: Option[ClusterServerAddress] =
    _myAddress.map(a=>ClusterServerAddress(a.host,a.port,a.systemName,a.category,DateTime.now().toDate.getTime))
  def setMyAddress(host:Option[String],port:Option[Int],systemName:String):Unit =
    _myAddress = Some(ClusterServerAddress(host.getOrElse(""),port.getOrElse(0),systemName,category,0L))

  private var _manager:Option[ActorRef] = None
  protected var _myAddress:Option[ClusterServerAddress] = None

  def protocol = "akka"

  private val _logger = LoggerFactory.getLogger("ClusterManager")

  override def logger: Logger = _logger

  def host:String
  def port:Int
  override def roles:List[String] = s"${key}:$myId" :: Nil
  def category:String

  def useAkkaClusterExtension:Boolean = true

  def transportType = "tcp"

  override def akkaConfig:String =
s"""
akka {
  actor {
    provider = "cluster"
  }
  remote {
    log-remote-lifecycle-events = off
    artery {
      enabled = on
      transport = $transportType
      canonical.hostname = "$host"
      canonical.port = $port
    }
  }

  cluster {
    metrics {
      enabled=off
    }
    downing-provider-class = "akka.cluster.sbr.SplitBrainResolverProvider"
  }

  coordinated-shutdown.terminate-actor-system=on
}
"""

  override def akkaExtensions: Set[String] = if (useAkkaClusterExtension) Set("akka.cluster.metrics.ClusterMetricsExtension") else Set()

  def connectionRetryCount = 3
  
  private var _blackList = Map.empty[Address,Int]
  private var _nodes = Map.empty[Int,Address]

  private var _services = Set.empty[ClusterService]

  def addServices(srvcs:Set[ClusterService]):Unit =
    _services ++= srvcs

  def addService(svc:ClusterService):Unit =
    _services += svc

  def node(id:Int):Option[Address] = _nodes.get(id)
  def nodeIds: List[Int] = _nodes.keys.toList
  def addressToId(address: Address):Option[Int] = {
    _nodes.find {
      case (_,a) =>
        a == address
    }.map(_._1)
  }

  private def idOfMember(member:Member):Option[Int] = {
    (for {
      m <- member.roles.find(_.startsWith(key))
    } yield {
      val s = m.split(":")
      if (s.length == 2) Some(s(1).toInt) else None//:Option[Int]
    }).flatten
  }

  def downMember(address: Address):Unit = {
    _logger.info(s"Try to down member with address:$address")
    _blackList -= address
    cluster.foreach(_.down(address))
    addressToId(address).foreach(i => clearBeaconFor(i))
  }

  def onMemberUp(member:Member):Unit = {}

  def onMemberUnreachable(member:Member):Unit = {
    downMember(member.address)
  }
  def onMemberReachable(member:Member):Unit = {
    _blackList -= member.address
    idOfMember(member).foreach {
      id =>
        _logger.info(s"node:$id becomes reachable")
        _nodes += id->member.address
    }
  }
  def onMemberRemoved(member:Member):Unit = {}

  def onLeaderChanged(newLeader:Address):Unit = {}

  def onAssociationError(/*ev:AssociationErrorEvent*/ addr:Address):Unit = {
    _blackList.get(addr).foreach {
      n =>
        if (n >= connectionRetryCount) {
          cluster.foreach(_.down(addr))
          _blackList -= addr
        } else {
          _blackList += addr->(n + 1)
        }
    }
  }

  def canBecomeALeader:Boolean = false

  private case object Refresh

  class ClusterManagerActor(manager:ClusterManager) extends Actor with ActorLogging {
    import codebook.runtime.util.TimeLimits._

    def seedNodes: List[Address] = {
      val list = Await.result(servers,Duration.Inf).values.toList

      (myAddress match {
        case Some(addr) => list.filter(_ != addr)
        case None => list
      }).sortWith(_.lastUpdate > _.lastUpdate).take(10).map(
        srv=>Address(protocol,srv.systemName,srv.host,srv.port))
    }

    def bootAsLeader():Unit = {
      cluster.foreach {
        c =>
          if (canBecomeALeader) {
            log.info("Booting as leader...")
//            c.joinSeedNodes(List(Address(protocol, context.system.name, host, port)))
            c.joinSeedNodes(List(c.selfAddress))
          }
      }
    }

    //
    // Akka Cluster can not join before to uninitialized nodes
    //
    def joinOrBoot():Unit =
      cluster.foreach {
        c =>
          log.info("joinOrBoot")
          val nodes = seedNodes
          if (nodes.nonEmpty) {
            log.info(s"Try to join $nodes")
            c.joinSeedNodes(nodes)
          } else {
            bootAsLeader()
          }
          services.foreach(_.startWithCluster(c,manager))
          startServerDistributionService()
      }

    private def boot():Boolean = {
      if (isReadyToStartFinding) {
        joinOrBoot()
        context.become(process(numMember = 0))
        true
      } else {
        log.warning(s"ClusterManager with $finderName is not ready to start, waiting while...")
        context.become(waitingReady)
        false
      }
    }

    override def preStart(): Unit = {
      log.info("Starting up ClusterManager...")
      cluster = Some(Cluster(context.system))
      cluster match {
        case Some(c) =>
          val ua = c.selfUniqueAddress
          setMyAddress(ua.address.host,ua.address.port,context.system.name)

          c.subscribe(self, initialStateMode = InitialStateAsEvents,
            classOf[MemberEvent], classOf[ReachabilityEvent])
          context.system.eventStream.subscribe(self,classOf[RemotingLifecycleEvent])
          context.system.scheduler.scheduleWithFixedDelay(_15s,_15s,self,Refresh)(context.dispatcher)

          boot()

        case None =>
          log.error(s"Starting clusterManager failure")
      }
    }

    //
    // This method could not work fine.
    // Because, Akka can not execute "join" after joined some other cluster.
    //
//    def maintainingCluster():Unit = {
//      for {
//        c <- cluster
//        leader <- c.state.leader
//      } {
//        val members = c.state.members
//        val memberAddresses = members.map(_.address)
//        if (leader == c.selfMember.address) {
//          log.info(s"Maintaining the cluster as a leader")
//          val n = members.size
//
//          servers.map {
//            srvs =>
//              log.info(s"servers:${srvs.values.map(_.toAddress)}")
//              log.info(s"members:$memberAddresses")
//              // When other cluster is larger than mine
//              if (srvs.size - n >= n) {
//                val newSrvList = srvs.values.map(_.toAddress).filter(addr => !memberAddresses.contains(addr))
//                log.info(s"Another cluster found, try to join...:${newSrvList}")
//                //c.joinSeedNodes(newSrvList.toList.take(10))
//                c.join(newSrvList.head)
//              }
//          }
//        }
//      }
//    }

    def receive: Receive = process(numMember = 0)

    def waitingReady:Receive = {
      case Refresh =>
        boot()

      case msg =>
        log.info(s"Received $msg, but ignored")
    }

    def process(numMember:Int):Receive = {
      case MemberUp(member) =>
        log.info("Member is Up: {}", member.address)
        onMemberUp(member)
        context.become(process(numMember + 1))
      case UnreachableMember(member) =>
        log.info("Member detected as unreachable: {}", member)
        onMemberUnreachable(member)
      case ReachableMember(member) =>
        log.info("Member detected as reachable: {}", member)
        onMemberReachable(member)

      case MemberRemoved(member, previousStatus) =>
        log.info(
          "Member is Removed: {} after {}",
          member.address, previousStatus)
        onMemberRemoved(member)
        context.become(process(numMember - 1))

      case LeaderChanged(Some(newLeader)) =>
        onLeaderChanged(newLeader)

      case e : MemberEvent => // ignore
        log.info(s"MemberEvent:$e")

      case _ : AssociatedEvent =>
        log.info("AssociationEvent")
      case _ : DisassociatedEvent =>
        log.info("DisassociationEvent")
      case ev: AssociationErrorEvent =>
        log.info("AssociationErrorEvent")
        onAssociationError(ev.remoteAddress)
      case e @ GracefulShutdownQuarantinedEvent(uniq,_) =>
        log.info(s"GracefulShutdownQuarantinedEvent:$e")
        downMember(uniq.address)

      case ev: RemotingLifecycleEvent =>
        log.info(s"RemotingLifecycleEvent:$ev")

      case Refresh =>
        log.debug("Refresh")
        if (numMember == 0) {
          joinOrBoot()
        } /*else {
          maintainingCluster()
        } */
    }
  }

  def refresh():Unit = _manager.foreach(_ ! Refresh)

  def services: Set[ClusterService] = _services

  def terminationWaitingDuration:Duration = Duration.Inf

  override def start()(implicit system:ActorSystem):Boolean = {
    if (_manager.isEmpty) {

      _manager = Some(system.actorOf(Props(new ClusterManagerActor(manager = this)), "ClusterManager"))
      ApiProfiler.start()
      super.start()

      sys.addShutdownHook({
        println("Bye!")
        clearBeaconFor(myId)
        for {
          clstr <- cluster
        } {
          clstr.leave(clstr.selfAddress)
        }
        stop()
        system.terminate()
        Await.result(system.whenTerminated,terminationWaitingDuration)
      })
      true
    } else {
      false
    }
  }
}
