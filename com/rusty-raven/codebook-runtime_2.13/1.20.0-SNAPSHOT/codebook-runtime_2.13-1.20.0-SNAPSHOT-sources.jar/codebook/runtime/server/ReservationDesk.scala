/**
  * codebook.runtime.server.ReservationDesk
  *
  * Copyright (c) 2016-2017 Osamu Takahashi
  * Copyright (c) 2016-2017 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server

import java.util.UUID
import java.util.concurrent.TimeoutException
import akka.actor.{Actor, ActorLogging, ActorRef, ActorSystem, Props}
import akka.cluster.Cluster
import akka.cluster.client.ClusterClientReceptionist
import akka.cluster.routing.{ClusterRouterGroup, ClusterRouterGroupSettings}
import akka.pattern.ask
import akka.routing.ConsistentHashingGroup
import akka.util.Timeout
import codebook.runtime.protocol.{AkkaProtocolSerializer, AkkaRequestSerializer, AkkaResponseSerializer}
import codebook.runtime.server.reservationdesk._
import codebook.runtime.util.{HasAkkaConfig, TimeLimits}
import org.joda.time.DateTime
import org.slf4j.LoggerFactory

import scala.concurrent.duration.Duration
import scala.concurrent.{Await, ExecutionContext, ExecutionException, Future, Promise}
import scala.reflect.classTag

//trait ReservationTokenCache {
//  def registerToken(uid:Long,token:UUID,until:DateTime):Boolean
//  def unregister(uid:Long):Boolean
//  def refresh():Unit
//}

trait ReservationDesk extends ClusterService with HasAkkaConfig {
  import codebook.runtime.util.OptionHelper._
  
  private val _logger = LoggerFactory.getLogger("ReservationDesk")
  private var _nodeId = 0

  def reservationActorName = "ReservationDesk"
  def initialRoomSize = 100
//  def tokenCache:ReservationTokenCache

  def maxReservationDuration = 120 // sec

  def nodeId:Int = _nodeId

  def usingDistributor = false

  override def akkaConfig:String = ReservationDeskSerializerSettings.akkaConfig +
s"""
reservation-desk-dispatcher {
  executor = "thread-pool-executor"
  type = PinnedDispatcher
}
"""

  override def akkaExtensions: Set[String] = Set("akka.cluster.client.ClusterClientReceptionist")


  private var _front:Option[ActorRef] = None
  private var _distributor:Option[GuestBookDistributor] = None

  def front: Option[ActorRef] = _front

  protected def createToken:UUID = {
    UUID.randomUUID()
  }

  case class Residence(var maxRoomSize:Int = initialRoomSize,
                              var currentReservedRooms:Int = 0,
                              var roomLeft:Int = initialRoomSize,
                              var usingRooms:Int = 0,

                              var reservationBook:Map[String,(Long,DateTime)] = Map.empty[String,(Long,DateTime)],
                              var tokenList:Map[Long,String] = Map.empty[Long,String],
                              var guestBook:Set[Long] = Set.empty[Long],

                              var oldestReservedTime:Option[DateTime] = None
                             )

  private class Front(r:Residence) extends Actor with ActorLogging {
    import codebook.runtime.util.UUIDUtil._

    implicit def resultStatusToShort(v:ResultStatus.Value):Short = v.id.toShort

    private case object CleanUp
    private val k1 = classTag[Promise[Option[Long]]].runtimeClass
    private val k2 = classTag[Promise[Boolean]].runtimeClass

    override def preStart(): Unit = {
      val d = Duration(maxReservationDuration,"s")
      context.system.scheduler.schedule(d,d,self,CleanUp)(context.dispatcher)
    }
    
    private def _makeReservation(timestamp:Long,uid:Long):ReservationResponse = {
      if (r.roomLeft > 0) {
        val token = createToken
        val tokenStr = token.toString

        val now = DateTime.now()
        r.reservationBook += tokenStr -> (uid,now)
        r.tokenList += uid->tokenStr
        r.currentReservedRooms += 1
        r.roomLeft -= 1
        if (r.oldestReservedTime.isEmpty)
          r.oldestReservedTime = Some(now)

        log.info(s"Making reservation success for $uid")
        new MakeReservationResponse(timestamp,ResultStatus.Success,nodeId,Token(token.asByteArray))
      } else {
        log.info(s"Making reservation failure for $uid")
        new MakeReservationErrorResponse(timestamp,ResultStatus.NoRoom)
      }
    }

    private def _unregister(uid:Long):Boolean =
      (for {
        token<-r.tokenList.get(uid)
        _ <- r.reservationBook.get(token)
      } yield {
        r.reservationBook -= token
        r.tokenList -= uid
        r.currentReservedRooms -= 1
        r.roomLeft += 1
        true
      }) getOrElse false

    private def _cancelReservation(timestamp:Long,uid:Long):ReservationResponse = {
      new CancelReservationResponse(timestamp, if (_unregister(uid)) ResultStatus.Success else ResultStatus.NoReservation)
    }

    private def _checkStaying(timestamp:Long,uid:Long):ReservationResponse = {
      val res = r.guestBook.contains(uid)
      log.info(s"User[uid:$uid] is staying = $res")
      new CheckStayingResponse(timestamp,if (res) ResultStatus.Success else ResultStatus.NotHere)
    }

    private def _expandRoom(timestamp:Long,newSize:Int):ReservationResponse = {
      r.maxRoomSize = newSize
      r.roomLeft = r.maxRoomSize - (r.usingRooms + r.currentReservedRooms)
      if (r.roomLeft < 0) r.roomLeft = 0
      new ExpandRoomResponse(timestamp,ResultStatus.Success)
    }

    private def _checkIn(timestamp:Long,token: Token):ReservationResponse = {
      val uuid = token.bytes.asUuid.toString

      r.reservationBook.get(uuid).flatMap {
        e =>
          val uid = e._1
          r.reservationBook -= uuid
          r.tokenList -= uid
          r.currentReservedRooms -= 1
          r.usingRooms += 1

          if (DateTime.now().minusSeconds(maxReservationDuration).isBefore(e._2)) {
            log.info(s"Check in succeeded for uid:$uid")
            r.guestBook += uid
            Some(new CheckInResponse(timestamp, ResultStatus.Success, uid))
          } else {
            log.info(s"Token for uid $uid has been expired")
            None
          }
      } getOrElse {
        log.warning(s"No Reservation for uuid:$uuid")
        new CheckInErrorResponse(timestamp, ResultStatus.NoReservation)
      }
    }

    private def _checkOut(timestamp:Long,uid:Long):ReservationResponse =
      new CheckOutResponse(timestamp,
        if (r.guestBook.contains(uid)) {
          log.info(s"Check out succeeded for uid:$uid")
          r.guestBook -= uid
          r.usingRooms -= 1
          r.roomLeft += 1
          ResultStatus.Success
        } else {
          log.warning(s"No Room for uid:$uid")
          ResultStatus.NotHere
        })

    private def _cleanUp():Unit = {
      r.oldestReservedTime.foreach {
        ot =>
          val d = DateTime.now().minusSeconds(maxReservationDuration)

          if (ot.isBefore(d)) {
            val sz = r.reservationBook.size
            var oldest:Option[DateTime] = None

            r.reservationBook = r.reservationBook.filter {
              e =>
                val ed = e._2._2
                if (d.isBefore(ed)) {
                  oldest match {
                    case Some(dd) =>
                      if (dd.isAfter(ed))
                        oldest = Some(ed)
                    case None =>
                      oldest = Some(ed)
                  }
                  true
                } else {
                  r.tokenList -= e._2._1
                  false
                }
            }
            val sz2 = r.reservationBook.size
            r.roomLeft += sz - sz2
            r.currentReservedRooms = sz2
          }
      }
    }

    def receive:Receive = {
      case req:MakeReservationRequest =>
        sender() ! _makeReservation(req.timestamp,req.uid)

      case req:CancelReservationRequest =>
        sender() ! _cancelReservation(req.timestamp,req.uid)

      case req:CheckInRequest =>
        sender() ! _checkIn(req.timestamp,req.token)

      case (req:CheckInRequest,p:Promise[_]) if k1.isInstance(p) =>
        p.asInstanceOf[Promise[Option[Long]]].success(_checkIn(req.timestamp,req.token) match {
          case res: CheckInResponse =>
            Some(res.uid)
          case _ =>
            None
        })

      case req:CheckOutRequest =>
        sender() ! _checkOut(req.timestamp,req.uid)

      case (req:CheckOutRequest,p:Promise[_]) if k2.isInstance(p) =>
        p.asInstanceOf[Promise[Boolean]].success(_checkOut(req.timestamp,req.uid).resultStatus == 0)

      case req:CheckStayingRequest =>
        sender() ! _checkStaying(req.timestamp,req.uid)

      case req:ExpandRoomRequest =>
        sender() ! _expandRoom(req.timestamp,req.n)

      case req:GetVacancyRequest =>
        sender() ! new GetVacancyResponse(req.timestamp,ResultStatus.Success,r.maxRoomSize,r.roomLeft,r.currentReservedRooms,r.usingRooms)

      case CleanUp =>
        _cleanUp()
    }
  }

  def start()(implicit system:ActorSystem): Unit = {
    if (_front.isEmpty) {
      _logger.info("Starting ReservationDesk...")
      val residence = Residence()
      val front = system.actorOf(Props(new Front(residence)).withDispatcher("reservation-desk-dispatcher"), reservationActorName)
      if (usingDistributor) {
        _distributor = Some(new GuestBookDistributor(nodeId,residence))
      }
      _front = Some(front)
    }
  }

  override def startWithCluster(cluster: Cluster, manager :ClusterManager): Unit = {
    if (_front.isEmpty) {
      _nodeId = manager.myId
//      _logger.info("Starting ReservationDesk...")
      start()(cluster.system)
      _front.foreach(ClusterClientReceptionist(cluster.system).registerService(_))
      _distributor.foreach(_.startWithCluster(cluster,manager))
    }
  }

  def startAsLoadBalancedRouterClient(useRole:Option[String] = None)(implicit system:ActorSystem): Unit = {
    if (_front.isEmpty) {
      _front = Some(system.actorOf(ClusterRouterGroup(
        ConsistentHashingGroup(Nil),
        ClusterRouterGroupSettings(
          totalInstances = 1000,
          routeesPaths = List(s"/user/$reservationActorName"),
          allowLocalRoutees = false,
          useRole = useRole
        )).props(),reservationActorName + "Client"))
    }
  }

  @deprecated("use async version, checkIn", "1.16")
  def blockCheckIn(token:Array[Byte])(implicit timeout:Timeout = TimeLimits.timeout5s.timeout,duration:Duration = TimeLimits._5s):Option[Long] = {
    _front.flatMap {
      f =>
        try {
          val res = Await.result(f.ask(new CheckInRequest(DateTime.now().toDate.getTime, Token(token))).mapTo[ReservationResponse], duration)
          if (res.resultStatus == ResultStatus.Success.id) {
            Some(res.asInstanceOf[CheckInResponse].uid)
          } else {
            None
          }
        } catch {
          case _: TimeoutException =>
            _logger.warn("Checking in timeout")
            None
        }
    } ~> _logger.info("must start first")
  }

  @deprecated("use async version, checkOut", "1.16")
  def blockCheckOut(uid:Long)(implicit timeout:Timeout = TimeLimits.timeout5s.timeout,duration:Duration = TimeLimits._5s):Boolean = {
    _front.exists {
      f =>
        try {
          Await.result(f.ask(new CheckOutRequest(DateTime.now().toDate.getTime, uid)).mapTo[ReservationResponse],duration).resultStatus == ResultStatus.Success.id
        } catch {
          case _: TimeoutException =>
            _logger.warn("Checking out timeout")
            false
        }
    }
  }

  def checkIn(token:Array[Byte])(implicit ec: ExecutionContext, timeout:Timeout = TimeLimits.timeout5s.timeout):Future[Option[Long]] = 
    _front.map {
      f =>
        f.ask(new CheckInRequest(DateTime.now().toDate.getTime, Token(token))).mapTo[CheckInResponse].map {
          res =>
            if (res.resultStatus == ResultStatus.Success.id) {
              Some(res.uid)
            } else {
              None
            }
        }
    }.getOrElse {
      _logger.info("must start first")
      Future.successful(None)
    }

  def checkOut(uid:Long)(implicit ec: ExecutionContext, timeout:Timeout = TimeLimits.timeout5s.timeout):Future[Boolean] = 
    _front.map {
      f =>
        f.ask(new CheckOutRequest(DateTime.now().toDate.getTime, uid)).mapTo[CheckOutResponse].map {
          _.resultStatus == 0
        }
    }.getOrElse {
      _logger.info("must start first")
      Future.successful(false)
    }
}

class ReservationRequestSerializer extends AkkaRequestSerializer {//AkkaProtocolSerializer[ReservationRequest] {
//  override def identifier = 1001

  val decoder = new ProtocolDecoder
}

class ReservationResponseSerializer extends AkkaResponseSerializer {//AkkaProtocolSerializer[ReservationResponse] {
//  override def identifier = 1002

  val decoder = new ProtocolDecoder
}

object ReservationDeskSerializerSettings extends HasAkkaConfig {
  override def akkaConfig: String =
"""
akka {
  actor {
    serializers {
      resreqser = "codebook.runtime.server.ReservationRequestSerializer"
      resresser = "codebook.runtime.server.ReservationResponseSerializer"
    }
    serialization-bindings {
      "codebook.runtime.server.reservationdesk.ReservationRequest" = resreqser
      "codebook.runtime.server.reservationdesk.ReservationResponse" = resresser
    }
  }
}
"""
}
