/**
  * codebook.runtime.server.ApiHandlerSetter
  *
  * Copyright (c) 2016-2017 Osamu Takahashi
  * Copyright (c) 2016-2017 Rusty Raven Inc.
  *
  * This software is released under the MIT License.
  * http://opensource.org/licenses/mit-license.php
  *
  * @author Osamu Takahashi
  */
package codebook.runtime.server

import akka.actor.FSM
import codebook.runtime.protocol.{Request, Response}

import scala.concurrent.duration.FiniteDuration
import scala.reflect.ClassTag

trait ApiHandlerSetter[S,D] { self : FSM[S,UserServiceActorState[D]] =>

  private var _handlers = Map.empty[S,StateFunction]
  private var _uncategorizedHandlers:Option[StateFunction] = None
  private var _internalProtocols:Option[StateFunction] = None
  private var _timeouts = Map.empty[S,FiniteDuration]
  private var _bootUps = List.empty[() => Unit]
  private var _cleanUps = List.empty[D => Unit]
  private var _extraActorStateCleanUps:List[UserServiceActorState[D] => Unit] = List.empty
  
  def commandDecoder:StateFunction

  def printUid:String

  protected def addHandlers(state:S,stateFunction: StateFunction):Unit =
    _handlers += _handlers.get(state).map(sf=>state->(sf orElse stateFunction)).getOrElse(state->stateFunction)

  protected def addMultiStateHandlers(states:Iterable[S], stateFunction: StateFunction):Unit =
    states.foreach(addHandlers(_,stateFunction))

  protected def addUncategorizedHandlers(stateFunction: StateFunction):Unit =
    _uncategorizedHandlers = _uncategorizedHandlers.map(_ orElse stateFunction).orElse(Some(stateFunction))

  protected def setTimeout(state:S,timeout: FiniteDuration):Unit =
    _timeouts += state->timeout

  protected def setupHandlers():Unit = {
    _handlers.foreach(e => when(e._1, _timeouts.get(e._1).orNull)(e._2))
    // add at last
    _internalProtocols.foreach(addUncategorizedHandlers)
    addUncategorizedHandlers(commandDecoder)
    _uncategorizedHandlers.foreach(un => whenUnhandled(un))
  }

  protected def registerInternalProtocol[REQ <: Request : ClassTag,RES <: Response : ClassTag]():Unit = {
      val h:StateFunction =  {
        case Event(req : REQ, _) =>
          log.warning(s"$printUid Unhandled Internal Request has been caught here:$req")
          stay()
        case Event(res : RES, _) =>
          log.warning(s"$printUid Unhandled Internal Response has been caught here:$res")
          stay()
      }
    _internalProtocols.map(_ orElse h).orElse(Some(h))
  }

  protected def addBootUp(f:() => Unit):Unit = {
    _bootUps ::= f
  }

  protected def addCleanUp(f:D => Unit):Unit = {
    _cleanUps ::= f
  }

  protected def addExtraActorStateCleanUp(f:UserServiceActorState[D] => Unit):Unit = {
    _extraActorStateCleanUps ::= f
  }
  
  def bootUps:List[() => Unit] = _bootUps
  def cleanUps:List[D => Unit] = _cleanUps
  def extraActorStateCleanUps:List[UserServiceActorState[D] => Unit] = _extraActorStateCleanUps
}
