package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.math.{Float3, HasFloat3Position}
import codebook.runtime.util.{ByteStringHelper, ByteStringReader}

trait PlayerPosition[D,U <: UserPosition[D],P <: PlayerPosition[D,U,P]] extends HasFloat3Position {
//  def position:Float3
  def direction:D
  def timestamp:Short
  def state:Short // ServerState
  
  def toByteString:ByteString

  def toUserPosition(uid:Long):U

  def copy(position:Float3 = this.position, direction:D = this.direction, timestamp:Short = this.timestamp,state:Short = this.state):P

  override def equals(obj: Any): Boolean =
    obj.isInstanceOf[PlayerPosition[D,U,P]] && obj.asInstanceOf[PlayerPosition[D,U,P]] == this
  def ==(other:PlayerPosition[D,U,P]):Boolean =
    position == other.position && timestamp == other.timestamp && state == other.state
}

class PlayerPositionImpl(val position:Float3,val direction:Short,val userState:Short,val timestamp:Short,val state:Short) extends PlayerPosition[Short,UserPositionImpl,PlayerPositionImpl]{
  def toByteString:ByteString = position.toByteString ++
    ByteStringHelper.LE.shortToByteString(direction) ++
    ByteStringHelper.LE.shortToByteString(userState) ++
    ByteStringHelper.LE.shortToByteString(timestamp) ++
    ByteStringHelper.LE.shortToByteString(state)
  
  def toUserPosition(uid:Long):UserPositionImpl =
    new UserPositionImpl(uid,position,direction,userState)

  def == (other:PlayerPositionImpl):Boolean = super.==(other) && userState == other.userState

  def copy(position:Float3 = this.position, direction:Short = this.direction, timestamp:Short = this.timestamp,state:Short = this.state):PlayerPositionImpl =
    PlayerPositionImpl(position,direction,this.userState,timestamp,state)

  override def toString: String = s"PlayerPositionImpl($position,direction=$direction,userState=$userState,timestamp=$timestamp,state=$state)"
}

object PlayerPositionImpl {
  def apply(position:Float3,direction:Short,userState:Short,timestamp:Short,state:Short):PlayerPositionImpl
    = new PlayerPositionImpl(position,direction,userState,timestamp,state)
  def apply(reader:ByteStringReader):PlayerPositionImpl =
    PlayerPositionImpl(Float3.decode(reader),reader.readShortLE,reader.readShortLE,reader.readShortLE,reader.readShortLE)
}
