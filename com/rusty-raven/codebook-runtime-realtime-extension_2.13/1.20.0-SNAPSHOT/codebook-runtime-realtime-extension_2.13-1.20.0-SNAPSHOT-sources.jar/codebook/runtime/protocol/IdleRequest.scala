package codebook.runtime.protocol

class IdleRequest(timestamp:Long) extends Request(timestamp) {
  override def cmdId: Short = 0
}
