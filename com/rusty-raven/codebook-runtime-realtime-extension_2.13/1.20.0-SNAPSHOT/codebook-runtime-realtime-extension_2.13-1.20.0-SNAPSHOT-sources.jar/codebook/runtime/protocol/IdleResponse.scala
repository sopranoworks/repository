package codebook.runtime.protocol

class IdleResponse(timestamp:Long,resultStatus: Short) extends Response(timestamp,resultStatus) {
  override def cmdId: Short = 0
}
