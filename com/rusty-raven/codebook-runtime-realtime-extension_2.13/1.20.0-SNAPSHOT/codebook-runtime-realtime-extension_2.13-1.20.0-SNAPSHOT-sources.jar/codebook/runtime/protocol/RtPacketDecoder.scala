package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.util.{ByteStringHelper, ByteStringReader}
import org.slf4j.LoggerFactory

// RtRequest Packet
//  1.if request is exists
//    [request bytes]
//    not exist
//    [Idle request bytes]
//  2. Player Position bytes
//
// RtResponse Packet
//  1.Server State byte
//  2.if (last) response is exists
//    [response bytes]
//    not exist (maybe first time only)
//    [Idol response with 0 timestamp bytes]
//  3.Server Frame bytes (unsigned short)
//  4.Other player information
//    [How many] (unsigned byte)
//    [User Position bytes] x n

trait RtPacketDecoder[D,U <: UserPosition[D],P <: PlayerPosition[D,U,P],R <: RelativeUserPosition[D],SS <: Enumeration] {
  def decoder:Decoder

  def serverState:SS

  protected def helper:PositionHelper[D,U,P,R]
  
  private val _logger = LoggerFactory.getLogger("RtPacketDecoder")

  final val MAX_PACKET_LENGTH = 1450

  def decodeRtPacket(reader:ByteStringReader):(Option[Request],Option[P]) = {
    val req = try {
      val cid = reader.readShortLE
      if (cid == 0) {
        Some(new IdleRequest(reader.readLongLE))
      } else {
        reader.rewind(2)
        decoder.decodeRequest(reader)
      }
    } catch {
      case _ : Throwable =>
        None
    }
    val pos = try {
      if (reader.length > 0) {
        helper.decodePlayerPosition(reader)
      } else None
    } catch {
      case _ : Throwable =>
        None
    }
    (req,pos)
  }

  def encodeRtRequest(request:Option[Request],playerPosition: P):ByteString = {
    request.map(_.toByteString).getOrElse(new IdleRequest(0).toByteString) ++
      playerPosition.toByteString
  }

  def decodeRtResponse(reader:ByteStringReader):RtResponse[D,U,P,SS]/*(ServerState.Value,Option[Response],Option[UserPosition],Seq[UserPosition])*/ = {
    val stf = reader.readByte
    val st = serverState.apply(stf & 0x7f)
    val areaId = if ((stf & 0x80) != 0) {
      Some(VLong(reader).v.toInt)
    } else {
      None
    }

    val res = try {
      if (reader.readShortLE != 0) {
        reader.rewind(2)
        decoder.decodeResponse(reader)
      } else {
        // Special case, no result status(always success)
        Some(new IdleResponse(reader.readLongLE,resultStatus = 0))
      }
    } catch {
      case _ : Throwable =>
        None
    }
    val serverFrame = reader.readShortLE
    val pos = try {
      if (reader.length > 0) {
        helper.decodePlayerPosition(reader)
      } else None
    } catch {
      case _ : Throwable =>
        None
    }
    val users = try {
      pos.map {
        o=>
          val vl = reader.readByte
          (0L until vl).map(_ => helper.toUserPosition(o,helper.decodeRelativeUserPosition(reader).get)).toList
      }.getOrElse(List.empty[U])
    } catch {
      case _ : Throwable =>
        List.empty[U]
    }
    
    RtResponse(st,res,areaId,serverFrame,pos,users)
  }

  def encodeRtResponse(state:SS#Value,areaId:Option[Int],serverFrame:Int,response:Option[Response],myPosition:P,users:Seq[U],lastTimestamp:Long):ByteString = {
    var bytes =
      // server state [byte]
      ByteString(state.id.toByte | (if (areaId.isDefined) 0x80 else 0))

    // area id
    areaId.foreach(aid => bytes ++= VLong(aid).toByteString)

    // response bytes [bytes]
    bytes ++=
      response.map(r=>if (r.cmdId == 0) (ByteString(0,0) ++ ByteStringHelper.LE.longToByteString(r.timestamp)) else r.toByteString)
        .getOrElse(ByteString(0,0) ++ ByteStringHelper.LE.longToByteString(lastTimestamp)) ++
      // server frame counter [short]
      ByteStringHelper.LE.shortToByteString((serverFrame & 0xffff).toShort) ++
      // my position
      myPosition.toByteString

    val l = MAX_PACKET_LENGTH - bytes.length - 1
    val n = math.min(if (l > 0) l / helper.relativeUserPositionEncodeSize else 0,users.length)

    val bytes2 = bytes ++ ByteString(n.toByte)

    if (n > 0) {
      // Only convert UserPosition which will be send
      users.take(n).foldLeft(bytes2)((b,u) => b ++ helper.toRelativeUserPosition(myPosition,u).toByteString)
    } else {
      bytes2
    }
  }
}
