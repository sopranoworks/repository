package codebook.runtime.protocol

import codebook.runtime.math.FP163_88
import codebook.runtime.util.ByteStringReader

trait PositionHelper[D,U <: UserPosition[D],P <: PlayerPosition[D,U,P],R <: RelativeUserPosition[D]] {
  def decodeUserPosition(reader:ByteStringReader):Option[U]
  def decodePlayerPosition(reader:ByteStringReader):Option[P]
  def decodeRelativeUserPosition(reader: ByteStringReader):Option[R]

  def toRelativeUserPosition(origin:P,user:U):R
  def toUserPosition(origin:P,rel:R):U

  def userPositionEncodeSize:Int
//  def playerPositionEncodeSize:Int
  def relativeUserPositionEncodeSize:Int
}

object PositionHelperImpl extends PositionHelper[Short,UserPositionImpl,PlayerPositionImpl,RelativeUserPositionImpl] {
  override def toRelativeUserPosition(origin: PlayerPositionImpl, user: UserPositionImpl): RelativeUserPositionImpl =
    RelativeUserPositionImpl(user.uid,FP163_88(user.position - origin.position).asInstanceOf[FP163_88],user.direction,user.userState)

  override def toUserPosition(origin: PlayerPositionImpl, rel: RelativeUserPositionImpl): UserPositionImpl =
    new UserPositionImpl(rel.uid,origin.position + rel.position.toFloat3,rel.direction,rel.userState)

  override def decodeUserPosition(reader: ByteStringReader): Option[UserPositionImpl] =
    UserPositionImpl.decode(reader)

  override def decodePlayerPosition(reader: ByteStringReader): Option[PlayerPositionImpl] = Some(PlayerPositionImpl(reader))

  override def decodeRelativeUserPosition(reader: ByteStringReader): Option[RelativeUserPositionImpl] = Some(RelativeUserPositionImpl(reader))

  override def userPositionEncodeSize: Int = UserPositionImpl.ENCODE_SIZE

//  override def playerPositionEncodeSize: Int =

  override def relativeUserPositionEncodeSize: Int = RelativeUserPositionImpl.ENCODE_SIZE
}
