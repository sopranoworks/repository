package codebook.runtime.protocol

case class RtResponse[D,U <: UserPosition[D],P <: PlayerPosition[D,U,P],SS <: Enumeration](
                      state:SS#Value,
                      response:Option[Response],
                      areaId:Option[Int],
                      serverFrame:Int,
                      myPosition:Option[P],
                      users:Seq[U])
