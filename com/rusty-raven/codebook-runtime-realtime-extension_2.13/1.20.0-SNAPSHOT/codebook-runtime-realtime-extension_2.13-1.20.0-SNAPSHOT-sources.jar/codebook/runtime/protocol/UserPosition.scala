package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.math.{Float3, HasFloat3Position}
import codebook.runtime.util.{ByteStringHelper, ByteStringReader}

trait UserPosition[D] extends HasUid with HasFloat3Position {
//  def uid:Long
//  def position:Float3
  def direction:D

  def toByteString:ByteString

  def ==(other:UserPosition[D]):Boolean =
    uid == other.uid && position == other.position && direction == other.direction

  override def equals(obj: Any): Boolean =
    obj.isInstanceOf[UserPosition[D]] && obj.asInstanceOf[UserPosition[D]] == this
}

class UserPositionImpl(val uid:Long,val position:Float3,val direction:Short,val userState:Short) extends UserPosition[Short] {
  def toByteString:ByteString = ByteStringHelper.LE.longToByteString(uid) ++
    position.toByteString ++
    ByteStringHelper.LE.shortToByteString(direction) ++
    ByteStringHelper.LE.shortToByteString(userState)

  def ==(other: UserPositionImpl): Boolean = super.==(other) && userState == other.userState

  override def toString: String = s"UserPositionImpl(uid=$uid,position=$position,direction=$direction,userState=$userState)"
}

object UserPositionImpl {
  def apply(uid:Long,position:Float3,direction:Short,userState:Short):UserPositionImpl =
    new UserPositionImpl(uid,position,direction,userState)
  def decode(reader:ByteStringReader):Option[UserPositionImpl] = {
    Some(new UserPositionImpl(reader.readLongLE,Float3.decode(reader),reader.readShortLE,reader.readShortLE))
  }
  val ENCODE_SIZE:Int = 8 + 4 * 3 + 2 + 2
}
