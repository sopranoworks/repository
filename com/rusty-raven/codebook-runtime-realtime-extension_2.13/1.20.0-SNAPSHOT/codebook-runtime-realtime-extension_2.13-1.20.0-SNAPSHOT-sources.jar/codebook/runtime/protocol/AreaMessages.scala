package codebook.runtime.protocol

import akka.serialization.Serializer
import akka.util.ByteString
import codebook.runtime.util.{ByteStringHelper, ByteStringReader, HasAkkaConfig}
import org.slf4j.LoggerFactory

object AreaMessageId extends Enumeration {
  val checkIn = Value
  val checkInSuccess = Value
  val checkInFailure = Value
  val checkOut = Value
  val disconnectUser = Value
  val forceCheckOut = Value
  val forceCheckOutFromAgent = Value
  val messageContainer = Value

  val areaChangeRequest = Value
  val areaChangeRequestResponse = Value
  val areaChangeCancel = Value

  val deliverPositionDb = Value

  val observeDistanceBetween = Value
  val distanceObservationId = Value
  val cancelDistanceObservation = Value
  val distanceObservationNotification = Value

  val registerAgentObserver = Value
  val registerAgentObserverResponse = Value
  val unregisterAgentObserver = Value
  val agentObserverNotification = Value
}

trait AreaMessage {
  def messageId:AreaMessageId.Value
  def toByteString:ByteString = ByteString(messageId.id.toByte)
  def errorResponse:Option[AreaMessage] = None
}

trait AreaMessageWithUID extends AreaMessage {
  def uid:Long
  override def toByteString: ByteString = super.toByteString ++ ByteStringHelper.LE.longToByteString(uid)
}

case class CheckIn(uid:Long,token:Array[Byte],agentId:Int) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.checkIn
  override def toByteString:ByteString = super.toByteString ++
    ByteString(token) ++
    ByteStringHelper.LE.intToByteString(agentId)

  override def equals(obj: Any): Boolean =
    obj match {
      case other:CheckIn =>
        uid == other.uid && token.length == other.token.length &&
          token.zip(other.token).forall(t => t._1 == t._2) &&
          agentId == other.agentId
      case _ => false
    }
}

case class CheckInSuccess(uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.checkInSuccess
//  def toByteString:ByteString = ByteString(AreaMessageId.checkInSuccess.id.toByte) ++ ByteStringHelper.LE.longToByteString(uid)
}

case class CheckInFailure(uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.checkInFailure
//  override def toByteString = ByteString(AreaMessageId.checkInFailure.id.toByte) ++ ByteStringHelper.LE.longToByteString(uid)
}

/**
  * This message is only using from UserServiceActor to HouseMaster
  * @param uid from uid
  */
case class CheckOut(uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.checkOut
//  override def toByteString:ByteString = ByteString(AreaMessageId.checkOut.id.toByte) ++ ByteStringHelper.LE.longToByteString(uid)
}

case class MessageContainer(areaId:Int,uid:Long,bytes:ByteString) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.messageContainer
  override def toByteString:ByteString = ByteString(AreaMessageId.messageContainer.id.toByte) ++ ByteStringHelper.LE.intToByteString(areaId) ++ ByteStringHelper.LE.longToByteString(uid) ++ bytes
}

/**
  * Area to rt-agent force check out request
  * @param areaId from areaId
  * @param uid from uid
  */
case class ForceCheckOutFromArea(areaId:Int,uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.forceCheckOut
  override def toByteString:ByteString = ByteString(AreaMessageId.forceCheckOut.id.toByte) ++ ByteStringHelper.LE.intToByteString(areaId) ++ ByteStringHelper.LE.longToByteString(uid)
}

/**
  * rt-agent to Area force check out request
  * @param uid target uid
  */
case class ForceCheckOutFromAgent(uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.forceCheckOutFromAgent
//  override def toByteString:ByteString = ByteString(AreaMessageId.forceCheckOutFromAgent.id.toByte) ++ ByteStringHelper.LE.longToByteString(uid)
}

case class DisconnectUser(uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.disconnectUser
//  override def toByteString: ByteString = ByteString(AreaMessageId.disconnectUser.id.toByte)
}

case class DeliverPositionDb(areaId:Int, positionDbBytes:ByteString) extends AreaMessage {
  override def messageId: AreaMessageId.Value = AreaMessageId.deliverPositionDb
  override def toByteString: ByteString = ByteString(AreaMessageId.deliverPositionDb.id.toByte) ++ ByteStringHelper.LE.intToByteString(areaId) ++ VLong(positionDbBytes.length).toByteString ++ positionDbBytes
}

// Distance Observing Message

trait DistanceObservationMessage extends AreaMessage

case class ObserveDistanceBetween(a:Long,b:Long,distance:Int) extends DistanceObservationMessage {
  override def messageId: AreaMessageId.Value = AreaMessageId.observeDistanceBetween
  override def toByteString: ByteString = ByteString(AreaMessageId.observeDistanceBetween.id.toByte) ++ ByteStringHelper.LE.longToByteString(a) ++ ByteStringHelper.LE.longToByteString(b) ++ ByteStringHelper.LE.intToByteString(distance)
}

case class DistanceObservationId(doid:Long) extends DistanceObservationMessage {
  override def messageId: AreaMessageId.Value = AreaMessageId.distanceObservationId
  override def toByteString: ByteString = ByteString(AreaMessageId.distanceObservationId.id.toByte) ++ ByteStringHelper.LE.longToByteString(doid)
}

case class CancelDistanceObservation(doid:Long) extends DistanceObservationMessage {
  override def messageId: AreaMessageId.Value = AreaMessageId.cancelDistanceObservation
  override def toByteString: ByteString = ByteString(AreaMessageId.cancelDistanceObservation.id.toByte) ++ ByteStringHelper.LE.longToByteString(doid)
}

case class DistanceObservationNotification(doId:Long) extends DistanceObservationMessage {
  override def messageId: AreaMessageId.Value = AreaMessageId.distanceObservationNotification
  override def toByteString: ByteString = ByteString(AreaMessageId.distanceObservationNotification.id.toByte) ++ ByteStringHelper.LE.longToByteString(doId)
}

// Area Change Messages

/**
  * Area to RT-agent or RT-agent to Area change area request
  * @param from current area id
  * @param to next area id
  */
case class AreaChangeRequest(uid:Long,from:Int,to:Int) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.areaChangeRequest
  override def toByteString: ByteString = super.toByteString ++ ByteStringHelper.LE.intToByteString(from) ++ ByteStringHelper.LE.intToByteString(to)
}

/**
  * Area to RT-agent or RT-agent to Area change area request response
  * @param resultStatus result status code of that request  (0 = success)
  */
case class AreaChangeRequestResponse(uid:Long,resultStatus:Byte) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.areaChangeRequestResponse
  override def toByteString: ByteString = super.toByteString ++ ByteString(resultStatus)
}

case class AreaChangeCancel(uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.areaChangeCancel
  override def toByteString: ByteString = super.toByteString ++ ByteStringHelper.LE.longToByteString(uid)
}

// Agent Observation

case class RegisterAgentObserver(uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.registerAgentObserver
  override def errorResponse: Option[AreaMessage] = Some(RegisterAgentObserverResponse(uid,result = false))
}

case class RegisterAgentObserverResponse(uid:Long, result:Boolean) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.registerAgentObserverResponse
  override def toByteString: ByteString = super.toByteString ++ ByteStringHelper.byteToByteString(if (result) 1 else 0)
}

case class UnregisterAgentObserver(uid:Long) extends AreaMessageWithUID {
  override def messageId: AreaMessageId.Value = AreaMessageId.unregisterAgentObserver
}

object AgentObservationReason extends Enumeration {
  val disconnected = Value

  val areaChanged = Value
  val areaStateChanged = Value
}

case class AgentObserverNotification(reason:Short, value:Long) extends AreaMessage {
  override def messageId: AreaMessageId.Value = AreaMessageId.agentObserverNotification
  override def toByteString: ByteString = super.toByteString ++ ByteStringHelper.LE.shortToByteString(reason) ++ ByteStringHelper.LE.longToByteString(value)
}

// Akka Serializer

class AreaMessageSerializer extends Serializer {
  private val _logger = LoggerFactory.getLogger("AreaMessageDecoder")

  def decode(bytes:ByteString):Option[AnyRef] = {
    val reader = ByteStringReader(bytes)
    try {
      reader.readByte.toInt match {
        case c if c == AreaMessageId.checkIn.id =>
          Some(CheckIn(reader.readLongLE,reader.readBytes(16).toArray,reader.readIntLE))
        case c if c == AreaMessageId.checkInSuccess.id =>
          Some(CheckInSuccess(reader.readLongLE))
        case c if c == AreaMessageId.checkInFailure.id =>
          Some(CheckInFailure(reader.readLongLE))
        case c if c == AreaMessageId.disconnectUser.id =>
          Some(DisconnectUser(reader.readLongLE))
        case c if c == AreaMessageId.forceCheckOut.id =>
          Some(ForceCheckOutFromArea(reader.readIntLE,reader.readLongLE))
        case c if c == AreaMessageId.forceCheckOutFromAgent.id =>
          Some(ForceCheckOutFromAgent(reader.readLongLE))
        case c if c == AreaMessageId.messageContainer.id =>
          Some(MessageContainer(reader.readIntLE,reader.readLongLE, reader.readBytes(/*bytes.length - 5*/reader.length)))
        case c if c == AreaMessageId.areaChangeRequest.id =>
          Some(AreaChangeRequest(reader.readLongLE,reader.readIntLE,reader.readIntLE))
        case c if c == AreaMessageId.areaChangeRequestResponse.id =>
          Some(AreaChangeRequestResponse(reader.readLongLE, reader.readByte))
        case c if c == AreaMessageId.areaChangeCancel.id =>
          Some(AreaChangeCancel(reader.readLongLE))
        case c if c == AreaMessageId.deliverPositionDb.id =>
          Some(DeliverPositionDb(reader.readIntLE,reader.readBytes(VLong(reader).v.toInt)))
        case c if c == AreaMessageId.observeDistanceBetween.id =>
          Some(ObserveDistanceBetween(reader.readLongLE,reader.readLongLE,reader.readIntLE))
        case c if c == AreaMessageId.distanceObservationId.id =>
          Some(DistanceObservationId(reader.readLongLE))
        case c if c == AreaMessageId.cancelDistanceObservation.id =>
          Some(CancelDistanceObservation(reader.readLongLE))
        case c if c == AreaMessageId.distanceObservationNotification.id =>
          Some(DistanceObservationNotification(reader.readLongLE))
        case c if c == AreaMessageId.registerAgentObserver.id =>
          Some(RegisterAgentObserver(reader.readLongLE))
        case c if c == AreaMessageId.registerAgentObserverResponse.id =>
          Some(RegisterAgentObserverResponse(reader.readLongLE, if (reader.readByte == 0) false else true))
        case c if c == AreaMessageId.unregisterAgentObserver.id =>
          Some(UnregisterAgentObserver(reader.readLongLE))
        case c if c == AreaMessageId.agentObserverNotification.id =>
          Some(AgentObserverNotification(reader.readShortLE,reader.readLongLE))
        case _ =>
          None
      }

    } catch {
      case _ : Throwable =>
        _logger.error("Invalid Message")
        None
    }
  }

  override def identifier: Int = 9001

  override def toBinary(o: AnyRef): Array[Byte] = o match {
    case m : AreaMessage =>
      m.toByteString.toArray
    case _ =>
      throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type")
  }

  override def includeManifest: Boolean = false

  override def fromBinary(bytes: Array[Byte], manifest: Option[Class[_]]): AnyRef =
    decode(ByteString(bytes)).getOrElse(throw new RuntimeException(s"[${getClass.getTypeName}] Unknown type"))
}

object AreaMessageSettings extends HasAkkaConfig {
  override def akkaConfig: String = super.akkaConfig +
s"""
akka {
  actor {
    serializers {
      areamsgser = "codebook.runtime.protocol.AreaMessageSerializer"
    }
    serialization-bindings {
      "codebook.runtime.protocol.AreaMessage" = areamsgser
    }
  }
}
"""
}
