package codebook.runtime.protocol

import akka.util.ByteString
import codebook.runtime.util.{ByteStringHelper, ByteStringReader}
import codebook.runtime.math.{FP163, FP163_88}

trait RelativeUserPosition[D] {
  def uid:Long
  def position:FP163
  def direction:D

  def toByteString:ByteString
}

class RelativeUserPositionImpl(val uid:Long,val position:FP163,val direction:Short,val userState:Short) extends RelativeUserPosition[Short] {
  def toByteString:ByteString =
    ByteStringHelper.LE.longToByteString(uid) ++
    position.toByteString ++
    ByteStringHelper.LE.shortToByteString(direction) ++
    ByteStringHelper.LE.shortToByteString(userState)
}

object RelativeUserPositionImpl {
  def apply(uid:Long,position:FP163_88,direction:Short,userState:Short):RelativeUserPositionImpl =
    new RelativeUserPositionImpl(uid,position,direction,userState)

  def apply(reader:ByteStringReader):RelativeUserPositionImpl =
    RelativeUserPositionImpl(reader.readLongLE,FP163_88(reader).asInstanceOf[FP163_88],reader.readShortLE,reader.readShortLE)

  val ENCODE_SIZE:Int = 8 + 2 * 3 + 2 + 2
}
