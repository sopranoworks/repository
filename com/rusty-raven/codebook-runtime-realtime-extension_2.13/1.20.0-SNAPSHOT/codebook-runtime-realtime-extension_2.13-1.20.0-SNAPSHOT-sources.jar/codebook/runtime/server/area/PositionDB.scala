package codebook.runtime.server.area

import java.util.concurrent.locks.ReentrantReadWriteLock

import akka.actor.{Actor, ActorRef, ActorSystem, Props}
import akka.event.slf4j.SLF4JLogging
import akka.routing.{ActorRefRoutee, RoundRobinRoutingLogic, Router}
import codebook.runtime.math.{HasFloat3Position, Octree, Sphere}
import codebook.runtime.protocol.HasUid
import codebook.runtime.util.HasAkkaConfig

import scala.concurrent.duration.Duration
import scala.concurrent.{Await, ExecutionContext, Future, Promise}
import scala.reflect.ClassTag

trait PositionDBBase[P <: HasFloat3Position with HasUid] {
  // These constant parameters will be overridden with ConfigurationProvider's value.
  val DEFAULT_RADIUS=300
  val MAXIMUM_USER=30

  object TtlUserPosition {
    val MAX_TTL = 10
  }
  case class TtlUserPosition(userPosition: P, ttl:Int = TtlUserPosition.MAX_TTL)

  def owner:Option[Long]

  def registerUser(user:P):Unit
  def unregisterUser(cid:Long):Unit
  def buildTreeAndSwapBuffers():Unit
  def queryUsersAroundUser(cid:Long, radius:Int = DEFAULT_RADIUS):Seq[P]
  def queryUsersAroundUserWithLimit(cid:Long, maxUser:Int = MAXIMUM_USER, radius:Int = DEFAULT_RADIUS):Seq[P]
  def queryUserFromList(cids:List[Long]):Seq[P]
  def numUsers: Int

  def buffer:Option[Map[Long,P]]

  def start()(implicit system:ActorSystem):Unit = {}
}

// double buffered
class PositionDB[P <: HasFloat3Position with HasUid](val owner:Option[Long] = None) extends PositionDBBase[P] with SLF4JLogging {



  private var currentBuffer:Map[Long,TtlUserPosition] = Map()
  private var previousBuffer:Option[Map[Long,TtlUserPosition]] = None
  private var _octree:Option[Octree[P]] = None

  def octree:Option[Octree[P]] = _octree

  def distributionDb:Option[(Map[Long,P],Octree[P])] = {
    for {
      buf <- previousBuffer
      oct <- _octree
    } yield {
      (buf.map(kv => kv._1->kv._2.userPosition),oct)
    }
  }

  override def buffer:Option[Map[Long,P]] =
    previousBuffer.map(m => m.map(kv => kv._1->kv._2.userPosition))

  private val _lock = new ReentrantReadWriteLock(true)

  private def _read[T](f: => T):T = {
    _lock.readLock().lock()
    val r = f
    _lock.readLock().unlock()
    r
  }

  def registerUser(user:P):Unit = {
    _lock.writeLock().lock()
    //log.info(s"RegisterUser:$user")
    currentBuffer += (user.uid->new TtlUserPosition(user))
    _lock.writeLock().unlock()
  }

  def unregisterUser(cid:Long):Unit = {
    _lock.writeLock().lock()
    currentBuffer -= cid
    _lock.writeLock().unlock()
  }

  def buildTreeAndSwapBuffers():Unit = {
    _lock.writeLock().lock()
    //log.info("BuildAndSwap")
    _octree = Octree(currentBuffer.toSeq.map(_._2.userPosition))
    previousBuffer = Some(currentBuffer/*.map(kv=>kv._1->kv._2.copy(ttl = kv._2.ttl - 1)).filter(_._2.ttl > 0)*/)
    currentBuffer = currentBuffer.map(kv=>kv._1->kv._2.copy(ttl = kv._2.ttl - 1)).filter(_._2.ttl > 0)
    _lock.writeLock().unlock()
  }

  // async query
  def queryUsersAroundUser(cid:Long, radius:Int=DEFAULT_RADIUS):Seq[P] = _read {
    (for {
      pbuf<-previousBuffer
      upos<-pbuf.get(cid)
      octt<-_octree
    } yield {
      octt.query(Sphere(upos.userPosition.position,radius.toFloat)).filter(_.uid != cid)
    }).getOrElse(Seq())
  }
  def queryUsersAroundUserWithLimit(cid:Long, maxUser:Int=MAXIMUM_USER, radius:Int=DEFAULT_RADIUS):Seq[P] = _read {
    queryUsersAroundUser(cid,radius).slice(0,maxUser)
  }

  def queryUserFromList(cids:List[Long]):Seq[P] =
    previousBuffer.map {buf =>
      for (cid<-cids;
            p<-buf.get(cid))
        yield p.userPosition //).toSeq
    }.getOrElse(Seq())

  def numUsers: Int = currentBuffer.size
}

class AsyncPositionDB[P <: HasFloat3Position with HasUid : ClassTag](val owner:Option[Long] = None) extends PositionDBBase[P] with SLF4JLogging {
  private var currentBuffer:List[TtlUserPosition] = List()
  private var previousBuffer:Option[Map[Long,TtlUserPosition]] = None
  private var octree:Option[Octree[P]] = None

  private var _workers:Vector[ActorRef] = Vector()
  private var _system:Option[ActorSystem] = None
  private var _router:Option[Router] = None

  private case class Gather(completion:Promise[(List[TtlUserPosition],List[Long])])

  private class Worker extends Actor {
    private val clazz = implicitly[ClassTag[P]].runtimeClass
    def process(queue:List[TtlUserPosition],unregisters:List[Long]):Receive = {
      case p if clazz.isInstance(p) =>
        context.become(process(new TtlUserPosition(p.asInstanceOf[P]) :: queue,unregisters))
      case uid: Long =>
        context.become(process(queue,unregisters :+ uid))

      case Gather(p) =>
        p.success(queue,unregisters)
        context.become(process(List(),List()))
    }
    
    def receive: Receive = process(List(),List())
  }

  override def buffer:Option[Map[Long,P]] =
    previousBuffer.map(m => m.map(kv => kv._1->kv._2.userPosition))

  override def registerUser(user: P): Unit =
    _router.foreach(_.route(user,null))

  override def unregisterUser(cid: Long): Unit =
    _router.foreach(_.route(cid,null))

  override def buildTreeAndSwapBuffers(): Unit = {
    _system.foreach {
      sys =>
        implicit val ec: ExecutionContext = sys.dispatchers.lookup("positiondb-worker-dispatcher")
        val gather = _workers.map {
          w =>
            val p = Promise[(List[TtlUserPosition],List[Long])]()
            w ! Gather(p)
            p.future
        }
        val (r,u) = Await.result(Future.sequence(gather).mapTo[Vector[(List[TtlUserPosition],List[Long])]], Duration.Inf).unzip
        val regs = currentBuffer ++ r.flatten

        var current = regs.map(e => e.userPosition.uid->e).toMap
        u.flatten.foreach (current -= _)

        currentBuffer = current.values.toList
        previousBuffer = Some(current)

        octree = Octree(currentBuffer.map(_.userPosition))
        currentBuffer = currentBuffer.map(e => e.copy(ttl = e.ttl - 1)).filter(_.ttl > 0)
    }
  }

  override def queryUsersAroundUser(cid: Long, radius: Int): Seq[P] =
    (for {
      pbuf<-previousBuffer
      upos<-pbuf.get(cid)
      octt<-octree
    } yield {
      octt.query(Sphere(upos.userPosition.position,radius.toFloat)).filter(_.uid != cid)
    }).getOrElse(Seq())

  override def queryUsersAroundUserWithLimit(cid: Long, maxUser: Int, radius: Int): Seq[P] =
    queryUsersAroundUser(cid,radius).slice(0,maxUser)

  override def queryUserFromList(cids: List[Long]): Seq[P] =
    previousBuffer.map {buf =>
      for (cid<-cids;
            p<-buf.get(cid))
        yield p.userPosition
    }.getOrElse(Seq())

  override def numUsers: Int = currentBuffer.size

  override def start()(implicit system:ActorSystem):Unit = {
    _system = Some(system)
    _workers = 0.until(16).map(_ => system.actorOf(Props(new Worker).withDispatcher("positiondb-worker-dispatcher"))).toVector
    val router = Router(RoundRobinRoutingLogic(),_workers.map {
      w =>
        ActorRefRoutee(w)
    } /*.toIndexedSeq*/)
    _router = Some(router)
  }
}

object AsyncPositionDB extends HasAkkaConfig {
  override def akkaConfig:String =
s"""
positiondb-worker-dispatcher {
  type = Dispatcher
  executor = "fork-join-executor"
  fork-join-executor {
    parallelism-min = 4
    parallelism-factor = 4.0
    parallelism-max = 64
  }
  throughput = 5
}
"""
}
