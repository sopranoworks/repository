package codebook.runtime.server.util

import akka.actor.{Actor, ActorContext, ActorLogging, ActorRef, ActorSystem, Address, Props}
import akka.cluster.{Cluster, Member}
import codebook.runtime.server.{ClusterEventListener, ClusterManager}
import org.slf4j.LoggerFactory

import scala.concurrent.duration.Duration
import scala.concurrent.Future
import scala.util.{Failure, Success}

class AreaFinder extends ClusterEventListener {
  import codebook.runtime.util.TimeLimits._

  private val _logger = LoggerFactory.getLogger("AreaFinder")
  private var _keeper:Option[ActorRef] = None
//  private var _cluster:Option[Cluster] = None
  private var _system:Option[ActorSystem] = None
  private var _areaServers = Map.empty[Int,ActorRef]

  private case class AreaServerMember(areaId:Int,address:Address/*,connector:ActorRef*/)

  private var _areaServerMembers = Map.empty[Address, AreaServerMember]

  val areaRoleSignature:String = "area"
  private val areaRoleSignaturePrefix = areaRoleSignature + "_"

  def connectorFor(n:Int):Option[ActorRef] = _areaServers.get(n)
  def roleFor(n:Int):String = areaRoleSignaturePrefix + n
  def lateArrivalPriority:Boolean = true

  override def actorName: String = "AreaFinder"

  private def _checkArea(member: Member):Option[Int] = {
    member.roles.find(_.startsWith(areaRoleSignaturePrefix)).flatMap {
      e =>
        e.split("_").toList match {
          case _ :: n :: Nil =>
            try {
              Some(n.toInt)
            } catch {
              case _ : Throwable =>
                None
            }
          case _ =>
            None
        }
    }
  }

  private case class MemberAdded(n:Int,member: AreaServerMember, conn:ActorRef)
  private case class MemberRemoved(n:Int,ttl:Int = 3, member: Member)
  private case class MemberCheckAgain(n:Int,member: Member)

  override def onStart(members: Set[Member], self:ActorRef, context:ActorContext): Unit = {
    members.foreach(onMemberUp)
  }

  private def resolveAreaConnector(n:Int,member: Member, system:ActorSystem, keeper:ActorRef):Unit = {
    import system.dispatcher
    if (_areaServerMembers.contains(member.address)) {
      _logger.info(s"Found area server id:$n[${member.address.toString + "/user/CargoHandler"}]")
      system.actorSelection(member.address.toString + "/user/CargoHandler").resolveOne(_10s).onComplete {
        case Success(act) =>
          keeper ! MemberAdded(n, AreaServerMember(n, member.address/*, act*/), act)
        case Failure(e) =>
          _logger.warn(s"Resolve area connector failure: ${e.toString} ${e.getMessage}")
          system.scheduler.scheduleOnce(_10s, keeper, MemberCheckAgain(n, member))
      }
    } else {
      _logger.info(s"Found area server id:$n[${member.address.toString + "/user/CargoHandler"}], but already removed")
    }
  }

//  private def reconstructAreaServerForId(areaId:Int):Unit = {
//    _areaServerMembers.values.find(_.areaId == areaId).foreach {
//      member =>
//        _logger.info(s"Renewed area connector for id:$areaId")
//        _areaServers += areaId -> member.connector
//    }
//  }

  private def removeAreaId(areaId:Int, member: Member):Unit = {
    _logger.info(s"Area id:$areaId has gone")
    _areaServers -= areaId
    _areaServerMembers -= member.address

//    reconstructAreaServerForId(areaId)
  }

  override def onMemberUp(member: Member): Unit = {
    for {
      n <- _checkArea(member)
      system <- _system
      keeper <- _keeper
    } {
      _areaServerMembers += member.address-> AreaServerMember(n, member.address)
      resolveAreaConnector(n,member,system,keeper)
    }
  }

  override def onMemberRemoved(member: Member): Unit = {
    for {
      areaId <- _checkArea(member)
      keeper <- _keeper
    } {
      keeper ! MemberRemoved(areaId,member = member)
    }
  }

  class MemberKeeper extends Actor with ActorLogging {
    private case object Tick
    private val d = Duration(5,"m")

    override def preStart(): Unit = {
      import context.dispatcher
      context.system.scheduler.scheduleWithFixedDelay(d,d,self,Tick)
    }

    def displayFoundArea():Unit = {
      import context.dispatcher

      Future {
        log.info("Found Area:")
        _areaServers.foreach {
          case (k,v) =>
            log.info(s"=> $k : ${v.path.address}")
        }
      }
    }

    def receive:Receive = {
      case MemberAdded(n,member, conn) =>
        log.info(s"Incoming new member:$n, $member")
        val exists = _areaServers.contains(n)

        if (lateArrivalPriority || !exists) {
          if (exists) {
            log.info(s"Area connector overwrote id:$n")
          } else {
            log.info(s"Area connector added id:$n")
          }
          _areaServers += n -> conn//member.connector
        } else {
          _logger.warn(s"Duplicated area id:$n, Did not overwrite.")
        }

      case m @ MemberRemoved(n,ttl,member) =>
        log.info(s"Member Removed:$n, $member (ttl = $ttl)")
        if (_areaServerMembers.contains(member.address)) {
          removeAreaId(n,member)
        } else {
          if (ttl > 0) {
            import context.dispatcher
            context.system.scheduler.scheduleOnce(_5s, self, m.copy(ttl = m.ttl - 1))
          } else {
            removeAreaId(n,member)
          }
        }

      case MemberCheckAgain(n,member) =>
        log.info(s"Retry resolving actor address for $member id:$n")
        _system.foreach(sys => resolveAreaConnector(n,member,sys,self))

      case Tick =>
        displayFoundArea()

      case e =>
        log.warning(s"Unhandled message received:$e(${e.getClass.getName})")
    }
  }

  def start()(implicit system:ActorSystem):Unit = {
    if (_keeper.isEmpty) {
      _system = Some(system)
      _keeper = Some(system.actorOf(Props(new MemberKeeper)))
    }
  }

  override def startWithCluster(cluster: Cluster, manager :ClusterManager): Unit = {
    super.startWithCluster(cluster,manager)
    start()(cluster.system)
  }
}
