package codebook.runtime.server.util

import codebook.runtime.protocol.{CancelDistanceObservation, DistanceObservationNotification, ObserveDistanceBetween}
import codebook.runtime.server.{ExtraActorState, UserServiceActorBase, UserServiceActorState}

import scala.concurrent.{Future, Promise}

case class DistanceObservationData(var registerResponse:Option[Promise[Long]] = None,var observations:Set[Long] = Set.empty) extends ExtraActorState

trait DistanceObservation[S,D] { _ : UserServiceActorBase[S,D] =>
  def areaFinder:AreaFinder
  def areaId:Option[Int]

  val DISTANCE_OBSERVATION_EXTRA_ID:Int = 0x4002

  def createDistanceObservation(targetId:Long, distance:Int):Future[Long] =
    (for {
      aid <- areaId
      conn <- areaFinder.connectorFor(aid)
      myId <- uid
    } yield {
      conn ! ObserveDistanceBetween(myId, targetId, distance)
      val p = Promise[Long]()
      val data = stateData.extraActorStates.get(DISTANCE_OBSERVATION_EXTRA_ID).flatMap(e => Option(e.asInstanceOf[DistanceObservationData])).getOrElse(DistanceObservationData())

      data.registerResponse = Some(p)
      stateData.extraActorStates += DISTANCE_OBSERVATION_EXTRA_ID->data

      p.future
    }).getOrElse(Future.successful(-1))

  def disposeDistanceObservation(doId:Long):Unit =
    for {
      aid <- areaId
      conn <- areaFinder.connectorFor(aid)
    } yield {
      conn ! CancelDistanceObservation(doId)
    }

  def onDistanceObserverNotify(doId:Long, data:D):(D,Option[S]) =
    (data,None)

  def distanceObservationEvent:StateFunction = {
    case Event(ntf:DistanceObservationNotification , state) =>
      val (data, nextState) = onDistanceObserverNotify(ntf.doId, state.data)
      state.data = data
      nextState.map(goto).getOrElse(stay()).using(state)
  }

  addUncategorizedHandlers(distanceObservationEvent)
  addExtraActorStateCleanUp((state:UserServiceActorState[D]) => {
    stateData.extraActorStates.get(DISTANCE_OBSERVATION_EXTRA_ID).flatMap(e => Option(e.asInstanceOf[DistanceObservationData])).foreach(
      _.observations.foreach(disposeDistanceObservation)
    )
  })
}
