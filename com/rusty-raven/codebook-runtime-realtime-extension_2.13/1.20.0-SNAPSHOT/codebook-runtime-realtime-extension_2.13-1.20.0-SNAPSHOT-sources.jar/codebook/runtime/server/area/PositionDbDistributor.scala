package codebook.runtime.server.area

import akka.actor.Actor.Receive
import akka.actor.{Actor, ActorContext, ActorLogging, ActorRef, Address, Props}
import akka.cluster.{Cluster, Member}
import akka.util.ByteString
import codebook.runtime.math.PositionSerializer
import codebook.runtime.protocol._
import codebook.runtime.server.{ClusterEventListener, ClusterManager}
import codebook.runtime.util.ByteStringReader
import codebook.runtime.util.TimeLimits.{_10s, _5s}
import org.slf4j.LoggerFactory

import scala.concurrent.duration.Duration
import scala.util.{Failure, Success}

class PositionDbDistributor[D,U <: UserPosition[D],P <:PlayerPosition[D,U,P],R <: RelativeUserPosition[D]](areaId:Int,val positionDB:PositionDBBase[U], helper:PositionHelper[D,U,P,R]) extends ClusterEventListener {
  import PositionDbDistributor._
  
  private implicit object Serializer extends PositionSerializer[U] {
    override def encode(p: U): ByteString = p.toByteString

    override def decode(reader: ByteStringReader): U =
      helper.decodeUserPosition(reader).get
  }

  private val _logger = LoggerFactory.getLogger("PDBDistributor")
  private var _keeper:Option[ActorRef] = None
  private var _cluster:Option[Cluster] = None
  private var _receivers = Map.empty[Address,ActorRef]

  private case class MemberAdded(addr:Address,connector:ActorRef)
  private case class MemberRemoved(addr:Address,ttl:Int = 3)
  private case class MemberCheckAgain(member: Member)

  private case object Tick

  override def actorName: String = "PosDist"

  private def resolveAreaConnector(member: Member, cluster:Cluster, keeper:ActorRef):Unit = {
    import cluster.system.dispatcher
    _logger.info(s"Found receiver id:[${member.address.toString + "/user/CargoHandler"}]")
    cluster.system.actorSelection(member.address.toString + "/user/CargoHandler").resolveOne(_10s).onComplete {
      case Success(act) =>
        keeper ! MemberAdded(member.address,act)
      case Failure(_) =>
        cluster.system.scheduler.scheduleOnce(_10s,keeper,MemberCheckAgain(member))
    }
  }

  val distributionInterval = Duration(1,"s")

  override def onStart(members: Set[Member], self:ActorRef, context:ActorContext): Unit = {
    members.foreach(onMemberUp)
    _cluster.foreach(c => c.system.scheduler.schedule(distributionInterval,distributionInterval,self,Tick)(c.system.dispatcher))
  }

  override def onMemberUp(member: Member): Unit = {
    if (member.hasRole(receiverRole)) {
      for {
        cluster <- _cluster
        keeper <- _keeper
      } {
        resolveAreaConnector(member,cluster,keeper)
      }
    }
  }

  override def onMemberRemoved(member: Member): Unit = {
    if (member.hasRole(receiverRole)) {
      for {
        keeper <- _keeper
      } {
        keeper ! MemberRemoved(member.address)
      }
    }
  }

  private def encodeBuffer(buffer:Map[Long,U]):ByteString =
    // omit key(uid). because U has a uid.
    buffer.foldLeft(VLong(buffer.size).toByteString)((b,kv) => b ++ kv._2.toByteString)

  private var count:Int = 0

  def process:Receive = {
    case Tick =>
      positionDB.buffer.foreach {
        buffer =>
          val bytes = encodeBuffer(buffer)
          val msg = DeliverPositionDb(areaId,bytes)
          if (count == 0) {
            _logger.info(s"[Area $areaId] Sending PositionDB, number of receiver = ${_receivers.size}")
          }
          count = (count + 1) % 60
          _receivers.values.foreach(_ ! msg)  // TODO: Encoding many times?

      }
  }

  override def eventHandler: Receive = process orElse super.eventHandler

  private class MemberKeeper extends Actor with ActorLogging {
    def receive:Receive = {
      case MemberAdded(addr,conn) =>
        log.info(s"Receiver added :$addr")
        _receivers += addr->conn

      case m @ MemberRemoved(addr,ttl) =>
        if (_receivers.contains(addr)) {
          log.info(s"Receiver removed :$addr")
          _receivers -= addr
        } else {
          if (ttl > 0) {
            import context.dispatcher
            context.system.scheduler.scheduleOnce(_5s, self, m.copy(ttl = m.ttl - 1))
          }
        }

      case MemberCheckAgain(member) =>
        log.info(s"Retry resolving actor address for $member")
        _cluster.foreach(c => resolveAreaConnector(member,c,self))

      case e =>
        log.warning(s"Unhandled message received:$e(${e.getClass.getName})")
    }
  }
  
  override def startWithCluster(cluster: Cluster, manager :ClusterManager): Unit = {
    super.startWithCluster(cluster,manager)
    if (_keeper.isEmpty) {
      _cluster = Some(cluster)
      _keeper = Some(cluster.system.actorOf(Props(new MemberKeeper)))
    }
  }
}

object PositionDbDistributor {
  def receiverRole = "pdb_recv"
}
