package codebook.runtime.server.rtagent

import akka.actor.Actor
import codebook.runtime.protocol.SystemMessages.Tick

import scala.concurrent.duration.{Duration, MILLISECONDS}

class GateTicker extends Actor {
  import GateTicker._

  override def preStart(): Unit = {
    import context.dispatcher
    context.system.scheduler.schedule(tickDuration,tickDuration,self,Tick)
  }

  override def receive: Receive = {
    case Tick =>
      context.system.eventStream.publish(Tick)
  }
}

object GateTicker {
  val tickDuration = Duration(200,MILLISECONDS)
}
