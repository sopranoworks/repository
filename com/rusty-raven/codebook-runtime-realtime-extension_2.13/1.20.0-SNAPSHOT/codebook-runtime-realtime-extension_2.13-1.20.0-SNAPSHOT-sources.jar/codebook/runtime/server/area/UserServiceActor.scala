package codebook.runtime.server.area

import akka.actor.{Actor, ActorLogging, ActorRef, ReceiveTimeout}
import akka.util.ByteString
import codebook.runtime.protocol._
import codebook.runtime.util.ByteStringReader

import scala.concurrent.Promise
import scala.reflect.ClassTag
import scala.util.{Failure, Success}


abstract class UserServiceActor[D,U <: UserPosition[D],P <: PlayerPosition[D,U,P] : ClassTag,R <: RelativeUserPosition[D],SS <: Enumeration,UD : ClassTag]
  extends Actor with ActorLogging
  with RtPacketDecoder[D,U,P,R,SS] {
  import codebook.runtime.util.TimeLimits._

  def debug(f: => Unit):Unit = if (log.isDebugEnabled) f

  def positionDebug:Boolean = false

  val MAX_INITIAL_POSITION_UNMATCHED_WARNING:Int = 10 // temporary
  val MAX_NO_DATA_COUNT:Int = 5 * 30 // 30 sec / temporary

  case class UserState(state:SS#Value,
                               stateDef: StateDef[SS],
                               lastTimestamp:Long,
                               lastRequest:Option[Request] = None,
                               position:P,
                               res:Option[Response],
                               queue:OptimizedRequestQueue,
                               receivedBytes:Int,
                               requestTerminate:Boolean = false,
                               nextPosition:Option[P],
                               nextState:Option[SS#Value] = None,
                               serverFrame:Int,
                               positionUnmatchWarning:Int = 0,
                               hasData:Boolean = false,
                               noDataFrameCount:Int = 0,
                               waitingPositionToTransition:Boolean = false,
                               areaChangeResult:Option[Promise[AreaChangeRequestResponse]] = None,
                               userData:UD
                              ) {
    def changingArea:Boolean = state == areaChangingServerState || areaChangeResult.isDefined
  }

  case class IncomingRequest(from:ActorRef, req:Any)
  case class IncomingRequests(requests:List[IncomingRequest])
  case class AreaChangeResult(nextState:SS#Value, res:Boolean)

  private def _decodeAndEnqueue(bytes:ByteString,userState:UserState):(Option[Request],Option[P]) = {
    val reader = ByteStringReader(bytes)
    val (req,pos) = decodeRtPacket(reader)

    (req.flatMap(r => if (r.timestamp <= userState.lastTimestamp) {
      debug(log.debug(s"previous timestamp request was received, ignored: $r"))
      None
    } else Some(r)),pos)
  }

  override def preStart(): Unit = {
    context.system.eventStream.subscribe(self,classOf[SyncMessage])
    log.info("UserServiceActor starting")
  }

  //
  // parameters to be needed
  //
  def areaId:Int
  def uid:Long
  def houseMaster: ActorRef
  def positionDB: PositionDBBase[U]
  def agent:ActorRef
  def agentId:Int

  def stateDefs:StateDefProvider[SS]

  //
  //
  //
  def initialUserPosition:P
  def initialServerState:SS#Value
  def runningServerState:SS#Value
  def areaChangingServerState:SS#Value = runningServerState
  def createRequestQueue:OptimizedRequestQueue = new OptimizedRequestQueue {}
  def initialUserData:UD

  def playerPositionToUserPosition(playerPos:P,uid:Long, userData:UD):U = playerPos.toUserPosition(uid)

  def stateDefOf(state:SS#Value):StateDef[SS] = stateDefs(state)

  //
  // TODO: Unify into Api
  //
  def changeState(state:SS#Value,oldUserState:UserState,nextPosition:Option[P] = None):UserState = {
    if (state != oldUserState.state) {
      log.info(s"Change state from ${oldUserState.state} to $state")
      val stateDef = stateDefOf(state)
      if (!stateDef.positionDbRegistration) positionDB.unregisterUser(uid)
      oldUserState.copy(state = state,
        stateDef = stateDef,
        position = nextPosition.getOrElse(oldUserState.position).copy(state = state.id.toShort),
        noDataFrameCount = 0,
        nextState = None,
        waitingPositionToTransition = stateDef.waitingPositionToTransition
      )
    } else {
      log.info(s"Discard changing state from ${oldUserState.state} to $state (same state)")
      oldUserState
    }
  }

  def receive: Receive = idling(UserState(
    state = initialServerState,
    stateDef = stateDefOf(initialServerState),
    waitingPositionToTransition = stateDefOf(initialServerState).waitingPositionToTransition,
    lastTimestamp = -1,
    position = initialUserPosition,
    res = None,
    queue = createRequestQueue,
    receivedBytes = 0,
    nextPosition = None,
    serverFrame = 0,
    userData = initialUserData
  ))

  def shutdown():Unit = {
    log.info(s"[$uid] Shutting down UserService")
    houseMaster ! CheckOut(uid)
    context.system.eventStream.unsubscribe(self)
    context.setReceiveTimeout(_10s)
    context.become(waitingShutdown)
  }

  final class Api(private var userState:UserState,myself:ActorRef) {

    // temporary
    def modifiedUserState:UserState = userState

    def state:SS#Value = userState.state

    def userData:UD = userState.userData
    def userData_=(newUserData:UD):Unit = {
      userState = userState.copy(userData = newUserData)
    }

    def lastTimestamp:Long = userState.lastTimestamp
    def lastRequest:Option[Request] = userState.lastRequest

    def changeState(state:SS#Value,nextPosition:Option[P] = None):Boolean = {
      if (state != userState.state) {
        log.info(s"Change state from ${userState.state} to $state")
        val stateDef = stateDefOf(state)
        if (!stateDef.positionDbRegistration) positionDB.unregisterUser(uid)
        userState = userState.copy(state = state,
          stateDef = stateDef,
          position = nextPosition.getOrElse(userState.position).copy(state = state.id.toShort),
          noDataFrameCount = 0,
          nextState = None,
          waitingPositionToTransition = stateDef.waitingPositionToTransition
        )
        true
      } else {
        log.info(s"Discard changing state from ${userState.state} to $state (same state)")
        false
      }
    }

    /**
      * AreaChange request from area server
      *
      * @param to the destination area id
      * @return result
      */
    def changeArea(to:Int):Boolean = {
      if (!userState.changingArea && checkCanAreaChangeTo(to)) {
        import context.dispatcher
        val p = Promise[AreaChangeRequestResponse]()
        p.future onComplete {
          case Success(res) =>
            if (res.resultStatus == 0) {
              log.info(s"[$uid] ChangeArea request success.")

              //
              // result success = exit from current(previous) area
              //
              myself ! ForceCheckOutFromAgent(uid)

            } else {
              log.info(s"[$uid] ChangeArea request rejected from rt-agent. resultStatus=${res.resultStatus}")
              val nextState = userState.stateDef.nextState getOrElse runningServerState
              myself ! AreaChangeResult(nextState,res = true)
            }
          case Failure(e) =>
            log.warning(s"[$uid] changeArea request failure: reason=${e.getMessage}")
            val nextState = userState.stateDef.nextState getOrElse runningServerState
            myself ! AreaChangeResult(nextState,res = false)
        }
        agent ! AreaChangeRequest(uid, areaId, to)
        changeState(areaChangingServerState)
        userState = userState.copy(areaChangeResult = Some(p))
        true
      } else {
        false
      }
    }

    def specifyNewPosition(newPosition:P):Unit = {
      userState = userState.copy(position = newPosition)
    }
  }

  // Process RT commands
  // override this
  def processRequest(req:Request, api:Api):Option[Response] = req match {
    case r:IdleRequest =>
      Some(new IdleResponse(r.timestamp,resultStatus = 0))
    case _ => None
  }

  // override this
  def processInternalRequest(req:Request, api:Api):(Option[Response],Option[P]) =
    (None,None)

  def checkCanAreaChangeTo(newAreaId:Int):Boolean = newAreaId != areaId

  def onCompleteAreaChange(res:Boolean, api:Api):Unit = {}

  def idling(userState:UserState):Receive = {
    case Begin(frame) =>
      debug(log.debug(s"Begin($frame) state = ${userState.state}"))
      if (userState.stateDef.noDataCheck && userState.noDataFrameCount > MAX_NO_DATA_COUNT) {
        log.info(s"[$uid] no data received $MAX_NO_DATA_COUNT count, shutting down...")
        agent ! ForceCheckOutFromArea(areaId,uid)
        shutdown()
      } else {
        context.become(processFrame(userState.copy(/*request = userState.queue.pop, */serverFrame = frame, hasData = false, noDataFrameCount = if (!userState.stateDef.noDataCheck || userState.hasData) 0 else userState.noDataFrameCount + 1)), discardOld = true)
      }

    case bytes: ByteString =>
      val (req,p) = _decodeAndEnqueue(bytes,userState)
      req.foreach(r => if (userState.stateDef.processingRequest) userState.queue.push(r))
      p match {
        case Some(nextPos) =>
          //
          // This time,  nextPosition is just overwritten
          //
          if (positionDebug) {
            log.info(s"[$uid] current = ${userState.position} nextPos = $nextPos")
          }
          context.become(idling(userState.copy(receivedBytes = userState.receivedBytes + 1,hasData = true,nextPosition = p,noDataFrameCount = 0)),discardOld = true)
        case None =>
          context.become(idling(userState.copy(receivedBytes = userState.receivedBytes + 1,hasData = true,noDataFrameCount = 0)),discardOld = true)
      }

      // illegal, but for safe
    case Tick(p) =>
      debug(log.debug("illegal message sending: Tick"))
      p.success(false)

      // illegal, but for safe
    case Tock(p) =>
      debug(log.debug("illegal message sending: Tock"))
      p.success(false)

    case _ : ForceCheckOutFromAgent =>
      log.info(s"[$uid] Going to terminate...")
      shutdown()

      //
      // process internal request (not from client)
      //
    case req : Request =>
      val api = new Api(userState, self)
      val (res, nextPos) = processInternalRequest(req, api)
      res.foreach(sender() ! _)
      context.become(idling(api.modifiedUserState),discardOld = true)

    case IncomingRequests(requests) =>
      requests.foreach {
        case IncomingRequest(from,req) =>
          self.tell(req, from)
      }

    case AreaChangeRequest(_,from,to) =>
      if (!userState.changingArea && from == areaId && checkCanAreaChangeTo(to)) {
        log.info(s"[$uid] AreaChangeRequest received and accepted.")
        sender() ! AreaChangeRequestResponse(uid,0)
        context.become(idling(changeState(areaChangingServerState, userState)),discardOld = true)
      } else {
        log.info(s"[$uid] AreaChangeRequest(from = $from,to = $to) received But denied. ")
        sender() ! AreaChangeRequestResponse(uid,-1)
      }

      //
      // from RT-agent response
      //
    case res:AreaChangeRequestResponse =>
      if (userState.state == areaChangingServerState) {
        log.info(s"[$uid] AreaChangeRequestResponse(resultState = ${res.resultStatus}) received.")
        userState.areaChangeResult.foreach(_.success(res))
      }
      context.become(idling(userState.copy(areaChangeResult = None)), discardOld = true)

    case AreaChangeCancel(_) =>
      if (userState.state == areaChangingServerState) {
        log.info(s"[$uid] Cancel AreaChange")
        val nextState = userState.stateDef.nextState getOrElse runningServerState
        context.become(idling(changeState(nextState, userState)),discardOld = true)
      } else {
        log.warning(s"[$uid] AreaChangeCancel received. But current state is ${userState.state}. ignored.")
      }

    case AreaChangeResult(nextState, res) =>
      val api = new Api(userState,self)
      api.changeState(nextState)
      onCompleteAreaChange(res,api)
//      context.become(idling(changeState(nextState,userState)),discardOld = true)
      context.become(idling(api.modifiedUserState),discardOld = true)

    case m =>
      log.warning(s"[$uid] Unhandled message received:$m from:${sender()}")
  }

  //
  // NOTICE: In this state, MUST PROCESS THROUGH UNTIL END
  //
  def processFrame(userState:UserState,nextBytes:Option[ByteString] = None, incomingRequests:List[IncomingRequest] = Nil):Receive = {
        // !! Will not receive Begin() Message at this point !!
//    case Begin(_) =>
//      if (userState.noDataFrameCount > MAX_NO_DATA_COUNT) {
//        log.info(s"[$uid] no data received $MAX_NO_DATA_COUNT count, shutting down...")
//        context.become(processFrame(userState.copy(requestTerminate = true)),discardOld = true)
//      }

    case Tick(p) =>
      //
      // process position
      //
      val (pos,nextState,unmatchedCount,requestTerminate) = userState.nextPosition match {
          //
          // When next position data exists
          //
        case Some(nextPos) =>
//          log.info(s"nextPost:$nextPos")
          if (nextPos.state == userState.state.id.toShort) {
            //
            // When waiting position to transition
            //
            if (userState.waitingPositionToTransition/* && userState.stateDef.requireSpecifyPositionAtStateTransition*/) {
              log.info("Position received and going checking")
              if (userState.position.position == nextPos.position) {
                //
                // matched to require position, do transition
                //
                val next = userState.stateDef.nextState.getOrElse(runningServerState)
                log.info(s"[$uid] Request change State to $next")
                (nextPos, Some(next), 0, false)
              } else {
                //
                // When received position is not required position
                //
                if (userState.positionUnmatchWarning == 0) {
                  log.warning(s"[$uid] specify position unmatched, required ${userState.position.position} but ${nextPos.position}")
                }

                if (userState.positionUnmatchWarning < MAX_INITIAL_POSITION_UNMATCHED_WARNING) {
                  (userState.position, None, userState.positionUnmatchWarning + 1, false)
                } else {
                  log.warning(s"[$uid] initial position unmatched too much, Force shutdown")
                  agent ! ForceCheckOutFromArea(areaId,uid)
                  shutdown()
                  (userState.position, None, 0, true)
                }
              }
            } else {
              //
              // received next position in current state
              //

              // check can move?
              if (positionDebug) {
                if (userState.position.position != nextPos.position) {
                  log.info(s"[$uid] ${userState.position.position} => ${nextPos.position}")
                }
              }

              (nextPos, None, 0, false)
            }
          } else {
              //
              // TODO: Different state check
              //
            (userState.position, None, 0, false)
          }
        case None =>
          (userState.position, None, 0, false)
      }

      if (userState.stateDef.positionDbRegistration) {
        positionDB.registerUser(playerPositionToUserPosition(pos,uid,userState.userData))
      }

      p.success(true)

      if (!requestTerminate) {
        context.become(processFrame(userState.copy(
          position = pos,
          nextPosition = None,
          nextState = nextState,
          positionUnmatchWarning = unmatchedCount
        ), incomingRequests = incomingRequests), discardOld = true)
      }

    case Tock(p) =>
      val api = new Api(userState,self)
      val (lt,req,res) = if (userState.stateDef.processingRequest) {
        userState.queue.map {
          req=>
            if (req.timestamp > userState.lastTimestamp) {
              val res = processRequest(req, api)
              (Some(req.timestamp),Some(req),res)
            } else {
              (None:Option[Long],None,None)
            }
        }.getOrElse((None,None,None))
      } else (None,None,None)

      var nextUserState = api.modifiedUserState
      nextUserState = nextUserState.nextState match {
        case Some(next) =>
            changeState(next,userState)
        case None =>
          nextUserState
      }
//      nextUserState = reqPos.map(p => nextUserState.copy(position = p)).getOrElse(nextUserState)

      val interval = nextUserState.stateDef.positionDistributionInterval
      if (userState.state != nextUserState.state || !nextUserState.requestTerminate && (nextUserState.stateDef.positionDistributionInterval > 0 || nextUserState.waitingPositionToTransition)) {
        //
        // Send response to rt-agent
        //
        if (userState.state != nextUserState.state || interval == 1 || (userState.serverFrame % interval) == 0 || nextUserState.waitingPositionToTransition) {
          debug(log.debug(s"Response sends, state is ${nextUserState.state}"))
          agent ! MessageContainer(areaId, uid, encodeRtResponse(
            // Server sends next state at this time
            nextUserState.state,
            if (userState.stateDef.includesAreaIdInResponse) Some(areaId) else None,
            serverFrame = userState.serverFrame,
            response = res orElse userState.res,
            myPosition = nextUserState.position.copy(state = nextUserState.state.id.toShort),
            users = if (nextUserState.stateDef.positionDistribution) positionDB.queryUsersAroundUser(uid) else Seq(),
            lastTimestamp = nextUserState.lastTimestamp,
          ))
        }
      }

      p.success(true)


      (lt,res) match{
        case (Some(t),Some(_)) =>
          context.become(processFrame(userState = nextUserState.copy(
            res = res,
            lastTimestamp = t,
            lastRequest = req,
            userData = api.userData
          ), incomingRequests = incomingRequests),discardOld = true)
        case (Some(t),None) =>
          context.become(processFrame(userState = nextUserState.copy(
            lastTimestamp = t,
            lastRequest = req,
            userData = api.userData
          ), incomingRequests = incomingRequests),discardOld = true)
        case _ =>
          context.become(processFrame(userState = nextUserState.copy(
            userData = api.userData
          ), incomingRequests = incomingRequests),discardOld = true)
      }

    case End(_) =>
      debug(log.debug("End()"))
      if (!userState.requestTerminate) {
        context.become(idling(
          userState.nextState.map(changeState(_,userState)).getOrElse(userState)
            .copy(
              receivedBytes = 0,
              nextState = None
        )), discardOld = true)
        nextBytes.foreach(self.forward(_))
        if (incomingRequests.nonEmpty) self.forward(IncomingRequests(incomingRequests))
      } else {
        shutdown()
      }

    case bytes: ByteString =>
      //
      // Not process at this time
      //
      context.become(processFrame(userState,Some(bytes),incomingRequests),discardOld = true)

    case _ : ForceCheckOutFromAgent =>
      //
      // This time, only mark "requestTerminate" flag
      //
      log.info(s"[$uid] Request user termination")
      context.become(processFrame(userState = userState.copy(requestTerminate = true), incomingRequests = incomingRequests),discardOld = true)

    case req : Request =>
      context.become(processFrame(userState, incomingRequests = incomingRequests ++ List(IncomingRequest(sender(),req))),discardOld = true)

    case msg : AreaMessage =>
      context.become(processFrame(userState, incomingRequests = incomingRequests ++ List(IncomingRequest(sender(),msg))),discardOld = true)

    case res : AreaChangeResult =>  
      context.become(processFrame(userState, incomingRequests = incomingRequests ++ List(IncomingRequest(sender(),res))),discardOld = true)

    case m =>
      log.warning(s"[$uid] Unhandled message received during processing a frame:$m from:${sender()}")
  }
  
  def waitingShutdown:Receive = {
    case Done | ReceiveTimeout=>
      log.info(s"[$uid] Bye!")
      context.stop(self)

    case Begin(_) =>

    case Tick(p) =>
      p.success(false)

    case Tock(p) =>
      p.success(false)

    case End(_) =>

      //
      // Waiting shutdown, so always failure
      //
    case AreaChangeRequest(_,_,_) =>
      sender() ! AreaChangeRequestResponse(uid,ResultStatus.Failure.id.toByte)

    case _ =>
  }
}
