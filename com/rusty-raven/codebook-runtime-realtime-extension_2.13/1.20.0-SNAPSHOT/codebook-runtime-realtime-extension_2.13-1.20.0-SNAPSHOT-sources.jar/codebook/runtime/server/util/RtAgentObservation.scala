package codebook.runtime.server.util

import akka.actor.ActorRef
import codebook.runtime.protocol.{AgentObservationReason, AgentObserverNotification, RegisterAgentObserver, RegisterAgentObserverResponse, UnregisterAgentObserver}
import codebook.runtime.server.{ExtraActorState, RoleFinder, UserServiceActorBase, UserServiceActorState}

import scala.concurrent.{Future, Promise}

case class RtAgentObservationData(var registerResponse:Option[Promise[(Boolean,Option[ActorRef])]] = None) extends ExtraActorState

trait RtAgentObservation[S,D] { _ : UserServiceActorBase[S,D] =>
  import codebook.runtime.util.OptionHelper._

  def rtAgentFinder: RoleFinder
//  def rtAgentId:Int

  val RT_AGENT_OBSERVATION_EXTRA_ID:Int = 0x4001

  def createRtAgentObservation(rtAgentId:Int,targetId:Long):Future[(Boolean,Option[ActorRef])] =
    (for {
      conn<-rtAgentFinder.connectorFor(rtAgentId) ~> log.warning(s"createRtAgentObservation unknown rt-agent id:$rtAgentId")
//      myUid<-uid ~> log.warning(s"createRtAgentObservation uid not defined")
    } yield {
      conn ! RegisterAgentObserver(targetId)
      val p = Promise[(Boolean,Option[ActorRef])]()
      val data = stateData.extraActorStates.get(RT_AGENT_OBSERVATION_EXTRA_ID).flatMap(e => Option(e.asInstanceOf[RtAgentObservationData])).getOrElse(RtAgentObservationData())
      
      data.registerResponse = Some(p)
      stateData.extraActorStates += RT_AGENT_OBSERVATION_EXTRA_ID->data

      p.future
    }).getOrElse(Future.successful((false,None)))

  def disposeRtAgentObservation(rtAgentId:Int, targetId:Int):Boolean =
    (for {
      conn<-rtAgentFinder.connectorFor(rtAgentId)
//      myUid<-uid
    } yield {
      conn ! UnregisterAgentObserver(targetId)
      true
    }).getOrElse(false)

  def onAgentObserverNotify(reason:AgentObservationReason.Value, value:Long, data:D):(D,Option[S]) =
    (data,None)

  def rtAgentObservationEvent:StateFunction = {
    case Event(res:RegisterAgentObserverResponse, state) =>
      state.extraActorStates.get(RT_AGENT_OBSERVATION_EXTRA_ID).flatMap(e => Option(e.asInstanceOf[RtAgentObservationData])).foreach {
        data =>
          data.registerResponse.foreach(_.success(res.result, Some(sender())))
          data.registerResponse = None
          state.extraActorStates += RT_AGENT_OBSERVATION_EXTRA_ID->data
      }
      stay().using(state)

    case Event(ntf:AgentObserverNotification, state) =>
      val (data, nextState) = onAgentObserverNotify(AgentObservationReason(ntf.reason), ntf.value, state.data)
      state.data = data
      nextState.map(goto).getOrElse(stay()).using(state)
  }

  def rtAgentObservationCleanUp(state:UserServiceActorState[D]):Unit = {
//    disposeRtAgentObservation()
  }

  addUncategorizedHandlers(rtAgentObservationEvent)
  addExtraActorStateCleanUp(rtAgentObservationCleanUp)
}
