package codebook.runtime.server.area

import akka.dispatch.ControlMessage

import scala.concurrent.Promise

/*private [area] */trait SyncMessage extends ControlMessage

/*private [area] */case class Begin(frame:Int) extends SyncMessage

/*private [area] */case object Tick extends SyncMessage

/*private [area] */case object Tock extends SyncMessage

/*private [area] */case class Tick(result:Promise[Boolean])

/*private [area] */case class Tock(result:Promise[Boolean])

/*private [area] */case class End(frame:Int) extends SyncMessage

/*private [area] */case object Done extends SyncMessage
