package codebook.runtime.server.area

import akka.actor.{Actor, ActorContext, ActorLogging, ActorRef, ActorSystem, Props}
import akka.cluster.Cluster
import akka.routing.RoundRobinPool
import codebook.runtime.protocol.{AreaMessageWithUID, CheckIn, DistanceObservationMessage, ForceCheckOutFromAgent, MessageContainer, PlayerPosition, RelativeUserPosition, UserPosition}
import codebook.runtime.server._
import codebook.runtime.util.HasAkkaConfig
import org.slf4j.LoggerFactory

class CargoHandler[D,U <: UserPosition[D],P <: PlayerPosition[D,U,P],R <: RelativeUserPosition[D]](houseMaster: HouseMaster[D,U,P,R], pool:UserServiceActorPool) extends ClusterService with HasAkkaConfig {
  private val _logger = LoggerFactory.getLogger("CargoHandler")
  private var _worker:Option[ActorRef] = None
  private var _distanceObserver:Option[ActorRef] = None
  private var _unhandledMessageDelegate:Option[(Any,UserServiceActorPool,ActorContext) => Unit] = None

  def actorName = "CargoHandler"

  override def akkaConfig:String = CargoHandler.akkaConfig

  def worker: Option[ActorRef] = _worker

  class Worker extends Actor with ActorLogging {
    def forwardMessage(m:Any,to:Long)(implicit context: ActorContext):Unit =
      pool(to) match {
        case Some(u) =>
          u.forward(m)
  
        case None =>
          log.warning(s"${m.getClass.getName}: Unknown destination uid:$to")
      }


    def receive:Receive = {
        case c: CheckIn =>
          houseMaster.worker.foreach(_.forward(c))

        case m: MessageContainer =>
          pool(m.uid) match {
            case Some(u) =>
              u.forward(m.bytes)

            case None =>
              log.warning(s"MessageContainer: Unknown destination uid:${m.uid}")
          }
        case m: AreaMessageWithUID =>
          forwardMessage(m,m.uid)

        case m: DistanceObservationMessage =>
          _distanceObserver.foreach(_.forward(m))

        case m =>
          _unhandledMessageDelegate.foreach(_(m,pool,context))
      }
  }

  def distanceObserver:Option[ActorRef] = _distanceObserver
  def distanceObserver_=(ov:ActorRef):Unit = _distanceObserver = Some(ov)
  def unhandledMessageDelegate:Option[(Any,UserServiceActorPool,ActorContext) => Unit] = _unhandledMessageDelegate
  def unhandledMessageDelegate_=(dg:(Any,UserServiceActorPool,ActorContext) => Unit):Unit = _unhandledMessageDelegate = Some(dg)

  def start()(implicit system:ActorSystem):Unit = {
    _logger.info("Starting CargoHandler...")
    _worker = Some(system.actorOf(Props(new Worker).withDispatcher("cargo-handler-dispatcher").withRouter(RoundRobinPool(16)), actorName))
  }
  
  override def startWithCluster(cluster: Cluster, manager:ClusterManager): Unit = {
//    _worker = Some(cluster.system.actorOf(Props(new Worker).withDispatcher("cargo-handler-dispatcher").withRouter(RoundRobinPool(16)), actorName))
    start()(cluster.system)
  }
}

object CargoHandler extends HasAkkaConfig {
  override def akkaConfig:String =
s"""
cargo-handler-dispatcher {
  type = Dispatcher
  executor = "fork-join-executor"
  fork-join-executor {
    parallelism-min = 16
    parallelism-factor = 4.0
    parallelism-max = 512
  }
  throughput = 1
}
"""
}
