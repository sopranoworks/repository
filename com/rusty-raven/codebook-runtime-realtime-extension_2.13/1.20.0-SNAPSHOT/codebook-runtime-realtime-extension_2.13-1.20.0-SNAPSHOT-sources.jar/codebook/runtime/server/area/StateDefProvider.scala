package codebook.runtime.server.area

class StateDefProvider[SS <: Enumeration](state:SS) {
  private var stateDefs:Map[SS#Value, StateDef[SS]] = Map.empty

  implicit class StateName(name:SS#Value) {
    def :=(stateDef:StateDef[SS]):StateDef[SS] = {
      stateDefs += name->stateDef
      stateDef
    }
  }
  def apply(state:SS#Value):StateDef[SS] = stateDefs(state)
}
