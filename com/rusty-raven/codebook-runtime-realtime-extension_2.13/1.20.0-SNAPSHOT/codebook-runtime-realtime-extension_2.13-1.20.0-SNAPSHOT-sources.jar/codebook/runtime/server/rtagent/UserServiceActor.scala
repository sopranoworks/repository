package codebook.runtime.server.rtagent

import akka.actor.{Actor, ActorLogging, ActorRef, ReceiveTimeout}
import akka.dispatch.ControlMessage
import akka.io.Tcp.Close
import akka.pattern.ask
import akka.util.{ByteString, Timeout}
import codebook.runtime.packet.{DummyPacketCipher, Packet, PacketCipher}
import codebook.runtime.protocol.SystemMessages.{Closed, Connected, Tick}
import codebook.runtime.protocol._
import codebook.runtime.server._
import codebook.runtime.server.reservationdesk.{MakeReservationResponse, ReservationResponse}
import codebook.runtime.server.util.AreaFinder
import codebook.runtime.util.{ByteStringReader, TimeLimits}

import scala.concurrent.Future
import scala.util.{Failure, Success}

abstract class UserServiceActor[D,U <: UserPosition[D],P <: PlayerPosition[D,U,P],R <: RelativeUserPosition[D],SS <: Enumeration](
    val socket:ActorRef,
    nodeId:Int,
    reservationDesk: ReservationDesk,
    areaFinder: AreaFinder,
    areaArranger: Option[ReservationArranger],
    pool:UserServiceActorPool
  ) extends Actor with ActorLogging with RtPacketDecoder[D,U,P,R,SS] {

  import codebook.runtime.io.PortConversion._
  import codebook.runtime.util.TimeLimits._
  import codebook.runtime.util.OptionHelper._


  private case class Resolved(actor:ActorRef)
  case class AreaServerRef(aid:Int,connector:ActorRef)

  private case class ReservationResult(res:Option[MakeReservationResponse])

  object State {
    val whenLogin = 0
    val waitingCheckIn = 1
    val whenRunning = 2
    val whenWaitingShutdown = 3
    val whenReservingNextArea = 4
  }

  case class UserState(state:Int = 0,
                       currentArea:Option[AreaServerRef] = None,
                       previousArea:Option[AreaServerRef] = None,
                       nextArea:Option[AreaServerRef] = None,
                       currentAreaId:Int = -1,
                       previousAreaId:Int = -1,
                       nextAreaId:Int = -1,
                       uid:Long = -1,
                       timestamp:Option[Long] = None,
                       noMessageTicks:Int = 0,
                       areaState:Int = 0,
                       optBytes:Option[ByteString] = None,
                       observer:Option[ActorRef] = None
                      )

  private val MAX_NO_MESSAGE_TICKS = 5 * 30 // 30 sec

  val packetCipher:PacketCipher = new DummyPacketCipher

  def close(userState: UserState): Unit = {
//    currentArea.foreach(area => if (uid >=0) area ! ForceCheckOutFromAgent(uid))
    socket ! Close
  }

  def cleanUp(userState: UserState):Unit = {
    context.system.eventStream.unsubscribe(self,classOf[ControlMessage])
    pool.unregister(userState.uid)
  }

  def shutdown(userState: UserState):Unit = {
    close(userState)
    forceCheckOut(userState)
    cleanUp(userState)
    userState.observer.foreach(_ ! AgentObserverNotification(AgentObservationReason.disconnected.id.toShort,0))
    context.setReceiveTimeout(_10s)
    context.become(whenWaitingShutdown,discardOld = true)
  }

  override def preStart(): Unit = {
    log.info("Starting UserServiceActor")
  }

  override def postStop(): Unit = {

    
  }


  override def receive: Receive = {
    val userState = UserState()
    whenLogin(userState) orElse whenUnhandled(userState)
  }

  context.setReceiveTimeout(_10s)

  private def forceCheckOut(userState: UserState): Unit = {
    import context.dispatcher

    if (userState.uid >= 0) {
      userState.currentArea.foreach { area =>
        log.info(s"[${userState.uid}] Send ForceCheckOut to the area server")
        area.connector ! ForceCheckOutFromAgent(userState.uid)
      }
      reservationDesk.checkOut(userState.uid)
    }
  }
  
  private def areaServerFor(areaId:Int):Option[AreaServerRef] =
    areaFinder.connectorFor(areaId).map(AreaServerRef(areaId,_))

//  def areaChange(uid:Long,currentArea:Option[AreaServerRef],newAreaId:Int,token:Array[Byte]):Unit = {
//    import codebook.runtime.util.TimeLimits.timeout15s._
//    import context.dispatcher
//
//    val receiver = self
//
//    for {
//      newArea <- areaServerFor(newAreaId)
//      res2 <- newArea.connector.ask(CheckIn(uid,token,nodeId)).mapTo[AreaMessage]
//    } yield {
//      res2 match {
//        case CheckInSuccess(_) =>
//          Some(newArea)
//        case _ =>
//          None
//      }
//    }
//  }

  def whenCompleteCheckIn(newAreaId:Int,observer:Option[ActorRef], userState: UserState):Unit =
    observer.foreach(_ ! AgentObserverNotification(AgentObservationReason.areaChanged.id.toShort, newAreaId))
  
  def sendResponse(res:Response):Unit =
    socket.send(Packet(ByteString(0) ++ res.toByteString).encode(packetCipher).toByteString)

  /**
    * Create Response for Hello request
    * @param timestamp the timestamp of Hello request
    * @param resultStatus the result status of the response
    * @return created response
    */
  def createHelloResponse(timestamp:Long, resultStatus:Short):Response

  /**
    * Checking the request and returns check-in token
    * @param req received request
    * @return check-in token if request is valid
    */
  def checkHelloRequest(req:Request):Option[Array[Byte]]

  def processRequest(req:Request):Unit = {}

  def queryAreaIdAndToken(uid:Long):Option[(Int,Array[Byte])]

  def tryToReserveNextArea(nextAreaId:Int, uid:Long)(implicit timeout:Timeout = TimeLimits.timeout15s.timeout):Option[Future[ReservationResponse]] = {
    for {
      arranger <- areaArranger
    } yield {
      arranger.makeReservationWithSpecificRole(uid,areaFinder.roleFor(nextAreaId))
    }
  }

  private def toRunning(userState: UserState/*uid:Long,area:Option[AreaServerRef]*/):Unit = {
    context.setReceiveTimeout(_30s)
    context.system.eventStream.subscribe(self,classOf[ControlMessage])
    context.become(whenRunning(userState) orElse whenUnhandled(userState),discardOld = true)
  }

  private def next(userState: UserState):Unit = {
//    log.info(s"next state = ${userState.state}")
    context.become(userState.state match {
      case s if s == State.whenLogin => whenLogin(userState) orElse whenUnhandled(userState)
//      case s if s == State.waitingCheckIn => waitingCheckIn(userState)
      case s if s == State.waitingCheckIn || s == State.whenRunning || s == State.whenReservingNextArea => whenRunning(userState) orElse waitingCheckIn(userState) orElse whenReservingNextArea(userState) orElse whenUnhandled(userState)
      case s if s == State.whenWaitingShutdown => whenWaitingShutdown
//      case s if s == State.whenReservingNextArea => whenReservingNextArea(userState) orElse whenUnhandled(userState)
    },discardOld = true)
  }

  def checkIn(areaId:Int, areaToken: Array[Byte], userState: UserState):Boolean = {
    val nextArea = areaServerFor(areaId)

    nextArea match {
      case Some(area) =>
        log.info(s"send check in to $areaId <=> ${area.aid}:${area.connector}")
        area.connector ! CheckIn(userState.uid, areaToken, nodeId)
        next(userState.copy(state = State.waitingCheckIn,nextArea = Some(area), nextAreaId = areaId))
        true

      case None =>
        log.error(s"no area found for area id:$areaId")
        false
    }
  }

  def recoverAreaChange(userState: UserState):Unit = {
    userState.currentArea.foreach(prev => prev.connector ! AreaChangeCancel(userState.uid))
    next(userState.copy(state = State.whenRunning, nextArea = None/*currentArea = userState.previousArea, previousArea = None*/))
  }

  def whenLogin(userState: UserState):Receive = {
    case bytes:ByteString =>
      val (req,_) = decodeRtPacket(ByteStringReader(bytes))
      req.foreach(self.forward(_))
    case req:Request =>
      //
      checkHelloRequest(req).foreach {
        token =>
          
          //
          // At this point, no need async execution
          //
          log.info("Incoming Hello request")
          reservationDesk.blockCheckIn(token) match {
            case Some(uid) =>
              pool.register(uid, self)
              // load user information from redis
              queryAreaIdAndToken(uid) match {
                case Some((areaId,areaToken)) =>

                  if (areaId >= 0) {
                    // area login
                    if (!checkIn(areaId, areaToken, userState.copy(uid = uid,timestamp = Some(req.timestamp)))) {
                      sendResponse(createHelloResponse(req.timestamp, ResultStatus.Failure.id.toShort))
                      shutdown(userState.copy(uid = uid))
                    }
                  } else {
                    toRunning(userState.copy(currentArea = None))
                  }

                case None =>
                  log.error(s"No login info for uid:$uid")
                  sendResponse(createHelloResponse(req.timestamp, ResultStatus.Failure.id.toShort))
                  shutdown(userState.copy(uid = uid))
              }

            case None =>
              sendResponse(createHelloResponse(req.timestamp, ResultStatus.Failure.id.toShort))
              shutdown(userState)
          }
      }
  }

  def waitingCheckIn(userState: UserState):Receive = {
    case CheckInSuccess(_) =>
      log.info(s"[${userState.uid}] Checkin success to area server")
      userState.timestamp.foreach(t =>
        sendResponse(createHelloResponse(t,ResultStatus.Success.id.toShort)))

      userState.currentArea.foreach(_.connector ! AreaChangeRequestResponse(userState.uid,0))
      toRunning(userState.copy(timestamp = None, nextArea = None, nextAreaId = -1,currentArea = userState.nextArea, currentAreaId = userState.nextAreaId, previousArea = userState.currentArea, previousAreaId = userState.currentAreaId))
      whenCompleteCheckIn(userState.nextAreaId, userState.observer, userState)
    case CheckInFailure(_) =>
      userState.timestamp match {
        case Some(t) =>
          sendResponse(createHelloResponse(t,ResultStatus.Failure.id.toShort))
          shutdown(userState.copy(timestamp = None))
        case None =>
          recoverAreaChange(userState)
      }
  }

  def whenRunning(userState: UserState):Receive = {
    case bytes:ByteString =>
      userState.currentArea match {
        case Some(_) =>
          next(userState.copy(state = State.whenRunning,noMessageTicks = 0,optBytes = Some(bytes)))
        case None =>
          val (req,_) = decodeRtPacket(ByteStringReader(bytes))
          req.foreach(self.forward(_))
      }

    case MessageContainer(aid,_,bytes) =>
      userState.currentArea match {
        case Some(areaRef) =>
          if (areaRef.aid == aid) {
            val areaState = bytes(0) & 0x7f
            socket.send(Packet(bytes).toByteString)
            if (areaState != userState.areaState) {
              userState.observer.foreach(_ ! AgentObserverNotification(AgentObservationReason.areaStateChanged.id.toShort, (userState.areaState.toLong << 32) | areaState.toLong))
              next(userState.copy(areaState = areaState))
            }
          }
        case None =>
      }

      //
      // Tick message from GateTicker
      //
    case Tick =>
      if (userState.currentArea.isDefined) {
        val nextNoMessageTicks =
          (for {
            areaRef <- userState.currentArea
            bytes <- userState.optBytes
                 } yield {
            areaRef.connector ! MessageContainer(areaRef.aid, userState.uid, bytes)
            0
          })
            .getOrElse(userState.noMessageTicks + 1)
        if (nextNoMessageTicks < MAX_NO_MESSAGE_TICKS) {
          val newUserState = userState.copy(noMessageTicks = nextNoMessageTicks)
          next(newUserState)
        } else {
          shutdown(userState)
        }
      }

      //
      // AreaChangeRequest from Area server
      //
    case AreaChangeRequest(_, _, to) =>
      if (userState.nextArea.isEmpty && userState.currentArea.forall(_.aid != to)) {
        log.info(s"[${userState.uid}] AreaChangeRequest received from area server:${userState.currentArea.map(_.aid.toString).getOrElse("???")}")

        (for {
          nextArea <- areaServerFor(to) ~> log.warning(s"[${userState.uid}] Unknown area id on AreaChange request:$to")
          f <- tryToReserveNextArea(nextAreaId = to, userState.uid)
        } yield {
          import context.dispatcher

          next(userState.copy(state = State.whenReservingNextArea, nextArea = Some(nextArea)))
          val mySelf = self

          f.onComplete {
            case Success(res) =>
              log.info(s"[${userState.uid}] MakeReservation to new area server($to) success")
              mySelf ! ReservationResult(Option(res.asInstanceOf[MakeReservationResponse]))
            case Failure(e) =>
              log.warning(s"[${userState.uid}] MakeReservation to new area server failure: ${e.getMessage}")
              mySelf ! ReservationResult(None)
          }
        }).getOrElse {
          log.warning(s"[${userState.uid}] AreaChange failure: reserving failure")
          sender() ! AreaChangeRequestResponse(userState.uid,-1)
        }
      } else {
        log.warning(s"[${userState.uid}] AreaChange failure: bad state")
        sender() ! AreaChangeRequestResponse(userState.uid,-1)
      }

    case req: Request =>
      processRequest(req)
  }

  def whenWaitingShutdown:Receive = {
    case Closed | ReceiveTimeout =>
      context.stop(self)
    case _ =>
  }

  def whenReservingNextArea(userState: UserState):Receive = {
    case ReservationResult(res) =>
      log.info(s"ReservationResult($res)")
      (for {
        r <- res.flatMap {
                r =>
                  if (r.resultStatus == 0) Some(r) else {
                    None
                  }
              }
        area <- userState.nextArea
      } yield {
        log.info(s"[${userState.uid}] Check in to next area")
        checkIn(area.aid ,r.token.bytes, userState)
      }).getOrElse {
        //
        // TODO: implement rescue(recover) state
        //
        recoverAreaChange(userState)
      }
  }

  def whenUnhandled(userState: UserState):Receive = {
    case pkt:Packet =>
      pkt.decode(packetCipher).foreach(
        p=>self.forward(p.bytes)
      )

    case Closed =>
      forceCheckOut(userState)
      cleanUp(userState)
      context.stop(self)

    case ReceiveTimeout =>
      log.info(s"[${userState.uid}] No data received within 10 seconds, force disconnect")
      shutdown(userState)

    case SystemMessages.InvalidPacketReceived =>
      shutdown(userState)

    case Connected =>
      log.info("Incoming new user")
      
//    case AreaChangeRequest(from,to,token) =>
//      log.info(s"[${userState.uid}] Area Change Request received from $from to $to")
//      areaChange(userState.uid,userState.currentArea,to,token)

    case ForceCheckOutFromArea(areaId,_) =>
      // Check If the area is current or not
      if (userState.currentArea.exists(ca => ca.aid == areaId)) {
        log.info(s"[${userState.uid}] Requested Force Check Out. Bye!")
        shutdown(userState.copy(currentArea = None))
      } else {
        log.info(s"[${userState.uid}] Requested Force Check Out From not current area $areaId, Ignored")
      }

    case RegisterAgentObserver(uid) =>
      log.info(s"[$uid] Register Agent Observer")
      sender() ! RegisterAgentObserverResponse(uid, result = true)
      next(userState.copy(observer = Some(sender())))

    case UnregisterAgentObserver(_) =>
      userState.observer.foreach {
        ob =>
          if (sender() == ob) {
            log.info(s"[${userState.uid}] Unregister Agent Observer")
            next(userState.copy(observer = None))
          }
      }

    case e =>
      log.warning(s"Unhandled message:$e(${e.getClass.getName}) from ${sender()}")
  }

}
