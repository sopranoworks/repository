package codebook.runtime.server.area

case class StateDef[SS <: Enumeration](movable:Boolean,
                    requireSpecifyPositionAtStateTransition:Boolean,
                    positionDbRegistration:Boolean,
                    positionDistribution:Boolean,
                    // The position observer uses position db.
                    // So, positionDbRegistration = false means same.
//                    positionObservable:Boolean = true,
                    includesAreaIdInResponse:Boolean = false,
                    positionDistributionInterval:Int = 1,
                    processingRequest:Boolean = true,
                    noDataCheck:Boolean = true,
                    autoStateTransition:Boolean = false,
                    nextState:Option[SS#Value] = None,
                    timeoutLimit:Int = 0
                   ) {
  def waitingPositionToTransition:Boolean = autoStateTransition & requireSpecifyPositionAtStateTransition
}
