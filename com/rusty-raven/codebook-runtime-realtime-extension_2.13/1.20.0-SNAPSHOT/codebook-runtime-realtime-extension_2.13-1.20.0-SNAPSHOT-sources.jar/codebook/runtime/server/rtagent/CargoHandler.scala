package codebook.runtime.server.rtagent

import akka.actor.{Actor, ActorLogging, ActorRef, Props}
import akka.cluster.Cluster
import akka.routing.RoundRobinPool
import codebook.runtime.protocol.{AreaMessageWithUID, PlayerPosition, RelativeUserPosition, UserPosition}
import codebook.runtime.server.area.HouseMaster
import codebook.runtime.server.{ClusterManager, ClusterService, UserServiceActorPool}
import codebook.runtime.util.HasAkkaConfig
import org.slf4j.LoggerFactory

/**
  * The class for dispatching messages mainly from area-server to user servicing actor
  * at non-akka-clustered environment.
  *
  * @param pool
  */
class CargoHandler(pool:UserServiceActorPool) extends ClusterService with HasAkkaConfig {
  private val _logger = LoggerFactory.getLogger(actorName)
  private var _worker:Option[ActorRef] = None

  def actorName = "CargoHandler"

  override def akkaConfig:String = CargoHandler.akkaConfig

  def worker: Option[ActorRef] = _worker

  class Worker extends Actor with ActorLogging {
    def receive: Receive = {
      case msg: AreaMessageWithUID =>
        pool(msg.uid) match {
          case Some(act) =>
            act.forward(msg)

          case None =>
            _logger.debug("Unknown destination id {}",msg.uid)
            msg.errorResponse.foreach(sender() ! _)
        }

      case msg: Any =>
        _logger.info("Unhandled message received:{}",msg)

    }
  }
  override def startWithCluster(cluster: Cluster, manager:ClusterManager): Unit = {
    _logger.info("Starting CargoHandler...")
    _worker = Some(cluster.system.actorOf(Props(new Worker).withDispatcher("cargo-handler-dispatcher").withRouter(RoundRobinPool(16)), actorName))
  }
}

object CargoHandler extends HasAkkaConfig {
  override def akkaConfig:String =
s"""
cargo-handler-dispatcher {
  type = Dispatcher
  executor = "fork-join-executor"
  fork-join-executor {
    parallelism-min = 16
    parallelism-factor = 4.0
    parallelism-max = 512
  }
  throughput = 1
}
"""
}
