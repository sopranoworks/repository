package codebook.runtime.server.area

import akka.actor.{Actor, ActorLogging, ActorRef, ActorSystem, Props}
import codebook.runtime.protocol.{CancelDistanceObservation, DistanceObservationId, DistanceObservationNotification, ObserveDistanceBetween, UserPosition}
import codebook.runtime.util.UIDPublisher

import scala.concurrent.Future

class DistanceObserver[D,U <: UserPosition[D]](positionDB: PositionDBBase[U]) extends Actor with ActorLogging with UIDPublisher {
  private case class Observation(a:Long,b:Long,distance2:Float/*,count:Int */,checkExistsOnly:Boolean,from:ActorRef)

  override def unitId: Int = 0

  private def checkDistance(buffer:Map[Long,U], doId:Long, observation: Observation, self:ActorRef):Unit = {
    (for {
      a <- buffer.get(observation.a)
      b <- buffer.get(observation.b)
    } yield {
      if (!observation.checkExistsOnly && observation.distance2 < (a.position - b.position).length2) {
        observation.from.tell(DistanceObservationNotification(doId),self)
        self.tell(CancelDistanceObservation(doId),self)
      }
    }).getOrElse {
      // a or b is not exists
      observation.from.tell(DistanceObservationNotification(doId),self)
      self.tell(CancelDistanceObservation(doId),self)
    }
  }
  
  def receive: Receive = process(Map.empty)

  def process(observations:Map[Long,Observation]):Receive = {
    case Tock =>
      import context.dispatcher

      val mySelf = self
      for {
        buffer <- positionDB.buffer
        (doid,ovs) <- observations
      } {
        Future {
          checkDistance(buffer,doid,ovs,mySelf)
        }
      }
    case ObserveDistanceBetween(a,b,d) =>
      (for {
        buffer <- positionDB.buffer
        pa <- buffer.get(a)
        pb <- buffer.get(b)
      } yield {
        if (d == 0) {
          Some((publish, Observation(a, b, 0, checkExistsOnly = true, sender())))
        } else {
          val d2 = (d * d).toFloat
          if ((pa.position - pb.position).length2 <= d2) {
            Some((publish, Observation(a, b, d2, checkExistsOnly = false, sender())))
          } else {
            None
          }
        }
      }).flatten match {
        case Some((k,v)) =>
          sender() ! DistanceObservationId(k)
          context.become(process(observations + (k->v)),discardOld = true)
        case None =>
          sender() ! DistanceObservationId(0)
      }
    case CancelDistanceObservation(doid) =>
      context.become(process(observations - doid),discardOld = true)
  }
}

object DistanceObserver {
  val actorName = "DistanceObserver"
  def start[D,U <: UserPosition[D]](positionDB: PositionDBBase[U])(implicit system: ActorSystem):ActorRef =
    system.actorOf(Props(new DistanceObserver[D,U](positionDB)).withDispatcher("cargo-handler-dispatcher"),actorName)
}
