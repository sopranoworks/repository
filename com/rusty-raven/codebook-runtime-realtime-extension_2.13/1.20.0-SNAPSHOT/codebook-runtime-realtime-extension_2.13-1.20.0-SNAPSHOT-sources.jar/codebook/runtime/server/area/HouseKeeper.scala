package codebook.runtime.server.area

import akka.actor.{Actor, ActorLogging, ActorRef}
import akka.dispatch.MessageDispatcher
import akka.util.Timeout
import codebook.runtime.protocol.UserPosition

import scala.concurrent.duration._
import scala.concurrent.{Await, Future, Promise}

class HouseKeeper[D,U <: UserPosition[D]](positionDB:PositionDBBase[U],distanceObserver: ActorRef) extends Actor with ActorLogging {
  import HouseKeeper._

  private val d = 200.millis  // TODO temporary
  private implicit val to: Timeout = Timeout(d)
  private implicit val workerDispatcher: MessageDispatcher = context.system.dispatchers.lookup("ticktock-work-dispatcher")

  private case class KeeperState(timeoutFlag:Map[SyncMessage,Int] = Map())

  private def profileFrame(dt:Long,frame:Int,profile: Option[FrameProfile],numBorders:Int): FrameProfile = {
    val pf = profile match {
      case Some(FrameProfile(_,min,max,avg,_,_)) =>
        FrameProfile(frame,math.min(min,dt),math.max(max,dt),(avg + dt) / 2:Long,dt,numBorders)
      case None =>
        FrameProfile(frame,dt,dt,dt,dt,numBorders)
    }
    if (frame % 300 == 1) {
      log.info(s"$pf")
      FrameProfile(frame,dt,dt,pf.avg,dt,numBorders)
    } else {
      pf
    }
  }

  private def overZero(v:Int):Int = if (v < 0) 0 else v
//  private def under(v:Int,limit:Int):Int = if (v > limit) limit else v
  private def fill(v:Int, n:Int):Int = if (v == 0) n else v

  private def broadcast(/*borders:Iterable[ActorRef],*/msg:Any):Unit = {
//    borders.foreach((user:ActorRef)=>user ! msg)
    context.system.eventStream.publish(msg)
  }

  private def execute(borders:Iterable[ActorRef],frame:Int,keeperState: KeeperState):KeeperState = {
    broadcast(/*borders,*/Begin(frame))
    var timeoutFlag = Map.empty[SyncMessage,Int]

    timeoutFlag += Tick->
      (if (!wait(borders,Tick,keeperState)) fill(keeperState.timeoutFlag.getOrElse(Tick,0),300)
      else overZero(keeperState.timeoutFlag.getOrElse(Tick,0) - 1))
    positionDB.buildTreeAndSwapBuffers()

    timeoutFlag += Tock-> //!wait(borders,Tock,keeperState)
      (if (!wait(borders,Tock,keeperState)) fill(keeperState.timeoutFlag.getOrElse(Tock,0),300)
      else overZero(keeperState.timeoutFlag.getOrElse(Tock,0) - 1))
    distanceObserver ! Tock

    broadcast(/*borders,*/End(frame))
    keeperState.copy(timeoutFlag = timeoutFlag)
  }

  private def wait(borders:Iterable[ActorRef],msg:SyncMessage,keeperState: KeeperState):Boolean = {
    val results = if (msg == Tick) {
      borders.map { e =>
        Future {
          val p = Promise[Boolean]()
          e ! Tick(p)
          p.future
        }.flatten
      }
    } else {
      borders.map { e =>
        Future {
          val p = Promise[Boolean]()
          e ! Tock(p)
          p.future
        }.flatten
      }
    }
    try {
      val st = System.currentTimeMillis()
      Await.result(Future.sequence(results),Duration.Inf)
      val dt = (System.currentTimeMillis() - st).millis

      if (dt > d) {
        if (keeperState.timeoutFlag.getOrElse(msg, 0) == 0) {
          log.warning(s"Delayed: $msg $dt > $d users:${borders.size}")
        }
        false
      } else {
        true
      }
    } catch {
      case _ : java.util.concurrent.TimeoutException =>
        if (keeperState.timeoutFlag.getOrElse(msg, 0) == 0) {
          log.warning(s"Timeouted: $msg users:${borders.size}")
        }
        false
    }
  }

  def receive: Receive = processFrame(frame = 0,KeeperState())

  def processFrame(frame:Int,keeperState: KeeperState,frameProfile: Option[FrameProfile] = None):Receive = {
    case ExecuteFrame(borders) =>
      val st = System.currentTimeMillis()
      val ks = execute(borders,frame,keeperState)
      val fp = profileFrame(System.currentTimeMillis() - st,frame,frameProfile,borders.length)
      sender() ! Done
      context.become(processFrame(frame + 1,ks,frameProfile = Some(fp)),discardOld = true)
    case GetProfile =>
      sender() ! frameProfile
  }

}

object HouseKeeper {
  def actorName = "HouseKeeper"

  case class ExecuteFrame(boraders:List[ActorRef])
  case object GetProfile

  case class FrameProfile(frame:Int, min:Long, max:Long, avg:Long, lastProcessTime:Long, borders:Int)
}
