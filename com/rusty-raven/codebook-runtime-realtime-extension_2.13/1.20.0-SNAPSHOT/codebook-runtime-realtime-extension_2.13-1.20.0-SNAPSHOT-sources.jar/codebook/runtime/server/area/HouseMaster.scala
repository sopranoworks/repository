package codebook.runtime.server.area

import akka.actor.{Actor, ActorContext, ActorLogging, ActorRef, ActorSystem, Props}
import akka.cluster.Cluster
import akka.dispatch.ControlMessage
import codebook.runtime.protocol._
import codebook.runtime.server._
import codebook.runtime.util.HasAkkaConfig
import org.slf4j.LoggerFactory

import scala.concurrent.{ExecutionContext, Future}
import scala.concurrent.duration.{Duration, FiniteDuration, MILLISECONDS}
import scala.util.Success

trait HouseMaster[D,U <: UserPosition[D],P <: PlayerPosition[D,U,P],R <: RelativeUserPosition[D]] extends ClusterService with HasAkkaConfig {
  import HouseKeeper.ExecuteFrame

//  type P <: PlayerPosition[D,U,P]
//  type R <: RelativeUserPosition[D]

  def areaId:Int
  def reservationDesk: ReservationDesk
  def pool:UserServiceActorPool
  def helper:PositionHelper[D,U,P,R]

  private val _logger = LoggerFactory.getLogger("HouseMaster")
  private var _worker:Option[ActorRef] = None
  private var _keeper:Option[ActorRef] = None

  def actorName = "HouseMaster"

  override def akkaConfig:String =
    HouseMaster.akkaConfig + _cargoHandler.akkaConfig + AreaMessageSettings.akkaConfig

  val EXECUTING_INTERVAL:FiniteDuration=Duration(200,MILLISECONDS)

  protected val _positionDB:PositionDBBase[U] = new PositionDB[U]
  private lazy val _cargoHandler = new CargoHandler[D,U,P,R](houseMaster = this,pool = pool)
  private lazy val _positionDbDistributor = new PositionDbDistributor[D,U,P,R](areaId,_positionDB,helper)
  private var _unhandledMessageDelegate:Option[(Any,UserServiceActorPool,ActorContext) => Unit] = None

  def unhandledMessageDelegate:Option[(Any,UserServiceActorPool,ActorContext) => Unit] = _unhandledMessageDelegate
  def unhandledMessageDelegate_=(dg:(Any,UserServiceActorPool,ActorContext) => Unit):Unit = _unhandledMessageDelegate = Some(dg)

  def worker: Option[ActorRef] = _worker

  def userServiceActorDispatcherName:String = "user-service-actor-dispatcher"
  def createUserServiceActor(system:ActorSystem, areaId:Int, uid:Long, houseMaster:ActorRef, positionDB:PositionDBBase[U], agentPort:ActorRef, agentId:Int):Props

  class Worker extends Actor with ActorLogging {
    private object Tick extends ControlMessage

    private implicit val workerDispatcher: ExecutionContext = context.system.dispatchers.lookup("ticktock-work-dispatcher")

    override def preStart():Unit = {
      context.system.scheduler.scheduleWithFixedDelay(EXECUTING_INTERVAL,EXECUTING_INTERVAL,self,Tick)(context.dispatcher)
    }

    def checkIn(uid:Long,token:Array[Byte],messageSender:ActorRef,agentId:Int):Unit = {
//      import context.dispatcher
      val worker = self

//      Future {
//        reservationDesk.blockCheckIn(token) match {
//          case Some(uid2) if uid == uid2 =>
////            val user = context.system.actorOf(Props(new UserServiceActor(uid2,worker,_positionDB,messageSender,agentId)).withDispatcher("user-service-actor-dispatcher"))
//            val user = context.system.actorOf(createUserServiceActor(context.system, areaId, uid2, worker, _positionDB, messageSender, agentId).withDispatcher("user-service-actor-dispatcher"))
//            pool.register(uid2,user)
//            messageSender ! CheckInSuccess(uid)
//
//          case _ =>
//            messageSender ! CheckInFailure(uid)
//        }
//      }
      reservationDesk.checkIn(token).onComplete {
        case Success(Some(uid2)) =>
          val user = context.system.actorOf(createUserServiceActor(context.system, areaId, uid2, worker, _positionDB, messageSender, agentId).withDispatcher("user-service-actor-dispatcher"))
          pool.register(uid2,user)
          messageSender ! CheckInSuccess(uid)

        case _ =>
          messageSender ! CheckInFailure(uid)
      }
    }

    def checkOut(uid:Long):Unit = {
      pool.unregister(uid)
      reservationDesk.checkOut(uid)
    }

    def execute():Unit = {
      _keeper.foreach(_ ! ExecuteFrame(pool.all.toList))
    }

    def sendAllowTerminations(waitings:Set[ActorRef]):Unit = {
      Future {
        waitings.foreach(_ ! Done)
      }
    }
    
    def receive:Receive = messageHandler(frame = 0)

    def messageHandler(frame:Int):Receive = {
      case Tick =>
        execute()
        if (frame % 300 == 0) {
          log.info(s"pool size:${pool.size}")
        }
        context.become(waitingCompletion(frame,receiveTick = false,Set()),discardOld = true)

      case CheckIn(uid,token,agentId) =>
        log.info(s"Incoming new user uid:$uid")
        checkIn(uid,token,sender(),agentId)

        // This message is only from UserServiceActor to remove from pool
      case CheckOut(uid) =>
        checkOut(uid)
        sender() ! Done

      // These messages are received with cargo-handler
//      case msg @ ForceCheckOutFromAgent(uid) =>
//        pool(uid).foreach(_.forward(msg))
//
//      case MessageContainer(cid,bytes) =>
//        pool(cid).foreach(_.forward(bytes))
      case e =>
        log.warning(s"Unknown type message received:${e.getClass.getCanonicalName}")
    }

    def waitingCompletion(frame:Int,receiveTick:Boolean,waitingTermination:Set[ActorRef]):Receive = {
      case CheckIn(uid,token,agentId) =>
        log.info(s"Incoming new user uid:$uid")
        checkIn(uid,token,sender(),agentId)

        // This message is only from UserServiceActor to remove from pool
      case CheckOut(uid) =>
        checkOut(uid)
        context.become(waitingCompletion(frame + 1,receiveTick = false,waitingTermination + sender()),discardOld = true)
        
      case Done =>
        sendAllowTerminations(waitingTermination)
        if (receiveTick) {
          execute()
          context.become(waitingCompletion(frame + 1,receiveTick = false,Set()),discardOld = true)
        } else {
          context.become(messageHandler(frame + 1),discardOld = true)
        }

      case Tick =>
        context.become(waitingCompletion(frame,receiveTick = true,waitingTermination),discardOld = true)
    }
  }

  override def startWithCluster(cluster: Cluster, manager:ClusterManager): Unit = {
    _logger.info("Starting HouseMaster...")
    val distanceObserver = DistanceObserver.start[D,U](_positionDB)(cluster.system)
    _keeper = Some(cluster.system.actorOf(Props(new HouseKeeper[D,U](_positionDB,distanceObserver)).withDispatcher(/*"house-worker-dispatcher"*/"house-clock-keeper-dispatcher"), HouseKeeper.actorName))
    _worker = Some(cluster.system.actorOf(Props(new Worker()).withDispatcher("house-worker-dispatcher"), actorName))
    _cargoHandler.distanceObserver = distanceObserver
    _unhandledMessageDelegate.foreach(_cargoHandler.unhandledMessageDelegate = _)
    _cargoHandler.startWithCluster(cluster,manager)
    _positionDbDistributor.startWithCluster(cluster,manager)

//    HealthReporter.start(_keeper.get)(cluster.system)
  }
}

object HouseMaster extends HasAkkaConfig {
  override def akkaConfig:String =
s"""
house-worker-dispatcher {
  type = PinnedDispatcher
  executor = "thread-pool-executor"
  mailbox-type = "akka.dispatch.UnboundedControlAwareMailbox"
}
house-clock-keeper-dispatcher {
  type = PinnedDispatcher
  executor = "thread-pool-executor"
  mailbox-type = "akka.dispatch.UnboundedControlAwareMailbox"
}
user-service-actor-dispatcher {
  type = Dispatcher
  executor = "fork-join-executor"
  fork-join-executor {
    parallelism-min = 16
    parallelism-factor = 4.0
    parallelism-max = 128
  }
  throughput = 5
}
ticktock-work-dispatcher {
  type = Dispatcher
  executor = "fork-join-executor"
  fork-join-executor {
    parallelism-min = 16
    parallelism-factor = 4.0
    parallelism-max = 128
  }
  throughput = 5
}
""" + CargoHandler.akkaConfig
}
